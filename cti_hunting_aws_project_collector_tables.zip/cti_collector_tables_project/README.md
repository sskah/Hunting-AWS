# CTI Hunting AWS - arquitetura com API Gateway roteando Lambdas e Dynamo por collector
