/* ============================================================
   auth.js — OAuth2 (Authorization Code + PKCE) auth client
   - Reads /api/auth/config to discover provider URLs + client_id
   - Exchanges the code via the backend (/api/auth/exchange)
   - SSO only. Local/demo logins were removed.
   ============================================================ */

const Auth = (() => {
  const SESSION_KEY = 'reconlab.session';

  function _apiBase() {
    return (window.CTI_HUNTING_API_BASE || '').replace(/\/$/, '');
  }

  // Normalize an expiry that may arrive in seconds OR milliseconds.
  // Anything below ~year 2001 in ms is assumed to be seconds.
  function _normalizeExpiry(value) {
    const n = Number(value);
    if (!n || Number.isNaN(n)) return Date.now() + 8 * 3600_000;
    return n < 1e12 ? n * 1000 : n;
  }

  function isAuthenticated() {
    try {
      const s = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
      if (!s) return false;
      if (s.expires_at && Date.now() > s.expires_at) {
        localStorage.removeItem(SESSION_KEY);
        return false;
      }
      return true;
    } catch { return false; }
  }

  function getSession() {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); }
    catch { return null; }
  }

  function setSession(s) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(s));
  }

  function logout() {
    localStorage.removeItem(SESSION_KEY);
    window.location.replace('login.html');
  }

  function isAdmin() {
    const s = getSession();
    return !!s && s.role === 'admin';
  }

  // ---------- PKCE helpers ----------
  function _base64urlEncode(bytes) {
    let s = '';
    for (const b of bytes) s += String.fromCharCode(b);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  async function _sha256(text) {
    const buf = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest('SHA-256', buf);
    return new Uint8Array(hash);
  }
  function _randomString(len = 64) {
    const arr = new Uint8Array(len);
    crypto.getRandomValues(arr);
    return _base64urlEncode(arr);
  }

  async function _fetchAuthConfig() {
    const r = await fetch(_apiBase() + '/api/auth/config');
    if (!r.ok) throw new Error('SSO is not configured on the backend.');
    return r.json();
  }

  // ---------- OAuth2 Authorization Code + PKCE ----------
  async function startOAuth(provider) {
    const cfg = await _fetchAuthConfig();
    const p = cfg.providers && cfg.providers[provider];
    if (!p || !p.client_id) {
      throw new Error(`${provider} SSO is not configured on the backend.`);
    }

    const verifier = _randomString(64);
    const challenge = _base64urlEncode(await _sha256(verifier));
    const state = _randomString(16);

    sessionStorage.setItem('reconlab.pkce_verifier', verifier);
    sessionStorage.setItem('reconlab.pkce_state', state);
    sessionStorage.setItem('reconlab.pkce_provider', provider);

    const params = new URLSearchParams({
      client_id: p.client_id,
      redirect_uri: p.redirect_uri,
      response_type: 'code',
      scope: p.scope,
      code_challenge: challenge,
      code_challenge_method: 'S256',
      state,
    });
    window.location.href = `${p.auth_endpoint}?${params.toString()}`;
  }

  /**
   * Exchange the authorization code for a session via the backend.
   * Runs on whatever page the provider redirected to (see the guard
   * at the bottom of this file), so it no longer matters whether the
   * redirect_uri points at login.html, index.html, or the site root.
   */
  async function completeOAuth() {
    const params = new URLSearchParams(window.location.search);
    const code  = params.get('code');
    const state = params.get('state');
    const err   = params.get('error');
    if (err) throw new Error(params.get('error_description') || err);

    const expected = sessionStorage.getItem('reconlab.pkce_state');
    if (!state || state !== expected) throw new Error('state mismatch');

    const provider = sessionStorage.getItem('reconlab.pkce_provider');
    const verifier = sessionStorage.getItem('reconlab.pkce_verifier');
    if (!provider || !verifier) throw new Error('missing PKCE state');

    const r = await fetch(_apiBase() + '/api/auth/exchange', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, code, code_verifier: verifier }),
    });
    if (!r.ok) {
      let detail = '';
      try { detail = (await r.json()).error || ''; } catch {}
      throw new Error(`token exchange failed (${r.status})${detail ? ': ' + detail : ''}`);
    }
    const data = await r.json();

    setSession({
      provider,
      email: data.email || '',
      name: data.name || '',
      role: data.role || 'user',
      access_token: data.access_token || '',
      expires_at: _normalizeExpiry(data.expires_at),
    });

    sessionStorage.removeItem('reconlab.pkce_verifier');
    sessionStorage.removeItem('reconlab.pkce_state');
    sessionStorage.removeItem('reconlab.pkce_provider');
  }

  function _isOAuthCallback() {
    const q = new URLSearchParams(window.location.search);
    return q.has('code') && q.has('state');
  }

  function _isAppPage() {
    const p = location.pathname;
    return p.endsWith('/') || p.endsWith('/index.html');
  }

  return {
    isAuthenticated, getSession, setSession, logout, isAdmin,
    startOAuth, completeOAuth, _isOAuthCallback, _isAppPage,
  };
})();

/* ============================================================
   Single auth guard for the whole app.

   1) If the URL carries an OAuth callback (?code=&state=), finish
      the exchange HERE — on whichever page the provider landed on —
      then go to the app. This is what fixes the "OAuth sends me back
      to the login screen" loop: previously only login.html ran the
      exchange, so if the provider redirected anywhere else the code
      was never exchanged and index.html bounced back to login.
   2) Otherwise, protect the app pages: no session → login.
   location.replace() is used so the ?code= URL never stays in history.
   ============================================================ */
(function authGuard() {
  if (Auth._isOAuthCallback()) {
    Auth.completeOAuth()
      .then(() => { window.location.replace('index.html'); })
      .catch((e) => {
        const msg = encodeURIComponent(e && e.message ? e.message : 'oauth failed');
        window.location.replace('login.html?auth_error=' + msg);
      });
    return; // stop here while the redirect happens
  }

  if (Auth._isAppPage() && !Auth.isAuthenticated()) {
    window.location.replace('login.html');
  }
})();
