/* ============================================================
   env.js — where the front-end finds the API.

   Every call in the app is built as  <API_BASE> + "/api/<route>".
   So API_BASE must resolve "/api/health" to a working REST API URL.

   ── Option A (RECOMMENDED): same origin via CloudFront ──────────
   Add a CloudFront behavior for "/api/*" whose origin is the REST
   API Gateway, with the origin path set to your stage (e.g. "/prod").
   The front-end and API then share one origin, so:
     • leave API_BASE EMPTY (the value below), and
     • there is NO CORS — which is why the Lambdas need no changes
       (they don't emit Access-Control-* headers).

   ── Option B: call the REST API URL directly (cross-origin) ─────
   Point API_BASE at the full invoke URL INCLUDING the stage:
     window.CTI_HUNTING_API_BASE =
       'https://abc123.execute-api.us-east-1.amazonaws.com/prod';
   "/api/health" then becomes ".../prod/api/health". The stage prefix
   is fine — each Lambda trims everything before "/api/".
   NOTE: cross-origin needs CORS. API Gateway "Enable CORS" only
   answers the OPTIONS preflight; with Lambda *proxy* integration the
   GET/POST/etc. responses would also need an Access-Control-Allow-Origin
   header, which these Lambdas don't send. Prefer Option A.
   ============================================================ */
window.CTI_HUNTING_API_BASE = window.CTI_HUNTING_API_BASE || '';
