/* ============================================================
   app.js - Top-level wiring
   ============================================================ */

let lastScan = null;
let scanController = null;
let currentJobId = null;

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

async function runHealthCheck() {
  try {
    UI.log('health check started', 'INFO', 'health');
    const h = await API.health();
    if (h.logs?.length) UI.pushBackendLogs(h.logs);
    UI.log(`health check ${h.ok ? 'passed' : 'completed with warnings/errors'}`, h.ok ? 'OK' : 'WARN', 'health');
  } catch (e) {
    UI.log('health check failed: ' + e.message, 'ERROR', 'health');
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const sess = Auth.getSession();
  const isAdmin = Auth.isAdmin();

  // ── Session display ──────────────────────────────────────
  if (sess) {
    document.getElementById('user-email').textContent = sess.email || sess.name || 'user';
    if (isAdmin) {
      const badge = document.getElementById('user-role-badge');
      badge.textContent = 'ADMIN';
      badge.classList.remove('hidden');
    }
  }
  document.getElementById('btn-logout').addEventListener('click', () => Auth.logout());

  // ── Role-based UI ────────────────────────────────────────
  // Show admin-only nav buttons and table columns
  if (isAdmin) {
    document.querySelectorAll('.admin-only').forEach(el => el.classList.remove('hidden'));
  }

  // Default view is always ASSETS; ensure it's active
  UI.switchView('assets');

  // ── Bootstrap ────────────────────────────────────────────
  await UI.init();
  Assets.bind();
  ConfigUI.bind();

  Assets.render();
  UI.renderDashboard();
  runHealthCheck();

  // Wire history filters (admin only, but listeners are safe to add regardless)
  ['history-search','history-asset-filter','history-date-from','history-date-to','history-crit-filter'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => UI.renderHistory());
  });

  document.getElementById('footer-date').textContent = new Date().toUTCString();

  // ── Nav ──────────────────────────────────────────────────
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => UI.switchView(btn.dataset.view));
  });

  // ── Dashboard controls ───────────────────────────────────
  document.querySelectorAll('.dash-range').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.dash-range').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      UI.setDashScanRange(parseInt(btn.dataset.range) || 7);
    });
  });
  const dashSort = document.getElementById('dash-hist-sort');
  if (dashSort) dashSort.addEventListener('change', () => UI.renderDashboard());

  // ── Scan view (admin) ────────────────────────────────────
  document.getElementById('btn-all')
    .addEventListener('click', () => UI.setAllModules(true));
  document.getElementById('btn-none')
    .addEventListener('click', () => UI.setAllModules(false));

  document.getElementById('btn-cancel').addEventListener('click', async () => {
    if (currentJobId) {
      try {
        await API.cancelOsintJob(currentJobId);
        UI.log('cancel requested for current OSINT job', 'WARN', 'app');
      } catch (e) {
        UI.log('cancel request failed: ' + e.message, 'ERROR', 'app');
      }
      return;
    }
    if (scanController) scanController.abort();
  });

  const btnHealth = document.getElementById('btn-health');
  if (btnHealth) btnHealth.addEventListener('click', runHealthCheck);

  document.querySelectorAll('.lf').forEach(cb => {
    cb.addEventListener('change', () => UI.applyLogFilters());
  });

  // ── Run scan ─────────────────────────────────────────────
  document.getElementById('btn-run').addEventListener('click', async () => {
    const company = document.getElementById('company').value.trim();
    const terms = document.getElementById('terms').value
      .split('\n').map(s => s.trim()).filter(Boolean);

    if (!company)      return alert('Company name required.');
    if (!terms.length) return alert('At least one term/domain required.');

    const { modules, sources_by_module } = UI.getSelection();
    if (!modules.length) return alert('Select at least one module.');

    const btn = document.getElementById('btn-run');
    const btnCancel = document.getElementById('btn-cancel');
    btn.disabled = true;
    btn.querySelector('span').textContent = '⟳ EXECUTING...';
    btnCancel.classList.remove('hidden');
    UI.clearConsole();
    UI.resetProgress();
    UI.log(`▶ executing OSINT on "${company}"`, 'INFO', 'app');
    UI.log(`  terms: ${terms.join(', ')}`, 'DEBUG', 'app');
    UI.log(`  modules: ${modules.join(', ')}`, 'DEBUG', 'app');

    const safelist = Storage.safelistForBackend(company);
    const safeCount = Object.values(safelist).reduce((s, a) => s + (a?.length || 0), 0);
    if (safeCount) {
      UI.log(`  applying safelist: ${safeCount} corrected item(s) will be excluded`, 'INFO', 'app');
    }

    let logCursor = 0;

    try {
      const started = await API.startOsintJob({ company, terms, modules, sources_by_module, safelist });
      currentJobId = started.job_id;
      UI.log(`job queued: ${currentJobId}`, 'OK', 'app');

      while (currentJobId) {
        const { job } = await API.getOsintJob(currentJobId);
        if (!job) throw new Error('job not found');

        const logs = job.logs || [];
        if (logs.length > logCursor) {
          UI.pushBackendLogs(logs.slice(logCursor));
          logCursor = logs.length;
        }

        const p = job.progress || {};
        if (p.total) {
          const pct = Math.max(0, Math.min(100, (p.done / p.total) * 100));
          const modLabel = (p.module || '').replace('_', ' ');
          const statusLabel = p.status === 'running'
            ? `running ${modLabel}...`
            : p.status === 'done'
              ? `${modLabel} done`
              : p.status || 'running';
          UI.setProgress(pct, `[${p.done}/${p.total}] ${statusLabel}`);
        } else {
          UI.setProgress(5, job.status || 'queued');
        }

        if (job.status === 'succeeded') {
          lastScan = job.result;
          UI.setProgress(100, 'complete');
          UI.renderScore(lastScan.score);
          UI.log(`✓ scan complete — score=${lastScan.score.score} criticality=${lastScan.score.criticality}`, 'OK', 'app');
          break;
        }
        if (job.status === 'cancelled' || job.status === 'cancel_requested') {
          UI.log('⊘ scan cancelled', 'WARN', 'app');
          UI.resetProgress();
          break;
        }
        if (job.status === 'failed') {
          throw new Error(job.error || 'job failed');
        }

        await sleep(1500);
      }
    } catch (e) {
      UI.log('✗ scan failed: ' + e.message, 'ERROR', 'app');
      UI.resetProgress();
    } finally {
      currentJobId = null;
      scanController = null;
      btnCancel.classList.add('hidden');
      btn.disabled = false;
      btn.querySelector('span').textContent = '▶ EXECUTE OSINT';
    }
  });

  // ── Save + Export ─────────────────────────────────────────
  document.getElementById('btn-save').addEventListener('click', () => {
    if (!lastScan) return alert('Run a scan first.');
    Storage.saveScan({
      company: lastScan.company,
      terms:   lastScan.terms,
      counts:  lastScan.score.counts,
      results: lastScan.results,
      score:   lastScan.score.score,
      criticality:    lastScan.score.criticality,
      weighted_total: lastScan.score.weighted_total,
      logs: lastScan.logs || [],
      errors: lastScan.errors || {},
    });
    UI.log('✓ scan saved to history', 'OK', 'app');
    UI.renderDashboard();
  });

  document.getElementById('btn-export').addEventListener('click', async () => {
    if (!lastScan) return alert('Run a scan first.');
    try {
      await API.downloadReport({ company: lastScan.company, results: lastScan.results, score: lastScan.score });
      UI.log('✓ XLSX downloaded', 'OK', 'app');
    } catch (e) { UI.log('✗ export failed: ' + e.message, 'ERROR', 'app'); }
  });

  document.getElementById('btn-export-pdf').addEventListener('click', async () => {
    if (!lastScan) return alert('Run a scan first.');
    try {
      await API.downloadPdf({ company: lastScan.company, results: lastScan.results, score: lastScan.score });
      UI.log('✓ PDF downloaded', 'OK', 'app');
    } catch (e) { UI.log('✗ PDF export failed: ' + e.message, 'ERROR', 'app'); }
  });

  // ── History actions (admin) ────────────────────────────────
  let _diffBase = null;

  document.getElementById('history-tbody').addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const id  = btn.dataset.id;
    const rec = Storage.getScan(id);
    if (!rec) return;

    if (btn.dataset.act === 'edit') UI.openCorrectionModal(rec);
    if (btn.dataset.act === 'log')  UI.openLogModal(rec);
    if (btn.dataset.act === 'del') {
      if (confirm(`Delete scan for "${rec.company}"?`)) {
        Storage.removeScan(id);
        UI.renderHistory();
        UI.renderDashboard();
      }
    }
    if (btn.dataset.act === 'diff') {
      if (!_diffBase) {
        _diffBase = { id, company: rec.company };
        btn.classList.add('diff-selected');
        UI.log(`DIFF: scan A selected for "${rec.company}" — click DIFF on a second scan of the same company`, 'INFO', 'app');
      } else if (_diffBase.id === id) {
        _diffBase = null;
        document.querySelectorAll('button[data-act="diff"].diff-selected').forEach(b => b.classList.remove('diff-selected'));
        UI.log('DIFF: selection cleared', 'INFO', 'app');
      } else if (_diffBase.company.toLowerCase() !== rec.company.toLowerCase()) {
        UI.log(`DIFF: scans must be from the same company ("${_diffBase.company}" vs "${rec.company}")`, 'WARN', 'app');
      } else {
        const scanA = Storage.getScan(_diffBase.id);
        _diffBase = null;
        document.querySelectorAll('button[data-act="diff"].diff-selected').forEach(b => b.classList.remove('diff-selected'));
        UI.openDiffModal(scanA, rec);
      }
    }
  });

  document.getElementById('btn-clear-history').addEventListener('click', () => {
    if (confirm('Delete ALL scan history? This cannot be undone.')) {
      Storage.clearScans();
      UI.renderHistory();
      UI.renderDashboard();
    }
  });
});
