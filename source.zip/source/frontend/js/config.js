/* ============================================================
   config.js - Configuration editor view
   ============================================================ */

const ConfigUI = (() => {
  let _effective = {};

  const SOURCE_DEFS = [
    { source: 'IntelX',      keys: ['INTELX_KEY'],                          modules: ['credentials'] },
    { source: 'SerpAPI',     keys: ['SERPAPI_KEY'],                         modules: ['exposed_files', 'code_repos', 'apks', 'phishing'] },
    { source: 'VirusTotal',  keys: ['VIRUSTOTAL_KEY'],                      modules: ['domains'] },
    { source: 'DomainTools', keys: ['DOMAINTOOLS_USER', 'DOMAINTOOLS_KEY'], modules: ['domains'] },
    { source: 'Apura',       keys: ['APURA_KEY'],                           modules: ['domains', 'darkweb'] },
  ];

  async function render() {
    try {
      const full = await API.getConfigFull();
      _effective = full.effective;
    } catch (e) {
      UI.log('failed to load config: ' + e.message, 'ERROR', 'config');
      return;
    }

    // ---- fontes de coleta (read-only status badges) ----
    const keysWrap = document.getElementById('cfg-keys');
    keysWrap.innerHTML = '';
    for (const def of SOURCE_DEFS) {
      const configured = def.keys.every(k => !!_effective[k]);
      const moduleLabels = def.modules.map(m => UI.MODULE_LABELS[m] || m).join(', ');
      const row = document.createElement('div');
      row.className = 'src-status-row';
      row.innerHTML = `
        <span class="src-status-name">${def.source}</span>
        <span class="src-status-badge ${configured ? 'ok' : 'missing'}">${configured ? 'CONFIGURED' : 'NOT SET'}</span>
        <span class="src-status-modules">${moduleLabels}</span>
      `;
      keysWrap.appendChild(row);
    }

    // ---- exposed files ----
    document.getElementById('cfg-exposed-sites').value =
      _effective.EXPOSED_FILES_SITES || '';
    document.getElementById('cfg-exposed-terms').value =
      (_effective.EXPOSED_FILES_TERMS || []).join('\n');

    // ---- code repos ----
    document.getElementById('cfg-code-dorks').value =
      (_effective.CODE_REPO_DORKS || []).join('\n');

    // ---- apks ----
    document.getElementById('cfg-apk-dorks').value =
      (_effective.APK_DORKS || []).join('\n');

    // ---- weights (READ-ONLY: display only) ----
    const wrap = document.getElementById('cfg-weights');
    wrap.innerHTML = '';
    const weights = _effective.MODULE_WEIGHTS || {};
    for (const [mod, w] of Object.entries(weights)) {
      const f = document.createElement('div');
      f.className = 'field';
      f.innerHTML = `
        <span class="field-label">${UI.MODULE_LABELS[mod] || mod}</span>
        <input type="number" data-weight="${mod}" value="${w}" disabled readonly>
      `;
      wrap.appendChild(f);
    }

    // ---- scheduling (localStorage) ----
    const sched = Storage.getSchedConfig();
    document.getElementById('cfg-sched-interval').value = sched.intervalDays;
    document.getElementById('cfg-sched-max').value = sched.maxPerDay;
  }

  async function save() {
    const updates = {};

    // Exposed files
    const sites = document.getElementById('cfg-exposed-sites').value.trim();
    if (sites) updates.EXPOSED_FILES_SITES = sites;
    const eft = document.getElementById('cfg-exposed-terms').value
      .split('\n').map(s => s.trim()).filter(Boolean);
    if (eft.length) updates.EXPOSED_FILES_TERMS = eft;

    // Code repos
    const cdorks = document.getElementById('cfg-code-dorks').value
      .split('\n').map(s => s.trim()).filter(Boolean);
    if (cdorks.length) updates.CODE_REPO_DORKS = cdorks;

    // APKs
    const adorks = document.getElementById('cfg-apk-dorks').value
      .split('\n').map(s => s.trim()).filter(Boolean);
    if (adorks.length) updates.APK_DORKS = adorks;

    // Weights are READ-ONLY now — intentionally not collected/saved.

    // Scheduling (localStorage only)
    const interval = parseInt(document.getElementById('cfg-sched-interval').value) || 5;
    const maxPerDay = parseInt(document.getElementById('cfg-sched-max').value) || 3;
    Storage.saveSchedConfig({ intervalDays: interval, maxPerDay });

    try {
      const res = await API.saveConfig(updates);
      UI.log(`config saved: ${res.applied_keys.length} key(s) updated · scheduling: D+${interval}, max ${maxPerDay}/day`,
             'OK', 'config');
      await UI.init();
      await render();
    } catch (e) {
      alert('Save failed: ' + e.message);
    }
  }

  async function reset() {
    if (!confirm('Reset all overrides and restore defaults?')) return;
    await API.resetConfig();
    UI.log('✓ config overrides reset', 'OK', 'config');
    await UI.init();
    await render();
  }

  function bind() {
    document.getElementById('btn-save-config').addEventListener('click', save);
    document.getElementById('btn-reset-config').addEventListener('click', reset);
  }

  return { render, bind };
})();
