// Optional override when /api/* is not routed through the same CloudFront domain.
// Recommended AWS setup keeps this empty and uses a CloudFront behavior for /api/*.
window.CTI_HUNTING_API_BASE = window.CTI_HUNTING_API_BASE || '';
