/* ============================================================
   ui.js - DOM rendering helpers
   ============================================================ */

const UI = (() => {
  // Will be filled from /api/config
  let MODULE_SOURCES = {};
  let MODULE_WEIGHTS = {};
  let MODULE_ORDER = [];

  const MODULE_LABELS = {
    credentials:   'CREDENTIALS',
    exposed_files: 'EXPOSED FILES',
    code_repos:    'CODE REPOS',
    domains:       'DOMAIN',
    apks:          'APKs',
    phishing:      'PHISHING',
    darkweb:       'DEEP & DARK WEB',
  };

  const consoleEl = () => document.getElementById('console');

  // ---------- bootstrap from backend ----------
  async function init() {
    try {
      const cfg = await API.getConfig();
      MODULE_SOURCES = cfg.module_sources;
      MODULE_WEIGHTS = cfg.module_weights;
      MODULE_ORDER = Object.keys(MODULE_WEIGHTS);
      renderModulesGrid();
    } catch (e) {
      console.error('UI init failed', e);
      log('failed to load config from backend: ' + e.message, 'ERROR');
    }
  }

  // ---------- module grid (with source selectors) ----------
  let _gridDelegated = false;

  function _setupGridDelegation(grid) {
    if (_gridDelegated) return;
    _gridDelegated = true;
    grid.addEventListener('click', (e) => {
      const card = e.target.closest('.mod-toggle');
      if (!card) return;

      if (e.target.closest('.src-chip')) {
        e.stopPropagation();
        e.target.closest('.src-chip').classList.toggle('on');
        return;
      }

      if (e.target.closest('.mod-expand')) {
        e.stopPropagation();
        const panel = card.querySelector('.mod-sources');
        const btn = card.querySelector('.mod-expand');
        const isOpen = panel.classList.toggle('open');
        btn.classList.toggle('open', isOpen);
        return;
      }

      if (e.target.closest('.mod-left')) {
        const chk = card.querySelector('input[type="checkbox"]');
        chk.checked = !chk.checked;
        card.classList.toggle('checked', chk.checked);
      }
    });
  }

  function renderModulesGrid() {
    const grid = document.getElementById('modules-grid');
    grid.innerHTML = '';
    _setupGridDelegation(grid);

    for (const mod of MODULE_ORDER) {
      const sources = MODULE_SOURCES[mod] || [];
      const weight = MODULE_WEIGHTS[mod];
      const label = MODULE_LABELS[mod] || mod.toUpperCase();
      const num = String(weight).padStart(2, '0');

      const card = document.createElement('div');
      card.className = 'mod-toggle checked';
      card.dataset.mod = mod;
      card.innerHTML = `
        <div class="mod-row">
          <div class="mod-left">
            <input type="checkbox" checked>
            <span class="mod-num">${num}</span>
            <span class="mod-name">${label}</span>
          </div>
          <div class="mod-right">
            <span class="mod-weight">w·${weight}</span>
            <button class="mod-expand" type="button">▸</button>
          </div>
        </div>
        <div class="mod-sources">
          ${sources.map(s => `<span class="src-chip on" data-src="${s}">${s}</span>`).join('')}
        </div>
      `;
      grid.appendChild(card);
    }
  }

  function getSelection() {
    const modules = [];
    const sources_by_module = {};
    document.querySelectorAll('.mod-toggle').forEach(card => {
      const mod = card.dataset.mod;
      const enabled = card.querySelector('input[type="checkbox"]').checked;
      if (!enabled) return;
      modules.push(mod);
      const srcs = [];
      card.querySelectorAll('.src-chip.on').forEach(c => srcs.push(c.dataset.src));
      if (srcs.length) sources_by_module[mod] = srcs;
    });
    return { modules, sources_by_module };
  }

  function setAllModules(state) {
    document.querySelectorAll('.mod-toggle').forEach(card => {
      const chk = card.querySelector('input[type="checkbox"]');
      chk.checked = state;
      card.classList.toggle('checked', state);
    });
  }

  // ---------- console ----------
  function log(msg, level = 'INFO', module = '') {
    const el = consoleEl();
    if (!el) return;
    const ts = new Date().toTimeString().slice(0, 8);
    const line = document.createElement('div');
    line.className = `console-line ${level}`;
    line.dataset.level = level;
    line.innerHTML =
      `<span class="ts">${ts}</span>` +
      (module ? `<span class="mod">${escapeHtml(module)}</span>` : '') +
      escapeHtml(msg);
    el.appendChild(line);
    applyLogFilters();
    el.scrollTop = el.scrollHeight;
  }

  function pushBackendLogs(entries) {
    const el = consoleEl();
    for (const e of entries) {
      const line = document.createElement('div');
      line.className = `console-line ${e.level}`;
      line.dataset.level = e.level;
      line.innerHTML =
        `<span class="ts">${e.ts}</span>` +
        `<span class="mod">${escapeHtml(MODULE_LABELS[e.module] || e.module)}</span>` +
        escapeHtml(e.msg);
      el.appendChild(line);
    }
    applyLogFilters();
    el.scrollTop = el.scrollHeight;
  }

  function clearConsole() { consoleEl().innerHTML = ''; }

  function setProgress(pct, label) {
    const clamped = Math.min(100, pct);
    document.getElementById('progress-wrap').classList.remove('hidden');
    document.getElementById('progress-fill').style.width = clamped + '%';
    document.getElementById('progress-label').textContent = label || '';
    document.getElementById('progress-pct').textContent = Math.round(clamped) + '%';
  }

  function resetProgress() {
    document.getElementById('progress-wrap').classList.add('hidden');
    document.getElementById('progress-fill').style.width = '0%';
    document.getElementById('progress-label').textContent = 'preparing...';
    document.getElementById('progress-pct').textContent = '0%';
  }

  function applyLogFilters() {
    const enabled = new Set();
    document.querySelectorAll('.lf').forEach(cb => {
      if (cb.checked) enabled.add(cb.value);
    });
    document.querySelectorAll('.console-line').forEach(line => {
      const lvl = line.dataset.level;
      if (!lvl) return; // muted welcome line stays
      line.style.display = enabled.has(lvl) ? '' : 'none';
    });
  }

  // ---------- criticality ----------
  function critClass(score) {
    if (score <= 24) return 'crit-low';
    if (score <= 49) return 'crit-medium';
    if (score <= 75) return 'crit-high';
    return 'crit-critical';
  }
  function critLabel(score) {
    if (score <= 24) return 'LOW';
    if (score <= 49) return 'MEDIUM';
    if (score <= 75) return 'HIGH';
    return 'CRITICAL';
  }

  // ---------- score ----------
  function renderScore(scoreData) {
    document.getElementById('score-section').classList.remove('hidden');
    document.getElementById('score-big').textContent = scoreData.score;

    const critEl = document.getElementById('score-crit');
    critEl.textContent = critLabel(scoreData.score);
    critEl.className = 'score-crit ' + critClass(scoreData.score);

    const tbody = document.getElementById('score-tbody');
    tbody.innerHTML = '';
    for (const mod of MODULE_ORDER) {
      const count = scoreData.counts[mod] || 0;
      const w = MODULE_WEIGHTS[mod];
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${MODULE_LABELS[mod] || mod}</td>
        <td>${w}</td>
        <td>${count}</td>
        <td>${count * w}</td>
      `;
      tbody.appendChild(row);
    }
    document.getElementById('score-weighted-total').textContent =
      scoreData.weighted_total;
  }

  // ---------- history ----------
  function _populateHistoryAssetFilter() {
    const sel = document.getElementById('history-asset-filter');
    if (!sel) return;
    const current = sel.value;
    const companies = [...new Set(Storage.listScans().map(s => s.company))].sort((a, b) => a.localeCompare(b));
    sel.innerHTML = '<option value="">Todos os assets</option>';
    for (const c of companies) {
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = c;
      if (c === current) opt.selected = true;
      sel.appendChild(opt);
    }
  }

  function renderHistory() {
    _populateHistoryAssetFilter();
    const search   = (document.getElementById('history-search')?.value || '').toLowerCase();
    const asset    = (document.getElementById('history-asset-filter')?.value || '').toLowerCase();
    const dateFrom = document.getElementById('history-date-from')?.value || '';
    const dateTo   = document.getElementById('history-date-to')?.value || '';
    const crit     = document.getElementById('history-crit-filter')?.value || '';

    let records = Storage.listScans();
    if (search)   records = records.filter(r => r.company.toLowerCase().includes(search));
    if (asset)    records = records.filter(r => r.company.toLowerCase() === asset);
    if (dateFrom) records = records.filter(r => r.scanned_at >= dateFrom);
    if (dateTo)   records = records.filter(r => r.scanned_at <= dateTo + 'T23:59:59');
    if (crit)     records = records.filter(r => r.criticality === crit);

    const tbody = document.getElementById('history-tbody');
    if (!tbody) return;
    if (!records.length) {
      tbody.innerHTML = '<tr><td colspan="13" class="empty">no scans recorded yet</td></tr>';
      return;
    }
    tbody.innerHTML = '';
    const now = new Date();
    for (const rec of records) {
      const next = new Date(rec.next_scan_at);
      const overdue = next <= now;
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${escapeHtml(rec.company)}</strong></td>
        ${MODULE_ORDER.map(m => `<td>${rec.counts[m] || 0}</td>`).join('')}
        <td><strong>${rec.score}</strong></td>
        <td><span class="crit-badge ${critClass(rec.score)}">${critLabel(rec.score)}</span></td>
        <td>${formatDate(rec.scanned_at)}</td>
        <td class="${overdue ? 'next-due' : ''}">${formatDate(rec.next_scan_at)}${overdue ? ' ⚠' : ''}</td>
        <td>
          <div class="row-actions">
            <button data-act="edit" data-id="${rec.id}">EDIT</button>
            <button data-act="log"  data-id="${rec.id}">LOG</button>
            <button data-act="diff" data-id="${rec.id}" data-company="${escapeHtml(rec.company)}">DIFF</button>
            <button data-act="del"  data-id="${rec.id}" class="danger">DEL</button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    }
  }

  // ---------- dashboard ----------
  let _dashScanRange = 7;

  function _svgBarChart(host, data, opts = {}) {
    // data: [{ label, value }]
    const W = host.clientWidth || 520;
    const H = opts.height || 200;
    const padL = 34, padR = 12, padT = 14, padB = 38;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;
    const maxV = Math.max(1, ...data.map(d => d.value), opts.minMax || 0);
    const n = data.length || 1;
    const gap = 4;
    const bw = Math.max(2, (innerW / n) - gap);

    let bars = '', labels = '', grid = '';
    // y gridlines (4 steps)
    for (let i = 0; i <= 4; i++) {
      const yv = (maxV / 4) * i;
      const y = padT + innerH - (yv / maxV) * innerH;
      grid += `<line x1="${padL}" y1="${y}" x2="${W - padR}" y2="${y}" class="chart-grid"/>`;
      grid += `<text x="${padL - 6}" y="${y + 3}" class="chart-axis-label" text-anchor="end">${Math.round(yv)}</text>`;
    }
    data.forEach((d, i) => {
      const x = padL + i * (innerW / n) + gap / 2;
      const h = (d.value / maxV) * innerH;
      const y = padT + innerH - h;
      const color = d.color || opts.color || 'var(--accent)';
      bars += `<rect x="${x}" y="${y}" width="${bw}" height="${h}" rx="2" fill="${color}">
                 <title>${escapeHtml(String(d.title || d.label))}: ${d.value}</title></rect>`;
      // explicit value above each bar (skip zeros to reduce clutter)
      if (d.value > 0) {
        bars += `<text x="${x + bw / 2}" y="${y - 4}" class="chart-value-label"
                  text-anchor="middle">${d.value}</text>`;
      }
      // show every Nth label to avoid crowding
      const show = n <= 12 || i % Math.ceil(n / 12) === 0;
      if (show) {
        labels += `<text x="${x + bw / 2}" y="${H - padB + 14}" class="chart-axis-label" text-anchor="middle"
                    transform="rotate(35 ${x + bw / 2} ${H - padB + 14})">${escapeHtml(d.label)}</text>`;
      }
    });

    host.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" class="chart-svg">
      ${grid}${bars}${labels}</svg>`;
  }

  function _svgLineChart(host, data, opts = {}) {
    // data: [{ label, value }]
    const W = host.clientWidth || 520;
    const H = opts.height || 200;
    const padL = 34, padR = 12, padT = 14, padB = 38;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;
    const maxV = Math.max(1, ...data.map(d => d.value), opts.minMax || 0);
    const n = data.length;

    if (!n) { host.innerHTML = '<div class="empty">sem dados</div>'; return; }

    let grid = '';
    for (let i = 0; i <= 4; i++) {
      const yv = (maxV / 4) * i;
      const y = padT + innerH - (yv / maxV) * innerH;
      grid += `<line x1="${padL}" y1="${y}" x2="${W - padR}" y2="${y}" class="chart-grid"/>`;
      grid += `<text x="${padL - 6}" y="${y + 3}" class="chart-axis-label" text-anchor="end">${Math.round(yv)}</text>`;
    }

    const xAt = i => padL + (n === 1 ? innerW / 2 : (innerW / (n - 1)) * i);
    const yAt = v => padT + innerH - (v / maxV) * innerH;

    let pts = data.map((d, i) => `${xAt(i)},${yAt(d.value)}`).join(' ');
    let dots = '', labels = '';
    data.forEach((d, i) => {
      dots += `<circle cx="${xAt(i)}" cy="${yAt(d.value)}" r="3" fill="var(--accent)">
                 <title>${escapeHtml(d.label)}: ${d.value}</title></circle>`;
      // explicit value above each point
      dots += `<text x="${xAt(i)}" y="${yAt(d.value) - 8}" class="chart-value-label"
                text-anchor="middle">${d.value}</text>`;
      const show = n <= 12 || i % Math.ceil(n / 12) === 0;
      if (show) {
        labels += `<text x="${xAt(i)}" y="${H - padB + 14}" class="chart-axis-label" text-anchor="middle"
                    transform="rotate(35 ${xAt(i)} ${H - padB + 14})">${escapeHtml(d.label)}</text>`;
      }
    });

    const area = `${padL},${padT + innerH} ${pts} ${xAt(n - 1)},${padT + innerH}`;
    host.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" class="chart-svg">
      ${grid}
      <polygon points="${area}" class="chart-area"/>
      <polyline points="${pts}" class="chart-line"/>
      ${dots}${labels}</svg>`;
  }

  function _renderMiniTable(tbodyId, records) {
    const tbody = document.getElementById(tbodyId);
    if (!tbody) return;
    if (!records.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="empty">nenhum scan registrado</td></tr>';
      return;
    }
    tbody.innerHTML = '';
    records.forEach((rec, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${idx + 1}</strong></td>
        <td><strong>${escapeHtml(rec.company)}</strong></td>
        <td><strong>${rec.score}</strong></td>
        <td><span class="crit-badge ${critClass(rec.score)}">${critLabel(rec.score)}</span></td>
      `;
      tbody.appendChild(tr);
    });
  }

  function _renderDashHistTable(sort) {
    let records = Storage.latestScanPerAsset();
    if (sort === 'recent') {
      records = records.slice().sort((a, b) => new Date(b.scanned_at) - new Date(a.scanned_at));
    } else {
      records = records.slice().sort((a, b) => b.score - a.score);
    }
    records = records.slice(0, 10);

    const tbody = document.getElementById('dash-hist-tbody');
    if (!tbody) return;
    if (!records.length) {
      tbody.innerHTML = '<tr><td colspan="12" class="empty">nenhum scan registrado</td></tr>';
      return;
    }
    tbody.innerHTML = '';
    records.forEach((rec, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${idx + 1}</strong></td>
        <td><strong>${escapeHtml(rec.company)}</strong></td>
        ${MODULE_ORDER.map(m => `<td>${rec.counts?.[m] || 0}</td>`).join('')}
        <td><strong>${rec.score}</strong></td>
        <td><span class="crit-badge ${critClass(rec.score)}">${critLabel(rec.score)}</span></td>
        <td>${formatDate(rec.scanned_at)}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  function renderDashboard() {
    // Monthly average score (line chart)
    const monthly = Storage.monthlyAvgScore();
    const monthlyHost = document.getElementById('chart-monthly');
    if (monthlyHost) {
      if (!monthly.length) monthlyHost.innerHTML = '<div class="empty">sem dados de scans</div>';
      else _svgLineChart(monthlyHost,
        monthly.map(m => ({ label: m.month, value: m.avg })),
        { minMax: 100, height: 200 });
    }

    // Scans per day (bar chart)
    _renderScansChart();

    // Top 3 categories
    const cats = Storage.topCategories(3);
    const catHost = document.getElementById('dash-top-categories');
    if (catHost) {
      if (!cats.length) {
        catHost.innerHTML = '<div class="empty">nenhum scan registrado</div>';
      } else {
        const maxTotal = Math.max(1, ...cats.map(c => c.total));
        catHost.innerHTML = cats.map((c, i) => `
          <div class="top-cat-card">
            <div class="top-cat-rank">#${i + 1}</div>
            <div class="top-cat-body">
              <div class="top-cat-name">${MODULE_LABELS[c.module] || c.module}</div>
              <div class="top-cat-bar-track">
                <div class="top-cat-bar" style="width:${(c.total / maxTotal) * 100}%"></div>
              </div>
            </div>
            <div class="top-cat-total">${c.total}</div>
          </div>
        `).join('');
      }
    }

    // Top offenders mini-table
    _renderMiniTable('dash-top-offenders-tbody', Storage.topOffenders(10));

    // History-style top 10 list
    const sortSel = document.getElementById('dash-hist-sort');
    _renderDashHistTable(sortSel ? sortSel.value : 'score');
  }

  function _renderScansChart() {
    const host = document.getElementById('chart-scans');
    if (!host) return;
    const data = Storage.scansPerDay(_dashScanRange);
    if (!data.some(d => d.count > 0)) {
      host.innerHTML = '<div class="empty">nenhum scan no periodo</div>';
      return;
    }
    _svgBarChart(host,
      data.map(d => ({ label: d.day.slice(5), title: d.day, value: d.count })),
      { height: 200 });
  }

  function setDashScanRange(days) {
    _dashScanRange = days;
    _renderScansChart();
  }

  // ---------- correction modal ----------
  function _itemLabelFor(mod, item) {
    if (mod === 'credentials')
      return [item.user, item.password].filter(Boolean).join(' / ') || item.url || '(credencial)';
    if (mod === 'domains') return item.domain || '(dominio)';
    if (mod === 'darkweb') return item.title || item.url || item.event_id || '(item)';
    return item.title || item.link || item.typo_variant || '(item)';
  }

  function _scanHasItems(record) {
    return record.results && Object.values(record.results).some(a => (a || []).length);
  }

  function openCorrectionModal(record) {
    const modal = document.getElementById('correction-modal');
    const body = document.getElementById('modal-body');
    document.getElementById('modal-title').textContent = `EDIT SCORE :: ${record.company}`;

    // If the scan stored detailed findings, offer item-level correction
    // (checkboxes) which both lowers the count AND adds the item to the
    // asset's safelist so future scans drop it automatically.
    if (_scanHasItems(record)) {
      _renderItemCorrection(record, modal, body);
    } else {
      _renderCountCorrection(record, modal, body);
    }
  }

  // ----- item-level correction (preferred) -----
  function _renderItemCorrection(record, modal, body) {
    const results = record.results || {};
    const already = new Set(
      Storage.listCorrected(record.company).map(c => c.module + '|' + c.fp)
    );

    let sections = '';
    for (const mod of MODULE_ORDER) {
      const items = results[mod] || [];
      if (!items.length) continue;
      const rows = items.map(it => {
        const fp = it._fp;
        if (!fp) return '';
        const done = already.has(mod + '|' + fp);
        return `
          <label class="ci-item ${done ? 'ci-done' : ''}">
            <input type="checkbox" class="cc-check" data-mod="${mod}" data-fp="${escapeHtml(fp)}"
                   data-label="${escapeHtml(_itemLabelFor(mod, it))}" ${done ? 'checked disabled' : ''}>
            <span class="ci-item-label">${escapeHtml(_itemLabelFor(mod, it))}</span>
            ${done ? '<span class="ci-tag">ja corrigido</span>' : ''}
          </label>`;
      }).join('');
      sections += `
        <div class="ci-section">
          <h4 class="ci-section-title">${MODULE_LABELS[mod] || mod} <span class="ci-count">${items.length}</span></h4>
          <div class="ci-section-items">${rows}</div>
        </div>`;
    }

    body.innerHTML = `
      <p class="config-note" style="margin-bottom:12px;">
        Marque os itens que foram corrigidos. Eles serao removidos do score deste scan
        e adicionados a <strong>Safelist</strong> do asset — assim somem automaticamente
        nos proximos scans.
      </p>
      ${sections}
      <div class="modal-action-row">
        <input type="text" id="correction-note" placeholder="nota opcional (ex: ticket de remediacao)">
        <button id="btn-apply-correction" class="btn btn-primary">CORRIGIR &amp; SALVAR</button>
      </div>
      <div id="preview-score" style="margin-top:14px; font-size:11px; color: var(--text-1);"></div>
      <div class="correction-log" id="correction-log"></div>
    `;

    function preview() {
      // recompute counts = original counts minus newly checked items per module
      const checkedByMod = {};
      body.querySelectorAll('.cc-check:checked:not(:disabled)').forEach(cb => {
        checkedByMod[cb.dataset.mod] = (checkedByMod[cb.dataset.mod] || 0) + 1;
      });
      const counts = {};
      for (const m of MODULE_ORDER) {
        counts[m] = Math.max(0, (record.counts[m] || 0) - (checkedByMod[m] || 0));
      }
      const ks = MODULE_ORDER.filter(m => counts[m] > 0)
        .map(m => 2 * MODULE_WEIGHTS[m] * Math.log2(1 + counts[m]));
      const weightedTotal = MODULE_ORDER.reduce((s, m) => s + counts[m] * MODULE_WEIGHTS[m], 0);
      let score = 0;
      if (ks.length) {
        const base = Math.max(...ks);
        const others = ks.reduce((s, k) => s + k, 0) - base;
        score = Math.min(100, Math.round(base + 0.20 * others));
      }
      const nSel = body.querySelectorAll('.cc-check:checked:not(:disabled)').length;
      document.getElementById('preview-score').innerHTML =
        `${nSel} item(ns) marcado(s) · preview → score ${record.score} → ${score} · ` +
        `<span class="crit-badge ${critClass(score)}">${critLabel(score)}</span>`;
    }
    body.addEventListener('change', e => { if (e.target.classList.contains('cc-check')) preview(); });
    preview();
    _renderCorrectionLog(record);

    document.getElementById('btn-apply-correction').onclick = async () => {
      const entries = [];
      const checkedByMod = {};
      body.querySelectorAll('.cc-check:checked:not(:disabled)').forEach(cb => {
        entries.push({ module: cb.dataset.mod, fp: cb.dataset.fp, label: cb.dataset.label });
        checkedByMod[cb.dataset.mod] = (checkedByMod[cb.dataset.mod] || 0) + 1;
      });
      if (!entries.length) { alert('Selecione ao menos um item corrigido.'); return; }
      const note = document.getElementById('correction-note').value;

      const counts = {};
      for (const m of MODULE_ORDER) {
        counts[m] = Math.max(0, (record.counts[m] || 0) - (checkedByMod[m] || 0));
      }
      try {
        // 1) add to the per-asset safelist (replicates to Assets → Safelist)
        Storage.addCorrected(record.company, entries, note);
        // 2) recalc + persist the corrected score on this scan
        const newScore = await API.recalc(counts);
        Storage.applyCorrection(record.id, counts, newScore, note);
        closeModal();
        // refresh whichever views are mounted
        renderHistory();
        renderDashboard();
        if (typeof Assets !== 'undefined' && Assets.renderSafelist) {
          const a = Storage.listAssets()
            .find(x => x.name.toLowerCase() === record.company.toLowerCase());
          if (a) Assets.renderSafelist(a);
        }
      } catch (e) {
        alert('Recalc failed: ' + e.message);
      }
    };
    modal.classList.remove('hidden');
  }

  // ----- legacy count-only correction (fallback) -----
  function _renderCountCorrection(record, modal, body) {
    body.innerHTML = `
      <p class="config-note" style="margin-bottom:12px;">
        Este scan nao possui itens detalhados (foi gerado antes da atualizacao).
        Ajuste as contagens manualmente — a Safelist nao sera alterada.
      </p>
      <div class="edit-grid" id="edit-grid"></div>
      <div class="modal-action-row">
        <input type="text" id="correction-note" placeholder="optional note about this correction">
        <button id="btn-apply-correction" class="btn btn-primary">RECALC &amp; SAVE</button>
      </div>
      <div id="preview-score" style="margin-top:14px; font-size:11px; color: var(--text-1);"></div>
      <div class="correction-log" id="correction-log"></div>
    `;

    const grid = document.getElementById('edit-grid');
    for (const mod of MODULE_ORDER) {
      const w = MODULE_WEIGHTS[mod];
      const count = record.counts[mod] || 0;
      const row = document.createElement('div');
      row.className = 'edit-row';
      row.innerHTML = `
        <span style="color: var(--accent); font-family: var(--display);">${MODULE_LABELS[mod] || mod}</span>
        <span class="weight">×${w}</span>
        <input type="number" min="0" value="${count}" data-mod="${mod}">
      `;
      grid.appendChild(row);
    }

    function preview() {
      const counts = {};
      grid.querySelectorAll('input[data-mod]').forEach(i => {
        counts[i.dataset.mod] = parseInt(i.value) || 0;
      });
      const ks = MODULE_ORDER.filter(m => counts[m] > 0)
        .map(m => 2 * MODULE_WEIGHTS[m] * Math.log2(1 + counts[m]));
      const weightedTotal = MODULE_ORDER.reduce(
        (s, m) => s + (counts[m] || 0) * MODULE_WEIGHTS[m], 0);
      let score = 0;
      if (ks.length) {
        const base = Math.max(...ks);
        const others = ks.reduce((s, k) => s + k, 0) - base;
        score = Math.min(100, Math.round(base + 0.20 * others));
      }
      document.getElementById('preview-score').innerHTML =
        `preview → weighted=${weightedTotal} · score=${score} · ` +
        `<span class="crit-badge ${critClass(score)}">${critLabel(score)}</span>`;
    }
    grid.addEventListener('input', preview);
    preview();
    _renderCorrectionLog(record);

    document.getElementById('btn-apply-correction').onclick = async () => {
      const counts = {};
      grid.querySelectorAll('input[data-mod]').forEach(i => {
        counts[i.dataset.mod] = parseInt(i.value) || 0;
      });
      const note = document.getElementById('correction-note').value;
      try {
        const newScore = await API.recalc(counts);
        Storage.applyCorrection(record.id, counts, newScore, note);
        closeModal();
        renderHistory();
        renderDashboard();
      } catch (e) {
        alert('Recalc failed: ' + e.message);
      }
    };
    modal.classList.remove('hidden');
  }

  function _renderCorrectionLog(record) {
    const logEl = document.getElementById('correction-log');
    if (!logEl) return;
    if (record.corrections && record.corrections.length) {
      logEl.innerHTML = '<h4>CORRECTION HISTORY</h4>';
      record.corrections.slice().reverse().forEach(c => {
        const delta = c.new_score - c.old_score;
        const sign = delta > 0 ? '+' : '';
        const entry = document.createElement('div');
        entry.className = 'correction-entry';
        entry.innerHTML = `
          <span class="ts">${formatDate(c.at)}</span>
          score ${c.old_score} → ${c.new_score}
          <span class="delta">(${sign}${delta})</span>
          ${c.note ? '· ' + escapeHtml(c.note) : ''}
        `;
        logEl.appendChild(entry);
      });
    }
  }

  function openLogModal(record) {
    const modal = document.getElementById('correction-modal');
    const body = document.getElementById('modal-body');
    document.getElementById('modal-title').textContent = `LOG :: ${record.company}`;

    let html = `
      <div style="margin-bottom:16px; font-size:11px; color:var(--text-1);">
        Scan: ${formatDate(record.scanned_at)}<br>
        Score: <strong style="color:var(--accent)">${record.score}</strong>
        · <span class="crit-badge ${critClass(record.score)}">${critLabel(record.score)}</span><br>
        Counts: ${MODULE_ORDER.map(m =>
          `${MODULE_LABELS[m] || m}=${record.original_counts[m] || 0}`).join(' · ')}
      </div>
      <div class="correction-log">
        <h4>CORRECTIONS (${(record.corrections || []).length})</h4>
    `;
    if (!(record.corrections || []).length) {
      html += '<div class="correction-entry">no corrections yet</div>';
    } else {
      record.corrections.slice().reverse().forEach(c => {
        const delta = c.new_score - c.old_score;
        const sign = delta > 0 ? '+' : '';
        html += `
          <div class="correction-entry">
            <span class="ts">${formatDate(c.at)}</span>
            score <strong>${c.old_score}</strong> → <strong>${c.new_score}</strong>
            <span class="delta">(${sign}${delta})</span><br>
            <span style="font-size:10px; color:var(--text-2)">
              ${MODULE_ORDER.map(m =>
                (c.old_counts[m] !== c.new_counts[m])
                ? `${MODULE_LABELS[m] || m}: ${c.old_counts[m]}→${c.new_counts[m]}` : '')
                .filter(Boolean).join(' · ')}
            </span>
            ${c.note ? `<div style="margin-top:4px; color:var(--text-1)">"${escapeHtml(c.note)}"</div>` : ''}
          </div>
        `;
      });
    }
    html += '</div>';
    body.innerHTML = html;
    modal.classList.remove('hidden');
  }

  function closeModal() {
    document.getElementById('correction-modal').classList.add('hidden');
  }

  // ---------- diff modal ----------
  function openDiffModal(scanA, scanB) {
    // scanA = older, scanB = newer (sort by scanned_at ascending)
    const [older, newer] = [scanA, scanB].sort(
      (a, b) => new Date(a.scanned_at) - new Date(b.scanned_at)
    );

    document.getElementById('diff-modal-title').textContent =
      `DIFF :: ${escapeHtml(older.company)}`;

    const scoreDelta = newer.score - older.score;
    const scoreSign  = scoreDelta > 0 ? '+' : '';
    const scoreClass = scoreDelta > 0 ? 'crit-high' : scoreDelta < 0 ? 'crit-low' : '';

    let rows = MODULE_ORDER.map(m => {
      const a = older.counts[m] || 0;
      const b = newer.counts[m] || 0;
      const d = b - a;
      const sign = d > 0 ? '+' : '';
      const cls  = d > 0 ? 'diff-worse' : d < 0 ? 'diff-better' : 'diff-same';
      return `<tr class="${cls}">
        <td>${MODULE_LABELS[m] || m}</td>
        <td class="num">${a}</td>
        <td class="num">${b}</td>
        <td class="num delta">${sign}${d}</td>
      </tr>`;
    }).join('');

    document.getElementById('diff-modal-body').innerHTML = `
      <div class="diff-header-row">
        <div class="diff-scan-label">
          <span class="diff-tag">A</span>
          ${formatDate(older.scanned_at)}
          <span class="crit-badge ${critClass(older.score)}">${older.score}</span>
        </div>
        <div class="diff-arrow">→</div>
        <div class="diff-scan-label">
          <span class="diff-tag">B</span>
          ${formatDate(newer.scanned_at)}
          <span class="crit-badge ${critClass(newer.score)}">${newer.score}</span>
        </div>
        <div class="diff-score-delta ${scoreClass}">${scoreSign}${scoreDelta} pts</div>
      </div>
      <table class="diff-table">
        <thead>
          <tr>
            <th>MODULE</th>
            <th class="num">SCAN A</th>
            <th class="num">SCAN B</th>
            <th class="num">DELTA</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
      <div style="margin-top:12px; font-size:10px; color:var(--text-2)">
        Green = fewer findings (improved) · Red = more findings (worse)
      </div>
    `;

    document.getElementById('diff-modal').classList.remove('hidden');
  }

  function closeDiffModal() {
    document.getElementById('diff-modal').classList.add('hidden');
  }

  // ---------- view switching ----------
  function switchView(name) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.getElementById(`view-${name}`).classList.add('active');
    document.querySelectorAll('.nav-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.view === name);
    });
    if (name === 'history') renderHistory();
    if (name === 'dashboard') renderDashboard();
    if (name === 'assets')  Assets.render();
    if (name === 'config')  ConfigUI.render();
  }

  // ---------- utils ----------
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g,
      c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  }
  function formatDate(iso) {
    const d = new Date(iso);
    return d.toLocaleDateString('pt-BR') + ' ' + d.toTimeString().slice(0, 5);
  }

  return {
    init, getSelection, setAllModules,
    log, pushBackendLogs, clearConsole, applyLogFilters,
    setProgress, resetProgress,
    renderScore, renderHistory, renderDashboard, setDashScanRange,
    openCorrectionModal, openLogModal, closeModal,
    openDiffModal, closeDiffModal,
    switchView, critClass, critLabel,
    get MODULE_ORDER() { return MODULE_ORDER; },
    get MODULE_WEIGHTS() { return MODULE_WEIGHTS; },
    get MODULE_LABELS() { return MODULE_LABELS; },
  };
})();
