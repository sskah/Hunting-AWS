/* ============================================================
   assets.js - Asset list, detail view, and admin form modal
   ============================================================ */

const Assets = (() => {
  let _currentAssetId = null;
  let _selectedScanIds = new Set();

  // ── helpers ────────────────────────────────────────────────
  function _esc(s) {
    return String(s ?? '').replace(/[&<>"']/g,
      c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  function _fmtDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('pt-BR') + ' ' + d.toTimeString().slice(0, 5);
  }

  function _critClass(score) {
    if (score >= 76) return 'crit-critical';
    if (score >= 50) return 'crit-high';
    if (score >= 25) return 'crit-medium';
    return 'crit-low';
  }

  // ── Asset List ─────────────────────────────────────────────
  function render() {
    const tbody  = document.getElementById('assets-list-tbody');
    const items  = Storage.listAssets();
    const isAdmin = Auth.isAdmin();
    const todayYmd = new Date().toISOString().slice(0, 10);

    // Show/hide admin-only column header
    document.querySelectorAll('#assets-list-view .admin-only').forEach(el => {
      el.classList.toggle('hidden', !isAdmin);
    });

    if (!items.length) {
      tbody.innerHTML = `<tr><td colspan="${isAdmin ? 6 : 5}" class="empty">nenhum asset cadastrado</td></tr>`;
      refreshScanDropdown([]);
      return;
    }

    tbody.innerHTML = '';
    for (const a of items) {
      const sched = a.scheduled_at ? a.scheduled_at.slice(0, 10) : null;
      const schedCls = !sched ? 'sched-none'
                     : sched < todayYmd ? 'sched-past'
                     : sched === todayYmd ? 'sched-today'
                     : 'sched-future';
      const isAuto = !!a.auto_enabled;
      const critClass = a.criticality ? `crit-badge ${_critClass(
        a.criticality === 'Critical' ? 100
        : a.criticality === 'High' ? 65
        : a.criticality === 'Medium' ? 35 : 10
      )}` : '';

      const tr = document.createElement('tr');
      tr.className = 'asset-row';
      tr.dataset.id = a.id;
      tr.innerHTML = `
        <td><strong class="asset-link">${_esc(a.name)}</strong></td>
        <td>${a.criticality ? `<span class="${critClass}">${_esc(a.criticality)}</span>` : '<span class="muted">—</span>'}</td>
        <td>${(a.tags || []).map(t => `<span class="tag">${_esc(t)}</span>`).join('') || '<span class="muted">—</span>'}</td>
        <td class="${schedCls}">${sched || '<span class="muted">—</span>'}</td>
        <td class="auto-cell">
          <button class="auto-toggle ${isAuto ? 'auto-on' : 'auto-off'}"
                  data-act="toggle-auto" data-id="${a.id}"
                  title="${isAuto ? 'Desativar' : 'Ativar'} hunting automatico">
            <span class="auto-dot"></span>
            <span class="auto-label">${isAuto ? 'ON' : 'OFF'}</span>
          </button>
        </td>
        ${isAdmin ? `
        <td class="admin-only">
          <div class="row-actions">
            <button data-act="edit" data-id="${a.id}">EDIT</button>
            <button data-act="del"  data-id="${a.id}" class="danger">DEL</button>
          </div>
        </td>` : ''}
      `;
      tbody.appendChild(tr);
    }
    refreshScanDropdown(items);
  }

  function refreshScanDropdown(items) {
    const sel = document.getElementById('load-asset');
    if (!sel) return;
    sel.innerHTML = '<option value="">⤓ load from assets...</option>';
    for (const a of items) {
      const opt = document.createElement('option');
      opt.value = a.id;
      opt.textContent = a.name + (a.auto_enabled ? '  [AUTO]' : '');
      sel.appendChild(opt);
    }
  }

  // ── Asset Detail ────────────────────────────────────────────
  function openDetail(assetId) {
    _currentAssetId = assetId;
    _selectedScanIds = new Set();
    const asset = Storage.getAsset(assetId);
    if (!asset) return;

    document.getElementById('assets-list-view').classList.add('hidden');
    document.getElementById('assets-detail-view').classList.remove('hidden');

    document.getElementById('detail-asset-name').textContent = asset.name;
    const critEl = document.getElementById('detail-asset-crit');
    if (asset.criticality) {
      critEl.textContent = asset.criticality;
      critEl.className = `crit-badge ${_critClass(
        asset.criticality === 'Critical' ? 100
        : asset.criticality === 'High' ? 65
        : asset.criticality === 'Medium' ? 35 : 10
      )}`;
    } else {
      critEl.textContent = '';
      critEl.className = '';
    }

    // Activate info tab
    _switchDetailTab('info');
    renderDetailInfo(asset);
  }

  function closeDetail() {
    _currentAssetId = null;
    _selectedScanIds = new Set();
    document.getElementById('assets-detail-view').classList.add('hidden');
    document.getElementById('assets-list-view').classList.remove('hidden');
  }

  function _switchDetailTab(tab) {
    document.querySelectorAll('.detail-tab').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tab);
    });
    document.querySelectorAll('.detail-tab-panel').forEach(p => {
      p.classList.add('hidden');
    });
    document.getElementById(`detail-tab-${tab}`).classList.remove('hidden');

    if (tab === 'history' && _currentAssetId) {
      const asset = Storage.getAsset(_currentAssetId);
      if (asset) renderDetailHistory(asset);
    }
    if (tab === 'safelist' && _currentAssetId) {
      const asset = Storage.getAsset(_currentAssetId);
      if (asset) renderSafelist(asset);
    }
  }

  // ── Safelist (corrected items) ─────────────────────────────
  function _moduleLabel(m) {
    return (UI.MODULE_LABELS && UI.MODULE_LABELS[m]) || m;
  }

  // Human-readable label for a finding (used in the picker + safelist list)
  function _itemLabel(mod, item) {
    if (mod === 'credentials')
      return [item.user, item.password].filter(Boolean).join(' / ') || item.url || '(credencial)';
    if (mod === 'domains')
      return item.domain || '(dominio)';
    if (mod === 'darkweb')
      return item.title || item.url || item.event_id || '(item)';
    return item.title || item.link || item.typo_variant || '(item)';
  }

  function renderSafelist(asset) {
    _populateSafelistPicker(asset);
    const corrected = Storage.listCorrected(asset.name);
    document.getElementById('safelist-count').textContent = corrected.length;

    const host = document.getElementById('safelist-current');
    if (!corrected.length) {
      host.innerHTML = '<div class="empty">nenhum item corrigido ainda</div>';
      return;
    }
    host.innerHTML = corrected.map(c => `
      <div class="safelist-item">
        <span class="safelist-mod">${_esc(_moduleLabel(c.module))}</span>
        <span class="safelist-label">${_esc(c.label)}</span>
        ${c.at ? `<span class="safelist-date">${_fmtDate(c.at)}</span>` : ''}
        <button class="safelist-remove" data-mod="${_esc(c.module)}" data-fp="${_esc(c.fp)}" title="Remover da safelist">✕</button>
      </div>
    `).join('');
  }

  function _populateSafelistPicker(asset) {
    const sel = document.getElementById('safelist-scan-picker');
    if (!sel) return;
    const scans = Storage.listScansForAsset(asset.name);
    sel.innerHTML = '<option value="">Selecione um scan para marcar itens...</option>';
    for (const s of scans) {
      // Only scans that actually stored raw results can be used to pick items
      const hasResults = s.results && Object.values(s.results).some(a => (a || []).length);
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = `${_fmtDate(s.scanned_at)} · score ${s.score}` + (hasResults ? '' : ' (sem detalhes)');
      opt.disabled = !hasResults;
      sel.appendChild(opt);
    }
  }

  function openCorrectionItemsModal(scan) {
    const modal = document.getElementById('correction-items-modal');
    const body = document.getElementById('ci-modal-body');
    document.getElementById('ci-modal-title').textContent = `MARCAR ITENS CORRIGIDOS :: ${scan.company}`;

    const results = scan.results || {};
    const already = new Set(
      Storage.listCorrected(scan.company).map(c => c.module + '|' + c.fp)
    );

    const MODULE_ORDER = UI.MODULE_ORDER;
    let sections = '';
    let anyItems = false;
    for (const mod of MODULE_ORDER) {
      const items = results[mod] || [];
      if (!items.length) continue;
      anyItems = true;
      const rows = items.map(it => {
        const fp = it._fp;
        if (!fp) return '';
        const key = mod + '|' + fp;
        const isDone = already.has(key);
        return `
          <label class="ci-item ${isDone ? 'ci-done' : ''}">
            <input type="checkbox" class="ci-check" data-mod="${_esc(mod)}" data-fp="${_esc(fp)}"
                   data-label="${_esc(_itemLabel(mod, it))}" ${isDone ? 'checked disabled' : ''}>
            <span class="ci-item-label">${_esc(_itemLabel(mod, it))}</span>
            ${isDone ? '<span class="ci-tag">ja corrigido</span>' : ''}
          </label>`;
      }).join('');
      sections += `
        <div class="ci-section">
          <h4 class="ci-section-title">${_esc(_moduleLabel(mod))} <span class="ci-count">${items.length}</span></h4>
          <div class="ci-section-items">${rows}</div>
        </div>`;
    }

    if (!anyItems) {
      body.innerHTML = `<div class="empty">Este scan nao possui itens detalhados para marcar.
        Apenas scans executados apos esta atualizacao guardam os detalhes necessarios.</div>`;
    } else {
      body.innerHTML = `
        ${sections}
        <div class="modal-action-row">
          <input type="text" id="ci-note" placeholder="nota opcional (ex: ticket de remediacao)">
          <button id="btn-ci-save" class="btn btn-primary">MARCAR COMO CORRIGIDO</button>
        </div>`;
      document.getElementById('btn-ci-save').onclick = () => {
        const entries = [];
        body.querySelectorAll('.ci-check:checked:not(:disabled)').forEach(cb => {
          entries.push({
            module: cb.dataset.mod,
            fp: cb.dataset.fp,
            label: cb.dataset.label,
          });
        });
        if (!entries.length) { alert('Selecione ao menos um item.'); return; }
        const note = document.getElementById('ci-note').value.trim();
        Storage.addCorrected(scan.company, entries, note);
        closeCorrectionItemsModal();
        const asset = Storage.getAsset(_currentAssetId);
        if (asset) renderSafelist(asset);
      };
    }

    modal.classList.remove('hidden');
  }

  function closeCorrectionItemsModal() {
    document.getElementById('correction-items-modal').classList.add('hidden');
  }

  function renderDetailInfo(asset) {
    const assetEl = document.getElementById('detail-info-asset');
    assetEl.innerHTML = `
      <div class="detail-info-grid">
        ${_infoRow('Nome', asset.name)}
        ${_infoRow('Ponto Focal', asset.focal_point)}
        ${_infoRow('Email de Contato', asset.contact_email)}
        ${_infoRow('Telefone', asset.contact_phone)}
        ${_infoRow('Criticidade', asset.criticality)}
        ${_infoRow('Tags', (asset.tags || []).map(t => `<span class="tag">${_esc(t)}</span>`).join(' ') || null, true)}
      </div>
    `;

    const scanEl = document.getElementById('detail-info-scan');
    const socialHtml = (asset.social_profiles || []).map(s => {
      const [plat, url] = s.includes(':') ? [s.split(':')[0], s.split(':').slice(1).join(':')] : [s, ''];
      return `<div class="detail-scan-item"><span class="detail-scan-label">${_esc(plat)}</span> <span class="muted">${_esc(url)}</span></div>`;
    }).join('');

    scanEl.innerHTML = `
      <div class="detail-info-grid">
        ${_listRow('Dominios / Termos', asset.terms)}
        ${_listRow('Dominios de Email', asset.email_domains)}
        ${_listRow('IPs', asset.ips)}
      </div>
      ${(asset.social_profiles || []).length ? `
        <div class="detail-section-sub">
          <span class="detail-label">Perfis Sociais Oficiais</span>
          ${socialHtml}
        </div>` : ''}
    `;
  }

  function _infoRow(label, value, raw = false) {
    const display = raw ? (value || '<span class="muted">—</span>')
                        : (value ? _esc(value) : '<span class="muted">—</span>');
    return `<div class="detail-info-row">
      <span class="detail-label">${label}</span>
      <span class="detail-value">${display}</span>
    </div>`;
  }

  function _listRow(label, arr) {
    const items = (arr || []).filter(Boolean);
    const display = items.length
      ? items.map(v => `<span class="detail-list-item">${_esc(v)}</span>`).join('')
      : '<span class="muted">—</span>';
    return `<div class="detail-info-row">
      <span class="detail-label">${label}</span>
      <div class="detail-value">${display}</div>
    </div>`;
  }

  function renderDetailHistory(asset) {
    const search   = (document.getElementById('detail-search')?.value || '').toLowerCase();
    const dateFrom = document.getElementById('detail-date-from')?.value || '';
    const dateTo   = document.getElementById('detail-date-to')?.value || '';
    const crit     = document.getElementById('detail-crit-filter')?.value || '';

    let scans = Storage.listScansForAsset(asset.name);

    if (search) {
      scans = scans.filter(s =>
        s.company.toLowerCase().includes(search) ||
        (s.terms || []).some(t => t.toLowerCase().includes(search))
      );
    }
    if (dateFrom) scans = scans.filter(s => s.scanned_at >= dateFrom);
    if (dateTo)   scans = scans.filter(s => s.scanned_at <= dateTo + 'T23:59:59');
    if (crit)     scans = scans.filter(s => s.criticality === crit);

    const tbody = document.getElementById('detail-history-tbody');
    const MODULE_ORDER = UI.MODULE_ORDER;

    if (!scans.length) {
      tbody.innerHTML = '<tr><td colspan="12" class="empty">nenhum scan encontrado</td></tr>';
      _updateDetailDlBtns();
      return;
    }

    tbody.innerHTML = '';
    for (const rec of scans) {
      const isChecked = _selectedScanIds.has(rec.id);
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><input type="checkbox" class="scan-checkbox" data-id="${rec.id}" ${isChecked ? 'checked' : ''}></td>
        ${MODULE_ORDER.map(m => `<td>${rec.counts?.[m] ?? 0}</td>`).join('')}
        <td><strong>${rec.score}</strong></td>
        <td><span class="crit-badge ${_critClass(rec.score)}">${rec.criticality}</span></td>
        <td>${_fmtDate(rec.scanned_at)}</td>
        <td>
          <div class="row-actions">
            <button data-act="edit" data-id="${rec.id}">EDIT</button>
            <button data-act="log"  data-id="${rec.id}">LOG</button>
            <button data-act="del"  data-id="${rec.id}" class="danger">DEL</button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    }
    _updateDetailDlBtns();
  }

  function _updateDetailDlBtns() {
    const hasSel = _selectedScanIds.size > 0;
    document.getElementById('btn-detail-xlsx').disabled = !hasSel;
    document.getElementById('btn-detail-pdf').disabled  = !hasSel;
    const emailBtn = document.getElementById('btn-detail-email');
    if (emailBtn) emailBtn.disabled = !hasSel;
  }

  // ── Asset Form Modal (admin) ────────────────────────────────
  function openForm(assetId = null) {
    const modal = document.getElementById('asset-form-modal');
    const title = document.getElementById('asset-form-title');
    title.textContent = assetId ? 'EDIT ASSET' : 'ADD ASSET';
    modal.dataset.editingId = assetId || '';

    const a = assetId ? Storage.getAsset(assetId) : null;
    document.getElementById('af-name').value         = a?.name || '';
    document.getElementById('af-focal').value        = a?.focal_point || '';
    document.getElementById('af-email').value        = a?.contact_email || '';
    document.getElementById('af-phone').value        = a?.contact_phone || '';
    document.getElementById('af-criticality').value  = a?.criticality || '';
    document.getElementById('af-tags').value         = (a?.tags || []).join(', ');
    document.getElementById('af-auto-enabled').checked = !!a?.auto_enabled;
    const schedInput = document.getElementById('af-scheduled-date');
    if (schedInput) schedInput.value = (a?.scheduled_at || a?.scheduled_date || '').slice(0, 10);
    document.getElementById('af-terms').value        = (a?.terms || []).join('\n');
    document.getElementById('af-email-domains').value = (a?.email_domains || []).join('\n');
    document.getElementById('af-ips').value          = (a?.ips || []).join('\n');
    document.getElementById('af-social').value       = (a?.social_profiles || []).join('\n');

    modal.classList.remove('hidden');
  }

  function closeForm() {
    document.getElementById('asset-form-modal').classList.add('hidden');
  }

  function saveForm() {
    const name = document.getElementById('af-name').value.trim();
    if (!name) return alert('Nome do asset obrigatorio.');
    const terms = document.getElementById('af-terms').value
      .split('\n').map(s => s.trim()).filter(Boolean);
    if (!terms.length) return alert('Pelo menos um dominio/termo obrigatorio.');

    const modal = document.getElementById('asset-form-modal');
    const editingId = modal.dataset.editingId || undefined;

    Storage.saveAsset({
      id:              editingId || undefined,
      name,
      terms,
      tags:            document.getElementById('af-tags').value.split(',').map(s => s.trim()).filter(Boolean),
      focal_point:     document.getElementById('af-focal').value.trim(),
      contact_email:   document.getElementById('af-email').value.trim(),
      contact_phone:   document.getElementById('af-phone').value.trim(),
      criticality:     document.getElementById('af-criticality').value,
      email_domains:   document.getElementById('af-email-domains').value.split('\n').map(s => s.trim()).filter(Boolean),
      ips:             document.getElementById('af-ips').value.split('\n').map(s => s.trim()).filter(Boolean),
      social_profiles: document.getElementById('af-social').value.split('\n').map(s => s.trim()).filter(Boolean),
      auto_enabled:    document.getElementById('af-auto-enabled').checked,
      scheduled_date:  document.getElementById('af-scheduled-date')?.value || '',
    });

    closeForm();
    render();
  }

  // ── USE asset in scan view ─────────────────────────────────
  function useAsset(a) {
    document.getElementById('company').value = a.name;
    document.getElementById('terms').value = a.terms.join('\n');
    UI.switchView('scan');
  }

  // ── Event binding ──────────────────────────────────────────
  function bind() {
    // Add asset button (admin)
    document.getElementById('btn-add-asset').addEventListener('click', () => openForm(null));

    // Asset form modal close / cancel / save
    document.getElementById('asset-form-close').addEventListener('click', closeForm);
    document.getElementById('btn-asset-form-cancel').addEventListener('click', closeForm);
    document.getElementById('asset-form-modal').addEventListener('click', e => {
      if (e.target.id === 'asset-form-modal') closeForm();
    });
    document.getElementById('btn-asset-form-save').addEventListener('click', saveForm);

    // Back button
    document.getElementById('btn-back-assets').addEventListener('click', closeDetail);

    // Detail tabs
    document.querySelectorAll('.detail-tab').forEach(btn => {
      btn.addEventListener('click', () => _switchDetailTab(btn.dataset.tab));
    });

    // Asset list: row click → detail; action buttons
    document.getElementById('assets-list-tbody').addEventListener('click', e => {
      const btn = e.target.closest('button[data-act]');
      if (btn) {
        e.stopPropagation();
        const id  = btn.dataset.id;
        const act = btn.dataset.act;
        if (act === 'toggle-auto') {
          const result = Storage.toggleAutoEnabled(id);
          if (result?.bumped) alert(`Slot cheio — hunting reagendado para ${result.bumpedTo}.`);
          render();
          return;
        }
        const a = Storage.getAsset(id);
        if (!a) return;
        if (act === 'edit') { openForm(id); return; }
        if (act === 'del') {
          if (confirm(`Excluir asset "${a.name}"?`)) { Storage.removeAsset(id); render(); }
          return;
        }
        if (act === 'use') { useAsset(a); return; }
      }
      // Click on row (not button) → open detail
      const row = e.target.closest('tr.asset-row');
      if (row) openDetail(row.dataset.id);
    });

    // Detail history: checkboxes + action buttons + filters
    document.getElementById('detail-history-tbody').addEventListener('click', e => {
      const cb = e.target.closest('.scan-checkbox');
      if (cb) {
        const id = cb.dataset.id;
        if (cb.checked) _selectedScanIds.add(id);
        else            _selectedScanIds.delete(id);
        _updateDetailDlBtns();
        // sync select-all
        const allCbs = document.querySelectorAll('#detail-history-tbody .scan-checkbox');
        document.getElementById('detail-select-all').checked =
          allCbs.length > 0 && [...allCbs].every(c => c.checked);
        return;
      }

      const btn = e.target.closest('button[data-act]');
      if (!btn) return;
      const id  = btn.dataset.id;
      const rec = Storage.getScan(id);
      if (!rec) return;
      if (btn.dataset.act === 'edit') UI.openCorrectionModal(rec);
      if (btn.dataset.act === 'log')  UI.openLogModal(rec);
      if (btn.dataset.act === 'del') {
        if (confirm(`Excluir scan de "${rec.company}"?`)) {
          Storage.removeScan(id);
          _selectedScanIds.delete(id);
          const asset = Storage.getAsset(_currentAssetId);
          if (asset) renderDetailHistory(asset);
        }
      }
    });

    // Select-all checkbox in detail history header
    document.getElementById('detail-select-all').addEventListener('change', e => {
      const checked = e.target.checked;
      document.querySelectorAll('#detail-history-tbody .scan-checkbox').forEach(cb => {
        cb.checked = checked;
        if (checked) _selectedScanIds.add(cb.dataset.id);
        else         _selectedScanIds.delete(cb.dataset.id);
      });
      _updateDetailDlBtns();
    });

    // Detail filters → re-render history
    ['detail-search','detail-date-from','detail-date-to','detail-crit-filter'].forEach(id => {
      const el = document.getElementById(id);
      el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => {
        const asset = Storage.getAsset(_currentAssetId);
        if (asset) renderDetailHistory(asset);
      });
    });

    // Detail download buttons
    document.getElementById('btn-detail-xlsx').addEventListener('click', async () => {
      for (const scanId of _selectedScanIds) {
        const scan = Storage.getScan(scanId);
        if (!scan) continue;
        try {
          await API.downloadReport({
            company: scan.company,
            results: scan.results || {},
            score: { score: scan.score, criticality: scan.criticality,
                     weighted_total: scan.weighted_total, counts: scan.counts },
          });
        } catch (e) { alert('XLSX export falhou: ' + e.message); }
      }
    });

    document.getElementById('btn-detail-pdf').addEventListener('click', async () => {
      for (const scanId of _selectedScanIds) {
        const scan = Storage.getScan(scanId);
        if (!scan) continue;
        try {
          await API.downloadPdf({
            company: scan.company,
            results: scan.results || {},
            score: { score: scan.score, criticality: scan.criticality,
                     weighted_total: scan.weighted_total, counts: scan.counts },
          });
        } catch (e) { alert('PDF export falhou: ' + e.message); }
      }
    });

    const btnDetailEmail = document.getElementById('btn-detail-email');
    if (btnDetailEmail) {
      btnDetailEmail.addEventListener('click', async () => {
        if (!_selectedScanIds.size) return alert('Selecione ao menos um scan.');
        const to = prompt('Destinatarios do relatorio (separados por virgula):');
        if (!to) return;
        const recipients = to.split(',').map(s => s.trim()).filter(Boolean);
        if (!recipients.length) return alert('Informe ao menos um destinatario.');
        try {
          const started = await API.startEmailReport({
            scan_ids: [..._selectedScanIds],
            recipients,
            formats: ['xlsx', 'pdf'],
          });
          UI.log(`report email job queued: ${started.job_id}`, 'OK', 'report');
          let job = null;
          for (let i = 0; i < 80; i++) {
            const res = await API.getReportJob(started.job_id);
            job = res.job;
            if (!job) throw new Error('report job not found');
            if (job.status === 'succeeded') {
              UI.log('report email sent', 'OK', 'report');
              break;
            }
            if (job.status === 'failed') throw new Error(job.error || 'report job failed');
            await new Promise(resolve => setTimeout(resolve, 1500));
          }
          if (job && job.status !== 'succeeded') UI.log('report email still running; check jobs/logs later', 'WARN', 'report');
        } catch (e) {
          alert('Envio por email falhou: ' + e.message);
          UI.log('report email failed: ' + e.message, 'ERROR', 'report');
        }
      });
    }

    // ── Safelist tab events ──────────────────────────────────
    const slPicker = document.getElementById('safelist-scan-picker');
    if (slPicker) {
      slPicker.addEventListener('change', e => {
        const id = e.target.value;
        if (!id) return;
        const scan = Storage.getScan(id);
        if (scan) openCorrectionItemsModal(scan);
        e.target.value = '';
      });
    }

    document.getElementById('safelist-current').addEventListener('click', e => {
      const btn = e.target.closest('.safelist-remove');
      if (!btn) return;
      const asset = Storage.getAsset(_currentAssetId);
      if (!asset) return;
      Storage.removeCorrected(asset.name, btn.dataset.mod, btn.dataset.fp);
      renderSafelist(asset);
    });

    document.getElementById('btn-safelist-clear').addEventListener('click', () => {
      const asset = Storage.getAsset(_currentAssetId);
      if (!asset) return;
      if (!Storage.countCorrected(asset.name)) { alert('Safelist ja esta vazia.'); return; }
      if (confirm(`Limpar toda a safelist de "${asset.name}"?`)) {
        Storage.clearCorrected(asset.name);
        renderSafelist(asset);
      }
    });

    // Corrected-items modal close
    document.getElementById('ci-modal-close')
      .addEventListener('click', closeCorrectionItemsModal);
    document.getElementById('correction-items-modal').addEventListener('click', e => {
      if (e.target.id === 'correction-items-modal') closeCorrectionItemsModal();
    });

    // Correction / diff modal close (modals now live in assets view)
    document.getElementById('modal-close')
      .addEventListener('click', () => UI.closeModal());
    document.getElementById('correction-modal').addEventListener('click', e => {
      if (e.target.id === 'correction-modal') UI.closeModal();
    });
    document.getElementById('diff-modal-close')
      .addEventListener('click', () => UI.closeDiffModal());
    document.getElementById('diff-modal').addEventListener('click', e => {
      if (e.target.id === 'diff-modal') UI.closeDiffModal();
    });

    // Load-asset dropdown (scan view)
    const loadSel = document.getElementById('load-asset');
    if (loadSel) {
      loadSel.addEventListener('change', e => {
        const id = e.target.value;
        if (!id) return;
        const a = Storage.getAsset(id);
        if (a) useAsset(a);
        e.target.value = '';
      });
    }
  }

  return { render, bind, openDetail, closeDetail, openForm, renderSafelist };
})();
