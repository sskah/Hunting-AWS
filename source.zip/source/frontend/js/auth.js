/* ============================================================
   auth.js — OAuth2 generic auth client
   - Reads /api/auth/config to discover provider URLs + client_id
   - Authorization Code flow with PKCE
   - Demo mode for offline local development
   ============================================================ */

const Auth = (() => {
  const SESSION_KEY = 'reconlab.session';

  function _apiBase() {
    return (window.CTI_HUNTING_API_BASE || '').replace(/\/$/, '');
  }

  function isAuthenticated() {
    try {
      const s = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
      if (!s) return false;
      if (s.expires_at && Date.now() > s.expires_at) {
        localStorage.removeItem(SESSION_KEY);
        return false;
      }
      return true;
    } catch { return false; }
  }

  function getSession() {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); }
    catch { return null; }
  }

  function setSession(s) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(s));
  }

  function logout() {
    localStorage.removeItem(SESSION_KEY);
    window.location.href = 'login.html';
  }

  // ---------- PKCE helpers ----------
  function _base64urlEncode(bytes) {
    let s = '';
    for (const b of bytes) s += String.fromCharCode(b);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  async function _sha256(text) {
    const buf = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest('SHA-256', buf);
    return new Uint8Array(hash);
  }
  function _randomString(len = 64) {
    const arr = new Uint8Array(len);
    crypto.getRandomValues(arr);
    return _base64urlEncode(arr);
  }

  // ---------- OAuth2 Authorization Code + PKCE ----------
  async function startOAuth(provider) {
    const cfg = await _fetchAuthConfig();
    const p = cfg.providers[provider];
    if (!p || !p.client_id) {
      throw new Error(`${provider} SSO is not configured on the backend.`);
    }

    const verifier = _randomString(64);
    const challenge = _base64urlEncode(await _sha256(verifier));
    const state = _randomString(16);

    sessionStorage.setItem('reconlab.pkce_verifier', verifier);
    sessionStorage.setItem('reconlab.pkce_state', state);
    sessionStorage.setItem('reconlab.pkce_provider', provider);

    const params = new URLSearchParams({
      client_id: p.client_id,
      redirect_uri: p.redirect_uri,
      response_type: 'code',
      scope: p.scope,
      code_challenge: challenge,
      code_challenge_method: 'S256',
      state,
    });
    window.location.href = `${p.auth_endpoint}?${params.toString()}`;
  }

  /**
   * On the callback page (login.html?code=...&state=...), exchange the code
   * via the backend (avoids exposing client_secret if provider needs one).
   */
  async function completeOAuth() {
    const params = new URLSearchParams(window.location.search);
    const code  = params.get('code');
    const state = params.get('state');
    const err   = params.get('error');
    if (err) throw new Error(err);

    const expected = sessionStorage.getItem('reconlab.pkce_state');
    if (!state || state !== expected) throw new Error('state mismatch');

    const provider = sessionStorage.getItem('reconlab.pkce_provider');
    const verifier = sessionStorage.getItem('reconlab.pkce_verifier');
    if (!provider || !verifier) throw new Error('missing PKCE state');

    const r = await fetch(_apiBase() + '/api/auth/exchange', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, code, code_verifier: verifier }),
    });
    if (!r.ok) throw new Error(`token exchange failed (${r.status})`);
    const data = await r.json();

    setSession({
      provider,
      email: data.email || '',
      name: data.name || '',
      role: data.role || 'user',
      access_token: data.access_token || '',
      expires_at: data.expires_at || (Date.now() + 8 * 3600_000),
    });
    sessionStorage.removeItem('reconlab.pkce_verifier');
    sessionStorage.removeItem('reconlab.pkce_state');
    sessionStorage.removeItem('reconlab.pkce_provider');
  }

  async function _fetchAuthConfig() {
    try {
      const r = await fetch(_apiBase() + '/api/auth/config');
      if (!r.ok) throw new Error('no auth config');
      return await r.json();
    } catch {
      // Backend doesn't have auth wired (fully local dev) — fail clearly.
      throw new Error(
        'SSO not configured. Set OAuth client_id/secret in backend ' +
        'or use demo mode.'
      );
    }
  }

  function demoLogin() {
    setSession({
      provider: 'demo',
      email: 'analyst@local',
      name: 'Local Analyst',
      role: 'admin',
      access_token: 'demo-token',
      expires_at: Date.now() + 8 * 3600_000,
    });
  }

  function localUserLogin() {
    setSession({
      provider: 'local',
      email: 'viewer@local',
      name: 'Local Viewer',
      role: 'user',
      access_token: 'user-token',
      expires_at: Date.now() + 8 * 3600_000,
    });
  }

  function isAdmin() {
    const s = getSession();
    if (!s) return false;
    return s.role === 'admin';
  }

  return {
    isAuthenticated, getSession, setSession, logout,
    startOAuth, completeOAuth, demoLogin, localUserLogin, isAdmin,
  };
})();

// ---------- Auto-redirect guard for the main app ----------
// If this script is loaded inside index.html (not login.html), enforce auth.
if (location.pathname.endsWith('/') ||
    location.pathname.endsWith('/index.html')) {
  if (!Auth.isAuthenticated()) {
    location.href = 'login.html';
  }
}
