/* ============================================================
   api.js - HTTP client to the AWS API Gateway backend
   ============================================================ */

const API = (() => {
  function _base() {
    return (window.CTI_HUNTING_API_BASE || '').replace(/\/$/, '');
  }

  async function _json(method, path, body) {
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const r = await fetch(_base() + path, opts);
    if (!r.ok) {
      let detail = '';
      try { detail = (await r.json()).error || ''; } catch {}
      throw new Error(`HTTP ${r.status}${detail ? ': ' + detail : ''}`);
    }
    if (r.status === 204) return {};
    return r.json();
  }

  return {
    health() { return _json('GET', '/api/health'); },

    runOsint(payload) { return _json('POST', '/api/osint', payload); },
    startOsintJob(payload) { return _json('POST', '/api/osint/jobs', payload); },
    getOsintJob(jobId) { return _json('GET', `/api/osint/jobs/${encodeURIComponent(jobId)}`); },
    cancelOsintJob(jobId) { return _json('POST', `/api/osint/jobs/${encodeURIComponent(jobId)}/cancel`); },

    async downloadReport({ company, results, score }) {
      const r = await fetch(_base() + '/api/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ company, results, score }),
      });
      if (!r.ok) throw new Error('report failed');
      const blob = await r.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `osint_${company}_${score.criticality}.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    },

    async downloadPdf({ company, results, score }) {
      const r = await fetch(_base() + '/api/report/pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ company, results, score }),
      });
      if (!r.ok) throw new Error('pdf report failed');
      const blob = await r.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `osint_${company}_${score.criticality}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    },



    startEmailReport({ scan_ids, recipients, formats, subject, message }) {
      return _json('POST', '/api/reports/email', { scan_ids, recipients, formats, subject, message });
    },
    getReportJob(jobId) { return _json('GET', `/api/reports/jobs/${encodeURIComponent(jobId)}`); },

    recalc(counts) { return _json('POST', '/api/recalc', { counts }); },

    getConfig()      { return _json('GET',  '/api/config'); },
    getConfigFull()  { return _json('GET',  '/api/config/full'); },
    saveConfig(updates) { return _json('PUT', '/api/config', { updates }); },
    resetConfig()    { return _json('POST', '/api/config/reset'); },

    getScheduleConfig() { return _json('GET', '/api/schedule/config'); },
    saveScheduleConfig(updates) { return _json('PUT', '/api/schedule/config', updates); },
  };
})();
