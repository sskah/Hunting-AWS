/* ============================================================
   storage.js - DynamoDB-backed storage via API Gateway
   LocalStorage remains only as an offline/dev fallback.
   ============================================================ */

const Storage = (() => {
  const KEY_SCANS = 'reconlab.scans.v2.fallback';
  const KEY_ASSETS = 'reconlab.assets.v1.fallback';
  const KEY_SCHED_CONFIG = 'reconlab.sched.v1.fallback';
  const KEY_SAFELIST = 'reconlab.safelist.v1.fallback';
  const RESCAN_DAYS = 90;
  const SCHED_DEFAULTS = { intervalDays: 5, maxPerDay: 3 };

  function _apiBase() {
    return (window.CTI_HUNTING_API_BASE || '').replace(/\/$/, '');
  }

  function _req(method, path, body) {
    const xhr = new XMLHttpRequest();
    xhr.open(method, _apiBase() + path, false);
    xhr.setRequestHeader('Content-Type', 'application/json');
    try {
      xhr.send(body === undefined ? null : JSON.stringify(body));
      if (xhr.status >= 200 && xhr.status < 300) {
        return xhr.responseText ? JSON.parse(xhr.responseText) : {};
      }
      throw new Error(`HTTP ${xhr.status}: ${xhr.responseText || ''}`);
    } catch (e) {
      console.warn('[Storage] API unavailable, using local fallback:', e.message);
      throw e;
    }
  }

  function _load(key) {
    try { return JSON.parse(localStorage.getItem(key)) || []; }
    catch { return []; }
  }
  function _save(key, arr) { localStorage.setItem(key, JSON.stringify(arr)); }

  function _localSaveScan(payload) {
    const arr = _load(KEY_SCANS);
    const now = new Date();
    const next = new Date(now);
    next.setDate(next.getDate() + RESCAN_DAYS);
    const record = {
      id: 'scan_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
      company: payload.company,
      terms: payload.terms,
      counts: payload.counts,
      original_counts: { ...payload.counts },
      results: payload.results || {},
      score: payload.score,
      criticality: payload.criticality,
      weighted_total: payload.weighted_total,
      logs: payload.logs || [],
      scanned_at: now.toISOString(),
      next_scan_at: next.toISOString(),
      corrections: [],
    };
    arr.push(record);
    _save(KEY_SCANS, arr);
    return record;
  }

  function _assetPath(assetName) {
    return '/api/safelist/' + encodeURIComponent(assetName || '');
  }

  return {
    // ========== SCANS ==========
    listScans() {
      try { return (_req('GET', '/api/scans').items || []).sort((a, b) => b.score - a.score); }
      catch { return _load(KEY_SCANS).sort((a, b) => b.score - a.score); }
    },

    getScan(id) {
      try { return (_req('GET', `/api/scans/${encodeURIComponent(id)}`).record) || null; }
      catch { return _load(KEY_SCANS).find(x => x.id === id) || null; }
    },

    saveScan(payload) {
      try { return (_req('POST', '/api/scans', payload).record); }
      catch { return _localSaveScan(payload); }
    },

    applyCorrection(id, newCounts, newScoreData, note = '') {
      try {
        return (_req('PUT', `/api/scans/${encodeURIComponent(id)}/correction`, {
          counts: newCounts,
          score: newScoreData,
          note,
        }).record) || null;
      } catch {
        const arr = _load(KEY_SCANS);
        const rec = arr.find(x => x.id === id);
        if (!rec) return null;
        rec.corrections.push({
          at: new Date().toISOString(),
          old_counts: { ...rec.counts },
          new_counts: { ...newCounts },
          old_score: rec.score,
          new_score: newScoreData.score,
          note,
        });
        rec.counts = { ...newCounts };
        rec.score = newScoreData.score;
        rec.criticality = newScoreData.criticality;
        rec.weighted_total = newScoreData.weighted_total;
        _save(KEY_SCANS, arr);
        return rec;
      }
    },

    removeScan(id) {
      try { _req('DELETE', `/api/scans/${encodeURIComponent(id)}`); }
      catch { _save(KEY_SCANS, _load(KEY_SCANS).filter(x => x.id !== id)); }
    },

    clearScans() {
      try { _req('DELETE', '/api/scans'); }
      catch { _save(KEY_SCANS, []); }
    },

    // ========== SCHEDULING CONFIG ==========
    getSchedConfig() {
      try { return { ...SCHED_DEFAULTS, ..._req('GET', '/api/schedule/config') }; }
      catch {
        try { return { ...SCHED_DEFAULTS, ...JSON.parse(localStorage.getItem(KEY_SCHED_CONFIG)) }; }
        catch { return { ...SCHED_DEFAULTS }; }
      }
    },

    saveSchedConfig(cfg) {
      try { return _req('PUT', '/api/schedule/config', cfg); }
      catch {
        const merged = { ...this.getSchedConfig(), ...cfg };
        localStorage.setItem(KEY_SCHED_CONFIG, JSON.stringify(merged));
        return merged;
      }
    },

    // ========== ASSETS ==========
    listAssets() {
      try { return (_req('GET', '/api/assets').items || []); }
      catch {
        return _load(KEY_ASSETS).sort((a, b) => {
          const da = a.scheduled_at || '9999';
          const db = b.scheduled_at || '9999';
          return da < db ? -1 : da > db ? 1 : a.name.localeCompare(b.name);
        });
      }
    },

    getAsset(id) {
      try { return (_req('GET', `/api/assets/${encodeURIComponent(id)}`).record) || null; }
      catch { return _load(KEY_ASSETS).find(x => x.id === id) || null; }
    },

    nextAvailableSlot(desiredYmd, ignoreId = null) {
      try {
        const q = desiredYmd ? `?desired=${encodeURIComponent(desiredYmd)}` : '';
        return _req('GET', '/api/schedule/next' + q);
      } catch {
        const MAX = this.getSchedConfig().maxPerDay;
        const arr = _load(KEY_ASSETS).filter(x =>
          x.id !== ignoreId && x.scheduled_at && x.auto_enabled === true);
        const counts = {};
        for (const a of arr) {
          const ymd = (a.scheduled_at || '').slice(0, 10);
          if (!ymd) continue;
          counts[ymd] = (counts[ymd] || 0) + 1;
        }
        let cur = desiredYmd
          ? new Date(desiredYmd + 'T00:00:00Z')
          : new Date(new Date().toISOString().slice(0,10) + 'T00:00:00Z');
        for (let i = 0; i < 365; i++) {
          const ymd = cur.toISOString().slice(0, 10);
          if ((counts[ymd] || 0) < MAX) return { ymd, bumped: !!(desiredYmd && ymd !== desiredYmd) };
          cur.setUTCDate(cur.getUTCDate() + 1);
        }
        return { ymd: desiredYmd || cur.toISOString().slice(0,10), bumped: false };
      }
    },

    nextAutoScheduledDate(ignoreId = null) {
      const { intervalDays } = this.getSchedConfig();
      const arr = this.listAssets().filter(x => x.id !== ignoreId && x.scheduled_at);
      let candidateYmd;
      if (!arr.length) {
        const d = new Date();
        d.setUTCDate(d.getUTCDate() + 1);
        candidateYmd = d.toISOString().slice(0, 10);
      } else {
        const latestYmd = arr.reduce((max, a) => {
          const ymd = a.scheduled_at.slice(0, 10);
          return ymd > max ? ymd : max;
        }, '');
        const d = new Date(latestYmd + 'T00:00:00Z');
        d.setUTCDate(d.getUTCDate() + intervalDays);
        candidateYmd = d.toISOString().slice(0, 10);
      }
      return this.nextAvailableSlot(candidateYmd, ignoreId).ymd;
    },

    scheduleByDay() {
      const counts = {};
      for (const a of this.listAssets()) {
        if (!a.scheduled_at) continue;
        const ymd = a.scheduled_at.slice(0, 10);
        if (!counts[ymd]) counts[ymd] = { enabled: 0, disabled: 0 };
        if (a.auto_enabled) counts[ymd].enabled += 1;
        else                counts[ymd].disabled += 1;
      }
      return counts;
    },

    toggleAutoEnabled(id) {
      try { return _req('POST', `/api/assets/${encodeURIComponent(id)}/toggle-auto`); }
      catch {
        const arr = _load(KEY_ASSETS);
        const idx = arr.findIndex(x => x.id === id);
        if (idx < 0) return null;
        const a = arr[idx];
        const willEnable = !a.auto_enabled;
        let bumped = false;
        let bumpedTo = null;
        if (willEnable && a.scheduled_at) {
          const ymd = a.scheduled_at.slice(0, 10);
          const slot = this.nextAvailableSlot(ymd, id);
          if (slot.ymd !== ymd) { a.scheduled_at = slot.ymd + 'T00:00:00Z'; bumped = true; bumpedTo = slot.ymd; }
        }
        a.auto_enabled = willEnable;
        a.updated_at = new Date().toISOString();
        arr[idx] = a;
        _save(KEY_ASSETS, arr);
        return { record: a, bumped, bumpedTo };
      }
    },

    saveAsset(payload) {
      try {
        const path = payload.id ? `/api/assets/${encodeURIComponent(payload.id)}` : '/api/assets';
        const method = payload.id ? 'PUT' : 'POST';
        return _req(method, path, payload);
      } catch {
        const arr = _load(KEY_ASSETS);
        const autoEnabled = payload.auto_enabled === true;
        const fields = {
          name: payload.name,
          terms: payload.terms || [],
          tags: payload.tags || [],
          focal_point: payload.focal_point || '',
          contact_email: payload.contact_email || '',
          contact_phone: payload.contact_phone || '',
          criticality: payload.criticality || '',
          email_domains: payload.email_domains || [],
          ips: payload.ips || [],
          social_profiles: payload.social_profiles || [],
          auto_enabled: autoEnabled,
        };
        if (payload.id) {
          const idx = arr.findIndex(x => x.id === payload.id);
          if (idx >= 0) {
            arr[idx] = { ...arr[idx], ...fields, scheduled_at: payload.scheduled_date ? payload.scheduled_date + 'T00:00:00Z' : arr[idx].scheduled_at, updated_at: new Date().toISOString() };
            _save(KEY_ASSETS, arr);
            return { record: arr[idx] };
          }
        }
        const ymd = payload.scheduled_date || this.nextAutoScheduledDate(null);
        const rec = { id: 'asset_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8), ...fields, scheduled_at: ymd + 'T00:00:00Z', created_at: new Date().toISOString() };
        arr.push(rec);
        _save(KEY_ASSETS, arr);
        return { record: rec };
      }
    },

    removeAsset(id) {
      try { _req('DELETE', `/api/assets/${encodeURIComponent(id)}`); }
      catch { _save(KEY_ASSETS, _load(KEY_ASSETS).filter(x => x.id !== id)); }
    },

    listScansForAsset(assetName) {
      return this.listScans()
        .filter(s => (s.company || '').toLowerCase() === (assetName || '').toLowerCase())
        .sort((a, b) => new Date(b.scanned_at) - new Date(a.scanned_at));
    },

    latestScanPerAsset() {
      const scans = this.listScans().sort((a, b) => new Date(b.scanned_at) - new Date(a.scanned_at));
      const seen = new Set();
      const out = [];
      for (const s of scans) {
        const key = (s.company || '').toLowerCase();
        if (!seen.has(key)) { seen.add(key); out.push(s); }
      }
      return out.sort((a, b) => b.score - a.score);
    },

    // ========== SAFELIST ==========
    _loadSafelist() {
      try { return JSON.parse(localStorage.getItem(KEY_SAFELIST)) || {}; }
      catch { return {}; }
    },
    _saveSafelist(obj) { localStorage.setItem(KEY_SAFELIST, JSON.stringify(obj)); },

    getSafelist(assetName) {
      try { return (_req('GET', _assetPath(assetName)).corrected) || {}; }
      catch {
        const all = this._loadSafelist();
        return all[(assetName || '').toLowerCase()] || {};
      }
    },

    listCorrected(assetName) {
      const node = this.getSafelist(assetName);
      if (!node) return [];
      const out = [];
      for (const [mod, items] of Object.entries(node)) {
        for (const it of (items || [])) {
          if (typeof it === 'string') out.push({ module: mod, fp: it, label: it, at: null, note: '' });
          else out.push({ module: mod, fp: it.fp, label: it.label || it.fp, at: it.at || null, note: it.note || '' });
        }
      }
      return out.sort((a, b) => (b.at || '').localeCompare(a.at || ''));
    },

    safelistForBackend(assetName) {
      const node = this.getSafelist(assetName);
      const out = {};
      for (const [mod, items] of Object.entries(node)) {
        out[mod] = (items || []).map(it => typeof it === 'string' ? it : it.fp);
      }
      return out;
    },

    addCorrected(assetName, entries, note = '') {
      try { return (_req('POST', _assetPath(assetName), { entries, note }).corrected) || {}; }
      catch {
        const all = this._loadSafelist();
        const key = (assetName || '').toLowerCase();
        const node = all[key] || {};
        const now = new Date().toISOString();
        for (const e of entries) {
          if (!e.module || !e.fp) continue;
          const arr = node[e.module] || [];
          if (!arr.some(x => (typeof x === 'string' ? x : x.fp) === e.fp)) arr.push({ fp: e.fp, label: e.label || e.fp, note: e.note || note, at: now });
          node[e.module] = arr;
        }
        all[key] = node;
        this._saveSafelist(all);
        return node;
      }
    },

    removeCorrected(assetName, mod, fp) {
      try { _req('DELETE', `${_assetPath(assetName)}/${encodeURIComponent(mod)}/${encodeURIComponent(fp)}`); }
      catch {
        const all = this._loadSafelist();
        const key = (assetName || '').toLowerCase();
        const node = all[key];
        if (!node || !node[mod]) return;
        node[mod] = node[mod].filter(x => (typeof x === 'string' ? x : x.fp) !== fp);
        if (!node[mod].length) delete node[mod];
        if (!Object.keys(node).length) delete all[key];
        else all[key] = node;
        this._saveSafelist(all);
      }
    },

    clearCorrected(assetName) {
      try { _req('DELETE', _assetPath(assetName)); }
      catch {
        const all = this._loadSafelist();
        delete all[(assetName || '').toLowerCase()];
        this._saveSafelist(all);
      }
    },

    countCorrected(assetName) { return this.listCorrected(assetName).length; },

    // ========== DASHBOARD AGGREGATIONS ==========
    topOffenders(n = 10) { return this.latestScanPerAsset().slice(0, n); },

    lowestRanking(n = 10) {
      return this.latestScanPerAsset().slice().sort((a, b) => a.score - b.score).slice(0, n);
    },

    monthlyAvgScore() {
      const scans = this.listScans();
      const byMonth = {};
      for (const s of scans) {
        const m = (s.scanned_at || '').slice(0, 7);
        if (!m) continue;
        if (!byMonth[m]) byMonth[m] = { sum: 0, count: 0 };
        byMonth[m].sum += s.score;
        byMonth[m].count += 1;
      }
      return Object.entries(byMonth)
        .map(([month, v]) => ({ month, avg: Math.round(v.sum / v.count), count: v.count }))
        .sort((a, b) => a.month.localeCompare(b.month));
    },

    scansPerDay(days = 30) {
      const scans = this.listScans();
      const counts = {};
      for (const s of scans) {
        const d = (s.scanned_at || '').slice(0, 10);
        if (d) counts[d] = (counts[d] || 0) + 1;
      }
      const out = [];
      const today = new Date();
      for (let i = days - 1; i >= 0; i--) {
        const d = new Date(today);
        d.setDate(d.getDate() - i);
        const ymd = d.toISOString().slice(0, 10);
        out.push({ day: ymd, count: counts[ymd] || 0 });
      }
      return out;
    },

    topCategories(n = 3) {
      const latest = this.latestScanPerAsset();
      const totals = {};
      for (const s of latest) {
        for (const [mod, c] of Object.entries(s.counts || {})) {
          totals[mod] = (totals[mod] || 0) + (c || 0);
        }
      }
      return Object.entries(totals)
        .map(([module, total]) => ({ module, total }))
        .sort((a, b) => b.total - a.total)
        .slice(0, n);
    },
  };
})();
