from __future__ import annotations
import base64
import json
import math
import os
import time
import traceback
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from urllib.parse import unquote
from zoneinfo import ZoneInfo

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

DDB = boto3.resource("dynamodb")
LAMBDA = boto3.client("lambda")
SCHEDULER = boto3.client("scheduler")
SECRETS = boto3.client("secretsmanager")

TABLE_ASSETS = os.getenv("CTI_HUNTING_ASSETS_TABLE", "cti_hunting_assets")
TABLE_SCANS = os.getenv("CTI_HUNTING_SCANS_TABLE", "cti_hunting_scans")
TABLE_SAFELIST = os.getenv("CTI_HUNTING_SAFELIST_TABLE", "cti_hunting_safelist")
TABLE_CONFIG = os.getenv("CTI_HUNTING_CONFIG_TABLE", "cti_hunting_config")
TABLE_JOBS = os.getenv("CTI_HUNTING_JOBS_TABLE", "cti_hunting_jobs")
SECRETS_NAME = os.getenv("CTI_HUNTING_SECRETS_NAME", "cti_hunting_secrets")
ASSETS_SCHEDULE_INDEX = os.getenv("CTI_HUNTING_ASSETS_SCHEDULE_INDEX", "schedule-index")
SCANS_COMPANY_INDEX = os.getenv("CTI_HUNTING_SCANS_COMPANY_INDEX", "company-index")
JOB_TTL_DAYS = int(os.getenv("CTI_HUNTING_JOB_TTL_DAYS", "7"))
RESCAN_DAYS = int(os.getenv("CTI_HUNTING_RESCAN_DAYS", "90"))
SCHED_DEFAULTS = {"intervalDays": 5, "maxPerDay": 3}

MODULE_WEIGHTS = {
    "apks": 3,
    "code_repos": 4,
    "credentials": 5,
    "darkweb": 3,
    "domains": 2,
    "exposed_files": 4,
    "phishing": 2,
}
MODULE_SOURCES = {
    "credentials": ["IntelX"],
    "exposed_files": ["SerpAPI"],
    "code_repos": ["SerpAPI"],
    "domains": ["VirusTotal", "DomainTools", "Apura"],
    "apks": ["SerpAPI"],
    "phishing": ["DNS-Probe", "SerpAPI"],
    "darkweb": ["Apura"],
}
SECRET_KEYS = {
    "SERPAPI_KEY", "INTELX_KEY", "VIRUSTOTAL_KEY", "DOMAINTOOLS_USER",
    "DOMAINTOOLS_KEY", "APURA_KEY", "OAUTH_MICROSOFT_CLIENT_ID",
    "OAUTH_MICROSOFT_CLIENT_SECRET",
}

_tables: dict[str, Any] = {}

def table(name: str):
    if name not in _tables:
        _tables[name] = DDB.Table(name)
    return _tables[name]

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def today_ymd() -> str:
    tz = os.getenv("CTI_HUNTING_SCHEDULER_TIMEZONE", "America/Sao_Paulo")
    try:
        return datetime.now(ZoneInfo(tz)).date().isoformat()
    except Exception:
        return datetime.now(timezone.utc).date().isoformat()

def new_id(prefix: str) -> str:
    return f"{prefix}_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}"

def keyify(value: str | None) -> str:
    return (value or "").strip().lower()

def to_dynamo(value: Any) -> Any:
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {k: to_dynamo(v) for k, v in value.items()}
    if isinstance(value, list):
        return [to_dynamo(v) for v in value]
    return value

def from_dynamo(value: Any) -> Any:
    if isinstance(value, Decimal):
        return int(value) if value % 1 == 0 else float(value)
    if isinstance(value, dict):
        return {k: from_dynamo(v) for k, v in value.items()}
    if isinstance(value, list):
        return [from_dynamo(v) for v in value]
    return value

def scan_all(table_name: str) -> list[dict]:
    items, kwargs = [], {}
    while True:
        resp = table(table_name).scan(**kwargs)
        items.extend(resp.get("Items", []))
        if "LastEvaluatedKey" not in resp:
            break
        kwargs["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
    return [from_dynamo(x) for x in items]

def query_all(table_name: str, **kwargs) -> list[dict]:
    items = []
    while True:
        resp = table(table_name).query(**kwargs)
        items.extend(resp.get("Items", []))
        if "LastEvaluatedKey" not in resp:
            break
        kwargs["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
    return [from_dynamo(x) for x in items]

def body_json(event: dict) -> dict:
    raw = event.get("body")
    if event.get("isBase64Encoded") and raw:
        raw = base64.b64decode(raw).decode("utf-8")
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}

def request_info(event: dict) -> tuple[str, str, dict, dict, list[str]]:
    rc = event.get("requestContext") or {}
    http = rc.get("http") or {}
    method = (http.get("method") or event.get("httpMethod") or "GET").upper()
    path = event.get("rawPath") or event.get("path") or "/"
    idx = path.find("/api/")
    if idx >= 0:
        path = path[idx:]
    path = path.rstrip("/") or "/"
    parts = [unquote(p) for p in path.replace("/api/", "", 1).strip("/").split("/") if p]
    return method, path, event.get("queryStringParameters") or {}, body_json(event), parts

def response(status: int, payload: Any, content_type: str = "application/json; charset=utf-8", *, binary: bool = False, filename: str = "") -> dict:
    headers = {"Content-Type": content_type, "Cache-Control": "no-store"}
    if filename:
        headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    if binary:
        return {"statusCode": status, "headers": headers, "body": base64.b64encode(payload).decode("ascii"), "isBase64Encoded": True}
    body = payload if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False, default=str)
    return {"statusCode": status, "headers": headers, "body": body}

def bad_request(message: str) -> dict:
    return response(400, {"error": message})

def not_found() -> dict:
    return response(404, {"error": "not found"})

def get_config_overrides() -> dict:
    try:
        item = table(TABLE_CONFIG).get_item(Key={"key": "overrides"}).get("Item")
        return from_dynamo((item or {}).get("value", {})) or {}
    except Exception:
        return {}

def save_config_overrides(updates: dict) -> dict:
    current = get_config_overrides()
    current.update(updates or {})
    table(TABLE_CONFIG).put_item(Item=to_dynamo({"key": "overrides", "value": current, "updated_at": now_iso()}))
    return current

def reset_config_overrides() -> None:
    table(TABLE_CONFIG).delete_item(Key={"key": "overrides"})

def runtime_config() -> dict:
    cfg = {
        "MODULE_WEIGHTS": MODULE_WEIGHTS,
        "MODULE_SOURCES": MODULE_SOURCES,
        "INTELX_BASE": "https://2.intelx.io",
        "INTELX_BUCKET": "leaks.logs",
        "INTELX_DAYS_BACK": 4,
        "INTELX_MAX_RESULTS": 1000,
        "INTELX_RECORTE_WINDOW": 500,
        "APURA_BASE": "https://bttng.apura.com.br",
        "APURA_SOURCES_DARKWEB": ["Ransomware", "Forums"],
        "APURA_SOURCES_CERTSTREAM": ["CertStream"],
        "DOMAINTOOLS_BASE": "https://api.domaintools.com",
        "DOMAINTOOLS_MONITOR_ID": os.getenv("DOMAINTOOLS_MONITOR_ID", ""),
        "DOMAIN_PROBE_WORKERS": 20,
        "TYPO_MAX_VARIANTS": 500,
        "TYPO_PROBE_WORKERS": 20,
        "EXPOSED_FILES_SITES": "site:scribd.com OR site:docdroid.net OR site:slideshare.net OR site:issuu.com OR site:yumpu.com OR site:vdocuments.com OR site:atlassian.net OR site:s3.amazonaws.com OR inurl:docs.google.com OR site:pastebin.com OR site:repl.it",
        "EXPOSED_FILES_TERMS": ["confidential", "confidencial", "internal use only", "uso interno", "interno", "restricted", "password", "senha", "api_key", "apikey", "token", "secret", "BEGIN RSA PRIVATE KEY", "AKIA", "boleto", "comprovante", "CPF", "nota fiscal", "fatura", "contrato"],
        "CODE_REPO_DORKS": [
            'site:github.com "{term}" "password"', 'site:github.com "{term}" "api_key"',
            'site:github.com "{term}" "secret"', 'site:github.com "{term}" "token"',
            'site:github.com "{term}" ".env"', 'site:gitlab.com "{term}" "password"',
            'site:gitlab.com "{term}" "secret"', 'site:bitbucket.org "{term}" "credentials"',
            'site:gist.github.com "{term}"', 'site:postman.com "{term}"',
            'site:documenter.getpostman.com "{term}"', 'site:swaggerhub.com "{term}"',
            'site:pastebin.com "{term}"', 'site:trello.com "{term}" "password"',
        ],
        "OFFICIAL_REPO_PATTERNS": ["/docs/", "/documentation/", "official"],
        "APK_DORKS": ['"{term}" filetype:apk', 'site:apkpure.com "{term}"', 'site:apkmirror.com "{term}"', 'site:apkmonk.com "{term}"'],
    }
    cfg.update(get_config_overrides())
    return cfg

def load_secret_values() -> dict:
    try:
        raw = SECRETS.get_secret_value(SecretId=SECRETS_NAME).get("SecretString") or "{}"
        values = json.loads(raw) if raw.strip().startswith("{") else {}
        return values if isinstance(values, dict) else {}
    except Exception:
        return {}

def save_secret_values(updates: dict) -> dict:
    current = load_secret_values()
    current.update({k: v for k, v in (updates or {}).items() if v not in (None, "")})
    payload = json.dumps(current, ensure_ascii=False)
    try:
        SECRETS.put_secret_value(SecretId=SECRETS_NAME, SecretString=payload)
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") == "ResourceNotFoundException":
            SECRETS.create_secret(Name=SECRETS_NAME, SecretString=payload)
        else:
            raise
    return current

def safe_mask(cfg: dict) -> dict:
    out = {}
    for k, v in cfg.items():
        secretish = any(s in k for s in ("KEY", "USER", "SECRET", "TOKEN"))
        if secretish and isinstance(v, str) and v:
            out[k] = (v[:4] + "***" + v[-2:]) if len(v) > 6 else "***"
        else:
            out[k] = v
    return out

def invoke_async(function_name: str, payload: dict):
    return LAMBDA.invoke(FunctionName=function_name, InvocationType="Event", Payload=json.dumps(payload, ensure_ascii=False).encode("utf-8"))

def invoke_sync(function_name: str, payload: dict) -> dict:
    resp = LAMBDA.invoke(FunctionName=function_name, InvocationType="RequestResponse", Payload=json.dumps(payload, ensure_ascii=False).encode("utf-8"))
    raw = resp.get("Payload").read().decode("utf-8") if resp.get("Payload") else "{}"
    try:
        return json.loads(raw or "{}")
    except Exception:
        return {"ok": False, "raw": raw}

def score_from_counts(counts: dict, weights: dict) -> tuple[int, int]:
    ks = [2 * w * math.log2(1 + counts.get(m, 0)) for m, w in weights.items() if counts.get(m, 0) > 0]
    weighted_total = sum(counts.get(m, 0) * w for m, w in weights.items())
    if not ks:
        return weighted_total, 0
    base = max(ks)
    others = sum(ks) - base
    return weighted_total, min(100, round(base + 0.20 * others))

def criticality_label(score: int) -> str:
    if score <= 24:
        return "Low"
    if score <= 49:
        return "Medium"
    if score <= 75:
        return "High"
    return "Critical"

import requests

OAUTH_PROVIDERS = {
    "microsoft": {
        "auth_endpoint": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
        "token_endpoint": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        "userinfo_endpoint": "https://graph.microsoft.com/oidc/userinfo",
        "scope": "openid email profile User.Read",
    }
}

def full_config() -> dict:
    cfg = runtime_config()
    cfg.update(load_secret_values())
    if isinstance(cfg.get("ADMIN_EMAILS"), str):
        cfg["ADMIN_EMAILS"] = [x.strip() for x in cfg["ADMIN_EMAILS"].split(",") if x.strip()]
    return cfg

def auth_config() -> dict:
    cfg = full_config()
    out = {"providers": {}}
    for provider, base in OAUTH_PROVIDERS.items():
        cid = cfg.get(f"OAUTH_{provider.upper()}_CLIENT_ID", "")
        if not cid:
            continue
        redirect_uri = cfg.get("OAUTH_REDIRECT_URI") or os.getenv("CTI_HUNTING_FRONTEND_URL", "") + "/login.html"
        out["providers"][provider] = {"client_id": cid, "auth_endpoint": base["auth_endpoint"], "scope": base["scope"], "redirect_uri": redirect_uri}
    return response(200, out)

def exchange(body: dict) -> dict:
    provider = body.get("provider")
    if provider not in OAUTH_PROVIDERS:
        return bad_request("unknown provider")
    cfg = full_config()
    cid = cfg.get(f"OAUTH_{provider.upper()}_CLIENT_ID", "")
    csecret = cfg.get(f"OAUTH_{provider.upper()}_CLIENT_SECRET", "")
    if not cid:
        return bad_request(f"{provider} not configured")
    base = OAUTH_PROVIDERS[provider]
    payload = {"client_id": cid, "code": body.get("code"), "code_verifier": body.get("code_verifier"), "grant_type": "authorization_code", "redirect_uri": cfg.get("OAUTH_REDIRECT_URI") or os.getenv("CTI_HUNTING_FRONTEND_URL", "") + "/login.html"}
    if csecret:
        payload["client_secret"] = csecret
    try:
        r = requests.post(base["token_endpoint"], data=payload, timeout=30)
        r.raise_for_status()
        tok = r.json()
    except requests.RequestException as exc:
        return response(502, {"error": f"token exchange failed: {exc}"})
    email = name = ""
    try:
        u = requests.get(base["userinfo_endpoint"], headers={"Authorization": f"Bearer {tok.get('access_token', '')}"}, timeout=20)
        if u.ok:
            uj = u.json(); email = uj.get("email", ""); name = uj.get("name") or uj.get("given_name") or ""
    except requests.RequestException:
        pass
    admins = [e.strip().lower() for e in cfg.get("ADMIN_EMAILS", []) if e.strip()]
    return response(200, {"access_token": tok.get("access_token", ""), "email": email, "name": name, "role": "admin" if email.lower() in admins else "user", "expires_at": int((time.time() + tok.get("expires_in", 3600)) * 1000)})

def handle(event: dict) -> dict:
    method, path, query, body, parts = request_info(event)
    if method == "GET" and parts == ["auth", "config"]:
        return auth_config()
    if method == "POST" and parts == ["auth", "exchange"]:
        return exchange(body)
    return not_found()

def handler(event, context):
    try:
        return handle(event or {})
    except Exception as exc:
        traceback.print_exc()
        return response(500, {"error": str(exc)})
