"""
PDF Report Generator - THIRD-PARTY HUNTING OSINT Platform
----------------------------------------------------------
Generates a structured report with:
  1. Cover page  (company, date, score, criticality)
  2. Executive summary  (count table + score breakdown)
  3. Per-module findings  (top findings + MITRE ATT&CK mapping)
  4. Methodology note

Requires: fpdf2>=2.7.0  (added to requirements.txt)
"""
from __future__ import annotations
from io import BytesIO
from datetime import datetime, timezone
from fpdf import FPDF
import config as cfg_mod

# ----------------------------------------------------------------
# MITRE ATT&CK correlation table
# ----------------------------------------------------------------
MITRE: dict[str, list[tuple[str, str, str]]] = {
    "credentials": [
        ("T1078", "Valid Accounts",
         "Compromised credentials may grant initial access to corporate systems."),
        ("T1552", "Unsecured Credentials",
         "Credentials exposed in breach databases are ready for adversary reuse."),
        ("T1110", "Brute Force",
         "Exposed usernames narrow brute-force targets to known accounts."),
    ],
    "exposed_files": [
        ("T1213", "Data from Information Repositories",
         "Sensitive documents publicly indexed in document-sharing platforms."),
        ("T1530", "Data from Cloud Storage",
         "Unprotected files hosted in public S3 buckets or SaaS storage."),
    ],
    "code_repos": [
        ("T1552.001", "Credentials in Files",
         "API keys and secrets committed to public repositories."),
        ("T1195", "Supply Chain Compromise",
         "Public code may be forked and trojanised to target downstream users."),
    ],
    "domains": [
        ("T1583", "Acquire Infrastructure",
         "Threat actors register look-alike domains to support phishing campaigns."),
        ("T1584", "Compromise Infrastructure",
         "Certificate transparency reveals newly registered suspicious domains."),
    ],
    "apks": [
        ("T1476", "Deliver Malicious App via Other Means",
         "Unofficial APKs may redistribute the brand's app with injected malware."),
        ("T1426", "System Information Discovery",
         "Fake apps can harvest device and user data from victims."),
    ],
    "phishing": [
        ("T1566", "Phishing",
         "Typosquatted domains and sponsored ads are used to lure end-users."),
        ("T1434", "Internal Spearphishing",
         "Brand-impersonation sites target customers and employees."),
    ],
    "darkweb": [
        ("T1596", "Search Open Technical Databases",
         "Brand mentions on ransomware leak sites and dark-web forums."),
        ("T1589", "Gather Victim Identity Information",
         "PII and corporate data traded on underground marketplaces."),
    ],
}

MODULE_LABELS = {
    "credentials":   "Credentials",
    "exposed_files": "Exposed Files",
    "code_repos":    "Code Repos",
    "domains":       "Domain",
    "apks":          "APKs",
    "phishing":      "Phishing",
    "darkweb":       "Deep & Dark Web",
}

CRIT_COLORS = {
    "Low":      (180, 220, 180),
    "Medium":   (255, 220, 120),
    "High":     (255, 160,  60),
    "Critical": (220,  60,  60),
}


# ----------------------------------------------------------------
# PDF class
# ----------------------------------------------------------------
class _Report(FPDF):
    def __init__(self, company: str, score_data: dict):
        super().__init__()
        self.company    = company
        self.score_data = score_data
        self.set_auto_page_break(auto=True, margin=20)
        self.set_margins(20, 20, 20)

    # ---- helpers ----
    def _h(self, r, g, b):
        self.set_fill_color(r, g, b)

    def _rule(self):
        self.set_draw_color(60, 60, 60)
        self.line(20, self.get_y(), 190, self.get_y())
        self.ln(3)

    def header(self):
        if self.page_no() == 1:
            return
        self.set_font("Helvetica", "B", 8)
        self.set_text_color(120, 120, 120)
        self.cell(0, 8,
                  f"THIRD-PARTY HUNTING - {self.company} - Confidential",
                  align="R")
        self.ln(5)
        self._rule()

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "", 8)
        self.set_text_color(150, 150, 150)
        self.cell(0, 10, f"Page {self.page_no()}", align="C")

    # ---- cover ----
    def cover(self):
        self.add_page()
        self.set_fill_color(15, 15, 20)
        self.rect(0, 0, 210, 297, "F")

        score  = self.score_data["score"]
        crit   = self.score_data["criticality"]
        cr, cg, cb = CRIT_COLORS.get(crit, (200, 200, 200))

        self.set_y(60)
        self.set_font("Helvetica", "B", 28)
        self.set_text_color(255, 106, 0)
        self.cell(0, 14, "THIRD-PARTY HUNTING", align="C")
        self.ln(8)

        self.set_font("Helvetica", "", 13)
        self.set_text_color(160, 160, 170)
        self.cell(0, 8, "OSINT Intelligence Report", align="C")
        self.ln(20)

        self.set_font("Helvetica", "B", 20)
        self.set_text_color(220, 220, 220)
        self.cell(0, 12, self.company, align="C")
        self.ln(14)

        # score badge
        self.set_fill_color(cr, cg, cb)
        self.set_text_color(20, 20, 20)
        self.set_font("Helvetica", "B", 42)
        self.cell(0, 24, f"{score} / 100", align="C", fill=True)
        self.ln(6)
        self.set_font("Helvetica", "B", 16)
        self.cell(0, 10, crit.upper(), align="C")
        self.ln(24)

        self.set_font("Helvetica", "", 10)
        self.set_text_color(120, 120, 130)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        self.cell(0, 6, f"Generated: {ts}", align="C")
        self.ln(4)
        self.cell(0, 6,
                  "CONFIDENTIAL - For internal use only", align="C")

    # ---- summary ----
    def summary(self):
        self.add_page()
        cfg     = cfg_mod.load()
        weights = cfg["MODULE_WEIGHTS"]
        counts  = self.score_data["counts"]

        self.set_font("Helvetica", "B", 16)
        self.set_text_color(255, 106, 0)
        self.cell(0, 12, "Executive Summary", ln=True)
        self._rule()
        self.ln(2)

        # findings table
        self.set_font("Helvetica", "B", 9)
        self.set_fill_color(30, 30, 35)
        self.set_text_color(255, 255, 255)
        for hdr, w in (("Module", 70), ("Weight", 25),
                       ("Findings", 30), ("Weighted", 30)):
            self.cell(w, 8, hdr, border=1, fill=True)
        self.ln()

        row_colors = [(40, 40, 45), (50, 50, 58)]
        for i, mod in enumerate(weights):
            cnt = counts.get(mod, 0)
            self.set_fill_color(*row_colors[i % 2])
            self.set_text_color(200, 200, 210)
            self.set_font("Helvetica", "", 9)
            self.cell(70, 7, MODULE_LABELS.get(mod, mod), border=1, fill=True)
            self.cell(25, 7, str(weights[mod]),            border=1, fill=True,
                      align="C")
            self.cell(30, 7, str(cnt),                     border=1, fill=True,
                      align="C")
            self.cell(30, 7, str(cnt * weights[mod]),      border=1, fill=True,
                      align="C")
            self.ln()

        # totals
        self.set_font("Helvetica", "B", 9)
        self.set_fill_color(20, 20, 24)
        self.set_text_color(255, 106, 0)
        self.cell(70, 8, "TOTAL",                              border=1, fill=True)
        self.cell(25, 8, "",                                   border=1, fill=True)
        self.cell(30, 8, str(sum(counts.values())),            border=1, fill=True,
                  align="C")
        self.cell(30, 8, str(self.score_data["weighted_total"]), border=1,
                  fill=True, align="C")
        self.ln(14)

        # risk description
        crit  = self.score_data["criticality"]
        descs = {
            "Low":      "Low exposure detected. Monitor periodically.",
            "Medium":   "Moderate exposure. Remediation recommended within 30 days.",
            "High":     "High exposure. Immediate review and remediation required.",
            "Critical": "Critical exposure. Emergency response required.",
        }
        cr, cg, cb = CRIT_COLORS.get(crit, (200, 200, 200))
        self.set_fill_color(cr, cg, cb)
        self.set_text_color(20, 20, 20)
        self.set_font("Helvetica", "B", 10)
        self.cell(0, 10, f"  Risk Level: {crit} - {descs.get(crit, '')}",
                  fill=True, ln=True)

    # ---- per-module page ----
    def module_page(self, mod: str, items: list):
        self.add_page()
        label   = MODULE_LABELS.get(mod, mod)
        count   = len(items)
        attacks = MITRE.get(mod, [])

        self.set_font("Helvetica", "B", 14)
        self.set_text_color(255, 106, 0)
        self.cell(0, 10, f"{label}  ({count} finding{'s' if count != 1 else ''})",
                  ln=True)
        self._rule()

        # MITRE ATT&CK mapping
        if attacks:
            self.set_font("Helvetica", "B", 9)
            self.set_text_color(180, 180, 190)
            self.cell(0, 6, "MITRE ATT&CK Relevance:", ln=True)
            self.ln(1)
            for tid, tname, tdesc in attacks:
                self.set_fill_color(25, 25, 32)
                self.set_text_color(255, 106, 0)
                self.set_font("Helvetica", "B", 8)
                self.cell(22, 6, tid, border=0, fill=True)
                self.set_text_color(220, 220, 230)
                self.set_font("Helvetica", "B", 8)
                self.cell(48, 6, tname, border=0, fill=True)
                self.set_font("Helvetica", "", 8)
                self.cell(0, 6, tdesc, border=0, fill=True, ln=True)
            self.ln(4)

        if not items:
            self.set_font("Helvetica", "I", 9)
            self.set_text_color(120, 120, 130)
            self.cell(0, 8, "No findings.", ln=True)
            return

        # findings (top 20 per module to keep report concise)
        self.set_font("Helvetica", "B", 8)
        self.set_fill_color(30, 30, 38)
        self.set_text_color(200, 200, 210)

        # columns per module
        col_cfgs = {
            "credentials":   [("Category", 25), ("User", 60), ("URL", 65), ("Source", 25)],
            "exposed_files": [("Term Searched", 40), ("Title", 80), ("Link", 55)],
            "code_repos":    [("Platform", 28), ("Title", 70), ("Link", 77)],
            "domains":       [("Domain", 75), ("Type", 30), ("Source", 30), ("Last Analysis", 40)],
            "apks":          [("Store", 28), ("Title", 75), ("Link", 72)],
            "phishing":      [("Detection", 28), ("Variant", 50), ("Link", 97)],
            "darkweb":       [("Source Name", 35), ("Title", 75), ("Timestamp", 35), ("Snippet", 30)],
        }
        field_cfgs = {
            "credentials":   ["category", "user", "url", "source"],
            "exposed_files": ["term_searched", "title", "link"],
            "code_repos":    ["platform", "title", "link"],
            "domains":       ["domain", "type", "source", "last_analysis"],
            "apks":          ["store", "title", "link"],
            "phishing":      ["detection_type", "typo_variant", "link"],
            "darkweb":       ["source_name", "title", "timestamp", "snippet"],
        }

        cols   = col_cfgs.get(mod, [("Value", 175)])
        fields = field_cfgs.get(mod, ["title"])

        for hdr, w in cols:
            self.cell(w, 7, hdr, border=1, fill=True)
        self.ln()

        row_colors = [(40, 40, 45), (50, 50, 58)]
        priority_color = (80, 20, 20)

        for i, item in enumerate(items[:20]):
            is_priority = item.get("priority") and mod == "credentials"
            fill_rgb = priority_color if is_priority else row_colors[i % 2]
            self.set_fill_color(*fill_rgb)
            self.set_text_color(220, 220, 230)
            self.set_font("Helvetica", "BI" if is_priority else "", 7)
            for (_, w), field in zip(cols, fields):
                val = str(item.get(field, ""))[:80]
                self.cell(w, 6, val, border=1, fill=True)
            self.ln()

        if len(items) > 20:
            self.set_font("Helvetica", "I", 8)
            self.set_text_color(150, 150, 160)
            self.ln(2)
            self.cell(0, 6,
                      f"... and {len(items) - 20} more findings. "
                      "See the XLSX export for the complete list.",
                      ln=True)

    # ---- methodology ----
    def methodology(self):
        self.add_page()
        self.set_font("Helvetica", "B", 14)
        self.set_text_color(255, 106, 0)
        self.cell(0, 10, "Methodology & Scoring", ln=True)
        self._rule()

        paras = [
            ("Data Collection",
             "Findings are gathered passively via IntelX (credential leaks), "
             "SerpAPI (Google dorking for exposed files, code repos and APKs), "
             "VirusTotal / DomainTools / Apura (domain enumeration and certificate "
             "transparency), and DNS resolution (typosquatting detection)."),
            ("Scoring Formula",
             "Each module contributes K = 2 x weight x log2(1 + count). "
             "The final score is: max(K) + 0.20 x SUM(remaining K), capped at 100. "
             "The dominant module sets the base; others add a 20% breadth signal "
             "to avoid inflating single-module scenarios."),
            ("Criticality Bands",
             "0-24 = Low  |  25-49 = Medium  |  50-75 = High  |  76-100 = Critical"),
            ("Credential Priority",
             "A credential is flagged as PRIORITY (highlighted in red in the XLSX) "
             "when it is: corporate (user field contains the target domain), "
             "has a non-empty password, and was collected in the current calendar year."),
            ("MITRE ATT&CK",
             "Technique IDs are mapped from finding types to the MITRE ATT&CK "
             "Enterprise framework (https://attack.mitre.org). They indicate "
             "adversary techniques that the exposed data could enable, not confirmed "
             "active attacks."),
        ]

        for title, body in paras:
            self.set_font("Helvetica", "B", 10)
            self.set_text_color(200, 200, 215)
            self.cell(0, 8, title, ln=True)
            self.set_font("Helvetica", "", 9)
            self.set_text_color(150, 150, 165)
            self.multi_cell(0, 5, body)
            self.ln(4)


# ----------------------------------------------------------------
# Public entry point
# ----------------------------------------------------------------
def build_pdf(company: str, results: dict, score_data: dict) -> bytes:
    rpt = _Report(company, score_data)
    rpt.cover()
    rpt.summary()

    cfg     = cfg_mod.load()
    weights = cfg["MODULE_WEIGHTS"]
    for mod in weights:
        items = results.get(mod, [])
        if items or True:            # always render the page even if empty
            rpt.module_page(mod, items)

    rpt.methodology()

    buf = BytesIO()
    rpt.output(buf)
    buf.seek(0)
    return buf.getvalue()
