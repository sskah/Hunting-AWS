from __future__ import annotations
import base64
import json
import math
import os
import smtplib
import sys
import time
import traceback
import types
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from email.message import EmailMessage
from io import BytesIO
from typing import Any

import boto3
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

DDB = boto3.resource("dynamodb")
SES = boto3.client("ses")
TABLE_SCANS = os.getenv("CTI_HUNTING_SCANS_TABLE", "cti_hunting_scans")
TABLE_JOBS = os.getenv("CTI_HUNTING_JOBS_TABLE", "cti_hunting_jobs")
SECRETS_NAME = os.getenv("CTI_HUNTING_SECRETS_NAME", "cti_hunting_secrets")
MODULE_WEIGHTS = {"apks": 3, "code_repos": 4, "credentials": 5, "darkweb": 3, "domains": 2, "exposed_files": 4, "phishing": 2}

def _config_load():
    return {"MODULE_WEIGHTS": MODULE_WEIGHTS}
config_mod = types.ModuleType("config")
config_mod.load = _config_load
sys.modules["config"] = config_mod
from report_pdf import build_pdf

def now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def to_dynamo(value: Any) -> Any:
    if isinstance(value, float): return Decimal(str(value))
    if isinstance(value, dict): return {k: to_dynamo(v) for k, v in value.items()}
    if isinstance(value, list): return [to_dynamo(v) for v in value]
    return value

def from_dynamo(value: Any) -> Any:
    if isinstance(value, Decimal): return int(value) if value % 1 == 0 else float(value)
    if isinstance(value, dict): return {k: from_dynamo(v) for k, v in value.items()}
    if isinstance(value, list): return [from_dynamo(v) for v in value]
    return value

def table(name: str): return DDB.Table(name)

def get_scan(scan_id: str) -> dict | None:
    item = table(TABLE_SCANS).get_item(Key={"id": scan_id}).get("Item")
    return from_dynamo(item) if item else None

def get_job(job_id: str) -> dict | None:
    item = table(TABLE_JOBS).get_item(Key={"id": job_id}).get("Item")
    return from_dynamo(item) if item else None

def update_job(job_id: str, **updates):
    names, values, sets = {}, {}, []
    for i, (k, v) in enumerate(updates.items()):
        names[f"#k{i}"] = k; values[f":v{i}"] = to_dynamo(v); sets.append(f"#k{i}=:v{i}")
    names["#u"] = "updated_at"; values[":u"] = now_iso(); sets.append("#u=:u")
    table(TABLE_JOBS).update_item(Key={"id": job_id}, UpdateExpression="SET " + ", ".join(sets), ExpressionAttributeNames=names, ExpressionAttributeValues=values)

def criticality_color(score: int) -> str:
    if score <= 24: return "FFE5CC"
    if score <= 49: return "FFB266"
    if score <= 75: return "FF8000"
    return "B34700"

SHEET_CONFIG = {
    "credentials": {"title": "1. Credentials", "headers": ["Term", "Category", "Priority", "URL", "User", "Password", "Extra", "Source File", "IntelX URL", "Fonte Consultada"], "fields": ["term", "category", "priority", "url", "user", "password", "extra", "source_file", "intelx_url", "source"]},
    "exposed_files": {"title": "2. Exposed Files", "headers": ["Term", "Termo Consultado", "Title", "Link", "Snippet", "Fonte Consultada"], "fields": ["term", "term_searched", "title", "link", "snippet", "source"]},
    "code_repos": {"title": "3. Code Repos", "headers": ["Term", "Platform", "Title", "Link", "Snippet", "Fonte Consultada"], "fields": ["term", "platform", "title", "link", "snippet", "source"]},
    "domains": {"title": "4. Domains", "headers": ["Term", "Domain", "Type", "Last Analysis", "Reputation", "Fonte Consultada"], "fields": ["term", "domain", "type", "last_analysis", "reputation", "source"]},
    "apks": {"title": "5. APKs", "headers": ["Term", "Store", "Title", "Link", "Snippet", "Fonte Consultada"], "fields": ["term", "store", "title", "link", "snippet", "source"]},
    "phishing": {"title": "6. Phishing", "headers": ["Term", "Detection", "Typo Variant", "Title", "Link", "Snippet", "Fonte Consultada"], "fields": ["term", "detection_type", "typo_variant", "title", "link", "snippet", "source"]},
    "darkweb": {"title": "7. Deep & Dark Web", "headers": ["Term", "Source Name", "Title", "Snippet", "URL", "Timestamp", "Event ID", "Fonte Consultada"], "fields": ["term", "source_name", "title", "snippet", "url", "timestamp", "event_id", "source"]},
}

def build_excel(company: str, results: dict, score_data: dict) -> bytes:
    wb = Workbook(); wb.remove(wb.active)
    header_font = Font(bold=True, color="FFFFFF", name="Consolas"); header_fill = PatternFill("solid", fgColor="1A1A1A")
    thin = Side(style="thin", color="333333"); border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for mod_key, cfg in SHEET_CONFIG.items():
        ws = wb.create_sheet(cfg["title"]); ws.append(cfg["headers"])
        for cell in ws[1]: cell.font = header_font; cell.fill = header_fill; cell.alignment = Alignment(horizontal="left", vertical="center"); cell.border = border
        for item in results.get(mod_key, []): ws.append([item.get(f, "") for f in cfg["fields"]])
        for col_idx, header in enumerate(cfg["headers"], 1):
            lens = [len(str(item.get(cfg["fields"][col_idx-1], ""))) for item in results.get(mod_key, [])]
            ws.column_dimensions[get_column_letter(col_idx)].width = min(max([len(str(header))] + lens + [10]) + 2, 80)
    ws = wb.create_sheet("Score")
    headers = ["Company", "Date"] + [SHEET_CONFIG[m]["title"] for m in MODULE_WEIGHTS] + ["Weighted Sum", "Score", "Criticality"]
    ws.append(headers)
    for cell in ws[1]: cell.font = header_font; cell.fill = header_fill; cell.border = border
    counts = score_data.get("counts", {})
    ws.append([company, datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), *[counts.get(m, 0) for m in MODULE_WEIGHTS], score_data.get("weighted_total", 0), score_data.get("score", 0), score_data.get("criticality", "")])
    crit_cell = ws.cell(row=2, column=len(headers)); crit_cell.fill = PatternFill("solid", fgColor=criticality_color(int(score_data.get("score", 0)))); crit_cell.font = Font(bold=True, color="000000")
    for col_idx in range(1, len(headers) + 1): ws.column_dimensions[get_column_letter(col_idx)].width = 18
    buf = BytesIO(); wb.save(buf); return buf.getvalue()

def render(payload: dict, fmt: str) -> dict:
    company = payload.get("company", "Unknown")
    results = payload.get("results", {}) or {}
    score = payload.get("score", {}) or {}
    if isinstance(score, int): score = {"score": score, "criticality": payload.get("criticality", ""), "weighted_total": payload.get("weighted_total", 0), "counts": payload.get("counts", {})}
    if fmt == "pdf":
        data = build_pdf(company, results, score); ct = "application/pdf"; ext = "pdf"
    else:
        data = build_excel(company, results, score); ct = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; ext = "xlsx"
    return {"ok": True, "content_type": ct, "filename": f"osint_{company}_{score.get('criticality', 'report')}.{ext}", "body_base64": base64.b64encode(data).decode("ascii")}

def scan_to_payload(scan: dict) -> dict:
    return {"company": scan.get("company", "Unknown"), "results": scan.get("results", {}), "score": {"score": scan.get("score", 0), "criticality": scan.get("criticality", ""), "weighted_total": scan.get("weighted_total", 0), "counts": scan.get("counts", {})}}

def send_email_job(job_id: str) -> dict:
    job = get_job(job_id)
    if not job: return {"ok": False, "error": "job not found"}
    payload = job.get("payload", {}) or {}
    update_job(job_id, status="running", progress={"status": "rendering"})
    recipients = payload.get("recipients") or []
    source = os.getenv("CTI_HUNTING_REPORT_FROM_EMAIL") or os.getenv("CTI_HUNTING_SES_FROM_EMAIL")
    if not source: raise RuntimeError("CTI_HUNTING_REPORT_FROM_EMAIL is required")
    msg = EmailMessage(); msg["Subject"] = payload.get("subject") or "CTI Hunting - Relatório"; msg["From"] = source; msg["To"] = ", ".join(recipients)
    msg.set_content(payload.get("message") or "Segue em anexo o relatório dos scans selecionados.")
    for scan_id in payload.get("scan_ids", []):
        scan = get_scan(scan_id)
        if not scan: continue
        sp = scan_to_payload(scan)
        for fmt in payload.get("formats") or ["xlsx", "pdf"]:
            rendered = render(sp, fmt)
            data = base64.b64decode(rendered["body_base64"])
            maintype, subtype = rendered["content_type"].split("/", 1)
            msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=rendered["filename"])
    SES.send_raw_email(Source=source, Destinations=recipients, RawMessage={"Data": msg.as_bytes()})
    update_job(job_id, status="succeeded", progress={"status": "succeeded"}, result={"recipients": recipients})
    return {"ok": True, "job_id": job_id, "status": "succeeded"}

def handler(event, context):
    event = event or {}
    try:
        if event.get("source") == "cti_hunting.health": return {"ok": True, "name": "cti_hunting_report"}
        if event.get("source") == "cti_hunting.report.render": return render(event.get("payload") or {}, event.get("format") or "xlsx")
        if event.get("source") == "cti_hunting.report.job": return send_email_job(event.get("job_id"))
        return {"ok": False, "error": f"unknown source: {event.get('source')}"}
    except Exception as exc:
        traceback.print_exc()
        if event.get("job_id"):
            try: update_job(event["job_id"], status="failed", error=str(exc), progress={"status": "failed"})
            except Exception: pass
        return {"ok": False, "error": str(exc)}
