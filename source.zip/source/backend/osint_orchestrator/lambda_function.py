from __future__ import annotations
import hashlib
import json
import math
import os
import time
import traceback
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from zoneinfo import ZoneInfo

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

DDB = boto3.resource("dynamodb")
LAMBDA = boto3.client("lambda")
SCHEDULER = boto3.client("scheduler")

TABLE_ASSETS = os.getenv("CTI_HUNTING_ASSETS_TABLE", "cti_hunting_assets")
TABLE_SCANS = os.getenv("CTI_HUNTING_SCANS_TABLE", "cti_hunting_scans")
TABLE_SAFELIST = os.getenv("CTI_HUNTING_SAFELIST_TABLE", "cti_hunting_safelist")
TABLE_CONFIG = os.getenv("CTI_HUNTING_CONFIG_TABLE", "cti_hunting_config")
TABLE_JOBS = os.getenv("CTI_HUNTING_JOBS_TABLE", "cti_hunting_jobs")
JOB_TTL_DAYS = int(os.getenv("CTI_HUNTING_JOB_TTL_DAYS", "7"))
RESCAN_DAYS = int(os.getenv("CTI_HUNTING_RESCAN_DAYS", "90"))
SCHED_DEFAULTS = {"intervalDays": 5, "maxPerDay": 3}
ASSETS_SCHEDULE_INDEX = os.getenv("CTI_HUNTING_ASSETS_SCHEDULE_INDEX", "schedule-index")

PROVIDERS = {
    "serp": {"fn_env": "CTI_HUNTING_COLLECT_SERP_LAMBDA", "fn": "cti_hunting_collect_serp", "table_env": "CTI_HUNTING_COLLECT_SERP_TABLE", "table": "cti_hunting_collect_serp"},
    "virustotal": {"fn_env": "CTI_HUNTING_COLLECT_VIRUSTOTAL_LAMBDA", "fn": "cti_hunting_collect_virustotal", "table_env": "CTI_HUNTING_COLLECT_VIRUSTOTAL_TABLE", "table": "cti_hunting_collect_virustotal"},
    "apura": {"fn_env": "CTI_HUNTING_COLLECT_APURA_LAMBDA", "fn": "cti_hunting_collect_apura", "table_env": "CTI_HUNTING_COLLECT_APURA_TABLE", "table": "cti_hunting_collect_apura"},
    "intelx": {"fn_env": "CTI_HUNTING_COLLECT_INTELX_LAMBDA", "fn": "cti_hunting_collect_intelx", "table_env": "CTI_HUNTING_COLLECT_INTELX_TABLE", "table": "cti_hunting_collect_intelx"},
    "domaintools": {"fn_env": "CTI_HUNTING_COLLECT_DOMAINTOOLS_LAMBDA", "fn": "cti_hunting_collect_domaintools", "table_env": "CTI_HUNTING_COLLECT_DOMAINTOOLS_TABLE", "table": "cti_hunting_collect_domaintools"},
    "dnsprobe": {"fn_env": "CTI_HUNTING_COLLECT_DNSPROBE_LAMBDA", "fn": "cti_hunting_collect_dnsprobe", "table_env": "CTI_HUNTING_COLLECT_DNSPROBE_TABLE", "table": "cti_hunting_collect_dnsprobe"},
}
SOURCE_PROVIDER = {"SerpAPI": "serp", "VirusTotal": "virustotal", "Apura": "apura", "IntelX": "intelx", "DomainTools": "domaintools", "DNS-Probe": "dnsprobe"}
MODULE_WEIGHTS = {"apks": 3, "code_repos": 4, "credentials": 5, "darkweb": 3, "domains": 2, "exposed_files": 4, "phishing": 2}
MODULE_SOURCES = {"credentials": ["IntelX"], "exposed_files": ["SerpAPI"], "code_repos": ["SerpAPI"], "domains": ["VirusTotal", "DomainTools", "Apura"], "apks": ["SerpAPI"], "phishing": ["DNS-Probe", "SerpAPI"], "darkweb": ["Apura"]}

_tables: dict[str, Any] = {}

def table(name: str):
    if name not in _tables:
        _tables[name] = DDB.Table(name)
    return _tables[name]

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def today_ymd() -> str:
    try:
        return datetime.now(ZoneInfo(os.getenv("CTI_HUNTING_SCHEDULER_TIMEZONE", "America/Sao_Paulo"))).date().isoformat()
    except Exception:
        return datetime.now(timezone.utc).date().isoformat()

def new_id(prefix: str) -> str:
    return f"{prefix}_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}"

def keyify(value: str | None) -> str:
    return (value or "").strip().lower()

def to_dynamo(value: Any) -> Any:
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {k: to_dynamo(v) for k, v in value.items()}
    if isinstance(value, list):
        return [to_dynamo(v) for v in value]
    return value

def from_dynamo(value: Any) -> Any:
    if isinstance(value, Decimal):
        return int(value) if value % 1 == 0 else float(value)
    if isinstance(value, dict):
        return {k: from_dynamo(v) for k, v in value.items()}
    if isinstance(value, list):
        return [from_dynamo(v) for v in value]
    return value

def scan_all(table_name: str) -> list[dict]:
    items, kwargs = [], {}
    while True:
        resp = table(table_name).scan(**kwargs)
        items.extend(resp.get("Items", []))
        if "LastEvaluatedKey" not in resp:
            break
        kwargs["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
    return [from_dynamo(x) for x in items]

def query_all(table_name: str, **kwargs) -> list[dict]:
    items = []
    while True:
        resp = table(table_name).query(**kwargs)
        items.extend(resp.get("Items", []))
        if "LastEvaluatedKey" not in resp:
            break
        kwargs["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
    return [from_dynamo(x) for x in items]

def get_item(table_name: str, key: dict) -> dict | None:
    item = table(table_name).get_item(Key=key).get("Item")
    return from_dynamo(item) if item else None

def put_item(table_name: str, item: dict):
    table(table_name).put_item(Item=to_dynamo(item))

def update_job(job_id: str, **updates) -> dict | None:
    if not updates:
        return get_item(TABLE_JOBS, {"id": job_id})
    names, values, sets = {}, {}, []
    for i, (k, v) in enumerate(updates.items()):
        nk, vk = f"#k{i}", f":v{i}"
        names[nk] = k
        values[vk] = to_dynamo(v)
        sets.append(f"{nk}={vk}")
    names["#updated_at"] = "updated_at"; values[":updated_at"] = now_iso(); sets.append("#updated_at=:updated_at")
    resp = table(TABLE_JOBS).update_item(Key={"id": job_id}, UpdateExpression="SET " + ", ".join(sets), ExpressionAttributeNames=names, ExpressionAttributeValues=values, ReturnValues="ALL_NEW")
    return from_dynamo(resp.get("Attributes"))

def append_job_log(job_id: str, level: str, module: str, msg: str):
    job = get_item(TABLE_JOBS, {"id": job_id}) or {}
    logs = job.get("logs", [])
    logs.append({"ts": now_iso(), "elapsed": 0, "level": level, "module": module, "msg": msg})
    update_job(job_id, logs=logs[-1000:])

def provider_function(provider: str) -> str:
    meta = PROVIDERS[provider]
    return os.getenv(meta["fn_env"], meta["fn"])

def provider_table(provider: str) -> str:
    meta = PROVIDERS[provider]
    return os.getenv(meta["table_env"], meta["table"])

def get_config_overrides() -> dict:
    try:
        item = get_item(TABLE_CONFIG, {"key": "overrides"})
        return (item or {}).get("value", {}) or {}
    except Exception:
        return {}

def runtime_config() -> dict:
    cfg = {
        "MODULE_WEIGHTS": MODULE_WEIGHTS,
        "MODULE_SOURCES": MODULE_SOURCES,
        "INTELX_BASE": "https://2.intelx.io",
        "INTELX_BUCKET": "leaks.logs",
        "INTELX_DAYS_BACK": 4,
        "INTELX_MAX_RESULTS": 1000,
        "INTELX_RECORTE_WINDOW": 500,
        "APURA_BASE": "https://bttng.apura.com.br",
        "APURA_SOURCES_DARKWEB": ["Ransomware", "Forums"],
        "APURA_SOURCES_CERTSTREAM": ["CertStream"],
        "DOMAINTOOLS_BASE": "https://api.domaintools.com",
        "DOMAINTOOLS_MONITOR_ID": os.getenv("DOMAINTOOLS_MONITOR_ID", ""),
        "DOMAIN_PROBE_WORKERS": 20,
        "TYPO_MAX_VARIANTS": 500,
        "TYPO_PROBE_WORKERS": 20,
        "EXPOSED_FILES_SITES": "site:scribd.com OR site:docdroid.net OR site:slideshare.net OR site:issuu.com OR site:yumpu.com OR site:vdocuments.com OR site:atlassian.net OR site:s3.amazonaws.com OR inurl:docs.google.com OR site:pastebin.com OR site:repl.it",
        "EXPOSED_FILES_TERMS": ["confidential", "confidencial", "internal use only", "uso interno", "interno", "restricted", "password", "senha", "api_key", "apikey", "token", "secret", "BEGIN RSA PRIVATE KEY", "AKIA", "boleto", "comprovante", "CPF", "nota fiscal", "fatura", "contrato"],
        "CODE_REPO_DORKS": ['site:github.com "{term}" "password"', 'site:github.com "{term}" "api_key"', 'site:github.com "{term}" "secret"', 'site:github.com "{term}" "token"', 'site:github.com "{term}" ".env"', 'site:gitlab.com "{term}" "password"', 'site:gitlab.com "{term}" "secret"', 'site:bitbucket.org "{term}" "credentials"', 'site:gist.github.com "{term}"', 'site:postman.com "{term}"', 'site:documenter.getpostman.com "{term}"', 'site:swaggerhub.com "{term}"', 'site:pastebin.com "{term}"', 'site:trello.com "{term}" "password"'],
        "OFFICIAL_REPO_PATTERNS": ["/docs/", "/documentation/", "official"],
        "APK_DORKS": ['"{term}" filetype:apk', 'site:apkpure.com "{term}"', 'site:apkmirror.com "{term}"', 'site:apkmonk.com "{term}"'],
    }
    cfg.update(get_config_overrides())
    return cfg

def score_from_counts(counts: dict, weights: dict) -> tuple[int, int]:
    ks = [2 * w * math.log2(1 + counts.get(m, 0)) for m, w in weights.items() if counts.get(m, 0) > 0]
    weighted_total = sum(counts.get(m, 0) * w for m, w in weights.items())
    if not ks:
        return weighted_total, 0
    base = max(ks); others = sum(ks) - base
    return weighted_total, min(100, round(base + 0.20 * others))

def criticality_label(score: int) -> str:
    if score <= 24:
        return "Low"
    if score <= 49:
        return "Medium"
    if score <= 75:
        return "High"
    return "Critical"

def calculate_score(results: dict) -> dict:
    weights = runtime_config().get("MODULE_WEIGHTS", MODULE_WEIGHTS)
    counts = {m: len(results.get(m, [])) for m in weights}
    weighted_total, score = score_from_counts(counts, weights)
    return {"counts": counts, "weighted_total": weighted_total, "score": score, "criticality": criticality_label(score)}

def fingerprint_item(mod: str, item: dict) -> str:
    fields = {"credentials": ["user", "url", "source_file", "intelx_url"], "exposed_files": ["link", "title", "term_searched"], "code_repos": ["link", "title", "platform"], "domains": ["domain", "source", "type"], "apks": ["link", "title", "store"], "phishing": ["link", "typo_variant", "detection_type"], "darkweb": ["event_id", "url", "title", "timestamp"]}.get(mod, [])
    material = {k: item.get(k, "") for k in fields if item.get(k) not in (None, "")}
    if not material:
        material = item
    return hashlib.sha256(f"{mod}:{json.dumps(material, sort_keys=True, ensure_ascii=False, default=str)}".encode()).hexdigest()

def apply_safelist(results: dict, safelist: dict) -> dict:
    out = {}
    for mod, items in results.items():
        blocked = {e if isinstance(e, str) else e.get("fp") for e in safelist.get(mod, []) or []}
        kept = []
        for item in items or []:
            fp = fingerprint_item(mod, item)
            item.setdefault("fingerprint", fp); item.setdefault("_fp", fp)
            if fp not in blocked:
                kept.append(item)
        out[mod] = kept
    return out

def normalise_modules(modules: list[str] | None) -> list[str]:
    order = list(runtime_config().get("MODULE_WEIGHTS", MODULE_WEIGHTS).keys())
    requested = modules or ["all"]
    return order if "all" in requested else [m for m in requested if m in order]

def source_list_for_module(module: str, sources_by_module: dict) -> list[str]:
    configured = runtime_config().get("MODULE_SOURCES", MODULE_SOURCES).get(module, [])
    requested = sources_by_module.get(module)
    return list(configured) if not requested else [s for s in requested if s in configured]

def build_provider_tasks(modules: list[str], sources_by_module: dict) -> dict[str, dict[str, Any]]:
    tasks: dict[str, dict[str, Any]] = {}
    for mod in modules:
        for source in source_list_for_module(mod, sources_by_module):
            provider = SOURCE_PROVIDER.get(source)
            if not provider:
                continue
            task = tasks.setdefault(provider, {"modules": [], "sources_by_module": {}})
            if mod not in task["modules"]:
                task["modules"].append(mod)
            task["sources_by_module"].setdefault(mod, []).append(source)
    return tasks

def invoke_async(function_name: str, payload: dict):
    return LAMBDA.invoke(FunctionName=function_name, InvocationType="Event", Payload=json.dumps(payload, ensure_ascii=False).encode("utf-8"))

def create_job(payload: dict, job_type: str) -> dict:
    job_id = new_id("job")
    now = now_iso()
    job = {"id": job_id, "job_type": job_type, "status": "queued", "payload": payload, "logs": [], "progress": {"status": "queued"}, "created_at": now, "updated_at": now, "ttl_epoch": int(time.time()) + JOB_TTL_DAYS * 86400}
    put_item(TABLE_JOBS, job)
    return job

def get_safelist(asset_name: str) -> dict:
    item = get_item(TABLE_SAFELIST, {"asset_key": keyify(asset_name)})
    return (item or {}).get("corrected", {}) or {}

def create_initial_collector_item(scan_id: str, provider: str, task: dict, job_id: str):
    put_item(provider_table(provider), {"scan_id": scan_id, "item_key": f"COLLECTOR#{provider}", "provider": provider, "job_id": job_id, "status": "queued", "modules": task.get("modules", []), "started_at": "", "finished_at": "", "findings_count": 0, "logs_count": 0, "error": "", "ttl_epoch": int(time.time()) + int(os.getenv("CTI_HUNTING_COLLECTOR_TTL_DAYS", "90")) * 86400})

def collector_statuses(scan_id: str, expected: list[str]) -> dict[str, dict]:
    out = {}
    for provider in expected:
        item = get_item(provider_table(provider), {"scan_id": scan_id, "item_key": f"COLLECTOR#{provider}"})
        if item:
            out[provider] = item
    return out

def collector_items(scan_id: str, provider: str) -> list[dict]:
    return query_all(provider_table(provider), KeyConditionExpression=Key("scan_id").eq(scan_id))

def collect_intermediate(scan_id: str, providers: list[str]) -> tuple[dict, dict, list]:
    results: dict[str, list] = {}
    errors: dict[str, str] = {}
    logs: list[dict] = []
    for provider in providers:
        for item in collector_items(scan_id, provider):
            sk = item.get("item_key", "")
            if sk.startswith("FINDING#"):
                mod = item.get("module") or sk.split("#")[1]
                finding = item.get("finding") or {k: v for k, v in item.items() if k not in ("scan_id", "item_key", "ttl_epoch")}
                results.setdefault(mod, []).append(finding)
            elif sk.startswith("LOG#"):
                logs.append(item.get("log") or {"ts": item.get("created_at", ""), "level": item.get("level", "INFO"), "module": item.get("module", provider), "msg": item.get("message", "")})
            elif sk.startswith("COLLECTOR#") and item.get("status") == "failed":
                errors[provider] = item.get("error", "failed")
    logs.sort(key=lambda x: x.get("ts", ""))
    return results, errors, logs

def dedupe_results(results: dict) -> dict:
    out = {}
    for mod, items in results.items():
        seen, bucket = set(), []
        for item in items or []:
            fp = fingerprint_item(mod, item)
            if fp in seen:
                continue
            seen.add(fp)
            item.setdefault("fingerprint", fp); item.setdefault("_fp", fp)
            bucket.append(item)
        out[mod] = bucket
    return out

def save_scan(scan_payload: dict) -> dict:
    scan_id = scan_payload.get("id") or new_id("scan")
    now = now_iso()
    rec = {"id": scan_id, "company": scan_payload.get("company", "Unknown"), "company_key": keyify(scan_payload.get("company", "Unknown")), "asset_id": scan_payload.get("asset_id", ""), "terms": scan_payload.get("terms", []), "counts": scan_payload.get("counts", {}), "original_counts": scan_payload.get("counts", {}), "results": scan_payload.get("results", {}), "score": int(scan_payload.get("score", 0)), "criticality": scan_payload.get("criticality", ""), "weighted_total": scan_payload.get("weighted_total", 0), "logs": scan_payload.get("logs", []), "errors": scan_payload.get("errors", {}), "run_type": scan_payload.get("run_type", "scheduled"), "scanned_at": now, "next_scan_at": (datetime.now(timezone.utc) + timedelta(days=RESCAN_DAYS)).isoformat().replace("+00:00", "Z"), "corrections": [], "created_at": now, "updated_at": now}
    put_item(TABLE_SCANS, rec)
    return rec

def get_sched_config() -> dict:
    item = get_item(TABLE_CONFIG, {"key": "schedule"})
    return {**SCHED_DEFAULTS, **((item or {}).get("value", {}) or {})}

def next_date_from(asset: dict) -> str:
    interval = int(get_sched_config().get("intervalDays", 5))
    base = asset.get("scheduled_date") or today_ymd()
    return (datetime.fromisoformat(base[:10]) + timedelta(days=interval)).date().isoformat()

def schedule_name(asset: dict) -> str:
    return asset.get("schedule_name") or f"cti_hunting_asset_{asset.get('id', 'asset')}"

def sync_asset_schedule(asset: dict) -> dict:
    asset_id = asset.get("id")
    name = schedule_name(asset)
    if not asset.get("auto_enabled") or not asset.get("scheduled_date"):
        return {"ok": True, "action": "disabled", "schedule_name": name}
    arn = os.getenv("CTI_HUNTING_ORCHESTRATOR_LAMBDA_ARN", "")
    role = os.getenv("CTI_HUNTING_SCHEDULER_ROLE_ARN", "")
    if not arn or not role:
        return {"ok": False, "action": "skipped", "schedule_name": name, "error": "scheduler env vars missing"}
    time_part = os.getenv("CTI_HUNTING_SCHEDULE_TIME", "00:00:00") or "00:00:00"
    kwargs = {"Name": name, "GroupName": os.getenv("CTI_HUNTING_SCHEDULER_GROUP", "default"), "ScheduleExpression": f"at({asset['scheduled_date']}T{time_part})", "ScheduleExpressionTimezone": os.getenv("CTI_HUNTING_SCHEDULER_TIMEZONE", "America/Sao_Paulo"), "FlexibleTimeWindow": {"Mode": "OFF"}, "State": "ENABLED", "Target": {"Arn": arn, "RoleArn": role, "Input": json.dumps({"source": "cti_hunting.schedule.asset", "asset_id": asset_id, "schedule_name": name, "run_type": "scheduled"}, ensure_ascii=False)}, "Description": f"CTI Hunting scheduled OSINT for asset {asset.get('name') or asset_id}"}
    try:
        SCHEDULER.update_schedule(**kwargs); action = "updated"
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") not in ("ResourceNotFoundException", "ValidationException"):
            return {"ok": False, "action": "error", "schedule_name": name, "error": str(exc)}
        try:
            SCHEDULER.create_schedule(**kwargs); action = "created"
        except Exception as create_exc:
            return {"ok": False, "action": "error", "schedule_name": name, "error": str(create_exc)}
    return {"ok": True, "action": action, "schedule_name": name}

def mark_asset_scanned(asset_id: str, scan: dict, next_date: str | None = None) -> dict | None:
    asset = get_item(TABLE_ASSETS, {"id": asset_id})
    if not asset:
        return None
    updates = {"last_scan_at": scan.get("scanned_at") or now_iso(), "last_score": scan.get("score", 0), "last_criticality": scan.get("criticality", ""), "updated_at": now_iso()}
    if next_date:
        updates["scheduled_date"] = next_date; updates["scheduled_at"] = f"{next_date}T00:00:00Z"; updates["schedule_status"] = "enabled" if asset.get("auto_enabled") else "disabled"
    asset.update(updates)
    put_item(TABLE_ASSETS, asset)
    return asset

def start_scan(job: dict) -> dict:
    job_id = job["id"]
    payload = job.get("payload", {}) or {}
    company = payload.get("company") or payload.get("asset_name") or "Unknown"
    terms = payload.get("terms") or []
    selected_modules = normalise_modules(payload.get("modules"))
    tasks = build_provider_tasks(selected_modules, payload.get("sources_by_module", {}) or {})
    expected = list(tasks)
    logs = [{"ts": now_iso(), "elapsed": 0, "level": "INFO", "module": "orchestrator", "msg": f"starting OSINT for {company}"}]
    update_job(job_id, status="running", scan_id=job_id, expected_collectors=expected, completed_collectors=[], failed_collectors=[], progress={"done": 0, "total": len(expected), "module": "orchestrator", "status": "starting"}, logs=logs)
    if not expected:
        return finalize(job_id)
    cfg = runtime_config()
    for provider, task in tasks.items():
        create_initial_collector_item(job_id, provider, task, job_id)
        invoke_async(provider_function(provider), {"source": "cti_hunting.collect.run", "scan_id": job_id, "job_id": job_id, "provider": provider, "company": company, "asset_id": payload.get("asset_id", ""), "terms": terms, "modules": task.get("modules", []), "sources_by_module": task.get("sources_by_module", {}), "config": cfg})
        logs.append({"ts": now_iso(), "elapsed": 0, "level": "INFO", "module": "orchestrator", "msg": f"collector dispatched: {provider}"})
    update_job(job_id, logs=logs)
    return {"ok": True, "job_id": job_id, "expected_collectors": expected}

def finalize(job_id: str) -> dict:
    job = get_item(TABLE_JOBS, {"id": job_id})
    if not job:
        return {"ok": False, "error": "job not found"}
    if job.get("status") in ("succeeded", "failed", "cancelled"):
        return {"ok": True, "status": job.get("status"), "job_id": job_id, "already_finalized": True}
    payload = job.get("payload", {}) or {}
    expected = job.get("expected_collectors", []) or []
    results, errors, logs = collect_intermediate(job_id, expected)
    deduped = dedupe_results(results)
    final_results = apply_safelist(deduped, payload.get("safelist", {}) or {})
    score = calculate_score(final_results)
    result = {"company": payload.get("company") or payload.get("asset_name") or "Unknown", "asset_id": payload.get("asset_id", ""), "terms": payload.get("terms", []), "results": final_results, "score": score, "errors": errors, "logs": logs}
    if job.get("status") == "cancel_requested":
        update_job(job_id, status="cancelled", progress={"status": "cancelled"}, result=result, logs=logs)
        return {"ok": True, "status": "cancelled", "job_id": job_id}
    scan_record = None
    if job.get("job_type") == "scheduled_osint" or payload.get("persist_scan"):
        scan_record = save_scan({"company": result["company"], "asset_id": result.get("asset_id", ""), "terms": result["terms"], "counts": score.get("counts", {}), "results": final_results, "score": score.get("score", 0), "criticality": score.get("criticality", ""), "weighted_total": score.get("weighted_total", 0), "logs": logs, "errors": errors, "run_type": payload.get("run_type", "scheduled")})
        result["saved_scan_id"] = scan_record["id"]
        if result.get("asset_id"):
            asset = get_item(TABLE_ASSETS, {"id": result["asset_id"]})
            if asset:
                next_date = next_date_from(asset) if asset.get("auto_enabled") else None
                updated_asset = mark_asset_scanned(result["asset_id"], scan_record, next_date=next_date)
                if updated_asset and updated_asset.get("auto_enabled") and updated_asset.get("scheduled_date"):
                    result["schedule_status"] = sync_asset_schedule(updated_asset)
    logs.append({"ts": now_iso(), "elapsed": 0, "level": "OK", "module": "score", "msg": f"score={score['score']} criticality={score['criticality']} weighted={score['weighted_total']}"})
    update_job(job_id, status="succeeded", progress={"done": len(expected), "total": len(expected), "status": "succeeded"}, result=result, logs=logs)
    return {"ok": True, "status": "succeeded", "job_id": job_id, "score": score}

def handle_collector_completed(event: dict) -> dict:
    scan_id = event.get("scan_id") or event.get("job_id")
    if not scan_id:
        return {"ok": False, "error": "scan_id is required"}
    job = get_item(TABLE_JOBS, {"id": scan_id})
    if not job:
        return {"ok": False, "error": "job not found"}
    if job.get("status") in ("succeeded", "failed", "cancelled"):
        return {"ok": True, "status": job.get("status"), "job_id": scan_id}
    expected = job.get("expected_collectors", []) or []
    statuses = collector_statuses(scan_id, expected)
    completed = [p for p, s in statuses.items() if s.get("status") == "completed"]
    failed = [p for p, s in statuses.items() if s.get("status") == "failed"]
    _, _, logs = collect_intermediate(scan_id, expected)
    update_job(scan_id, completed_collectors=completed, failed_collectors=failed, progress={"done": len(completed) + len(failed), "total": len(expected), "module": event.get("provider", "collector"), "status": "done"}, logs=logs)
    if expected and len(completed) + len(failed) >= len(expected):
        return finalize(scan_id)
    return {"ok": True, "status": "running", "job_id": scan_id, "completed": completed, "failed": failed}

def start_job(job_id: str) -> dict:
    job = get_item(TABLE_JOBS, {"id": job_id})
    if not job:
        return {"ok": False, "error": "job not found"}
    return start_scan(job)

def start_scheduled_asset(event: dict) -> dict:
    asset_id = event.get("asset_id")
    if not asset_id:
        return {"ok": False, "error": "asset_id is required"}
    asset = get_item(TABLE_ASSETS, {"id": asset_id})
    if not asset:
        return {"ok": False, "error": f"asset not found: {asset_id}"}
    payload = {"company": asset.get("name", "Unknown"), "asset_name": asset.get("name", "Unknown"), "asset_id": asset_id, "terms": asset.get("terms", []), "modules": ["all"], "sources_by_module": {}, "safelist": get_safelist(asset.get("name", "")), "run_type": "scheduled", "persist_scan": True}
    job = create_job(payload, "scheduled_osint")
    return start_scan(job)

def run_due_assets() -> dict:
    until = today_ymd()
    due = [a for a in scan_all(TABLE_ASSETS) if a.get("auto_enabled") and a.get("scheduled_date") and a.get("scheduled_date") <= until]
    summary = {"ok": True, "due": len(due), "started": 0, "failed": 0, "jobs": []}
    for asset in due:
        try:
            res = start_scheduled_asset({"asset_id": asset["id"]})
            summary["jobs"].append(res); summary["started"] += 1
        except Exception as exc:
            traceback.print_exc(); summary["failed"] += 1; summary.setdefault("errors", []).append({"asset_id": asset.get("id"), "error": str(exc)})
    return summary

def handler(event, context):
    event = event or {}
    try:
        source = event.get("source")
        if source == "cti_hunting.health":
            return {"ok": True, "name": "cti_hunting_osint_orchestrator", "provider_tables": {p: provider_table(p) for p in PROVIDERS}}
        if source == "cti_hunting.osint.job.start":
            return start_job(event.get("job_id"))
        if source == "cti_hunting.collector.completed":
            return handle_collector_completed(event)
        if source == "cti_hunting.schedule.asset":
            return start_scheduled_asset(event)
        if source in ("cti_hunting.scheduler", "aws.scheduler") or event.get("detail-type") == "Scheduled Event":
            return run_due_assets()
        if source == "cti_hunting.finalize":
            return finalize(event.get("job_id") or event.get("scan_id"))
        return {"ok": False, "error": f"unknown source: {source}"}
    except Exception as exc:
        traceback.print_exc()
        job_id = event.get("job_id") or event.get("scan_id")
        if job_id:
            try:
                update_job(job_id, status="failed", error=str(exc), progress={"status": "failed"})
            except Exception:
                pass
        return {"ok": False, "error": str(exc)}
