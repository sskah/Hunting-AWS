"""
Shared SerpAPI client with:
  - ThreadPoolExecutor (5 workers, respects ~10 req/s plan limit)
  - Exponential back-off retry (3 attempts: 1s, 2s, 4s)
  - Circuit breaker: after 3 consecutive 429/5xx failures the module
    is marked degraded and no further calls are dispatched

Usage:
    from utils.serpapi_client import SerpApiClient
    client = SerpApiClient(api_key, module_name, logger)
    results = client.search_many(queries, num=20, field="organic_results")
"""
import time
import threading
import concurrent.futures
import requests

_ENDPOINT = "https://serpapi.com/search.json"
_MAX_WORKERS   = 5
_MAX_RETRIES   = 3
_BREAKER_LIMIT = 3    # consecutive failures before circuit opens


class SerpApiClient:
    def __init__(self, api_key: str, module: str, logger):
        self._key    = api_key
        self._module = module
        self._logger = logger
        self._failures = 0
        self._open     = False
        self._lock     = threading.Lock()

    def _call_one(self, params: dict, attempt: int = 0) -> dict:
        if self._open:
            return {}
        try:
            r = requests.get(_ENDPOINT, params=params, timeout=30)
            if r.status_code == 429 or r.status_code >= 500:
                raise requests.HTTPError(response=r)
            r.raise_for_status()
            with self._lock:
                self._failures = 0
            return r.json()
        except requests.RequestException as exc:
            with self._lock:
                self._failures += 1
                if self._failures >= _BREAKER_LIMIT:
                    self._open = True
                    self._logger.err(
                        self._module,
                        f"SerpAPI circuit open after {self._failures} failures — "
                        "remaining queries skipped")
                    return {}
            if attempt < _MAX_RETRIES - 1:
                delay = 2 ** attempt
                self._logger.warn(
                    self._module,
                    f"SerpAPI retry {attempt+1}/{_MAX_RETRIES-1} "
                    f"in {delay}s: {exc}")
                time.sleep(delay)
                return self._call_one(params, attempt + 1)
            self._logger.err(
                self._module,
                f"SerpAPI failed after {_MAX_RETRIES} attempts: {exc}")
            return {}

    def search(self, query: str, extra_params: dict | None = None,
               num: int = 20) -> dict:
        params = {
            "engine": "google",
            "q": query,
            "api_key": self._key,
            "num": num,
        }
        if extra_params:
            params.update(extra_params)
        return self._call_one(params)

    def search_many(self, queries: list[tuple[str, dict | None]],
                    num: int = 20,
                    field: str = "organic_results") -> list[tuple[int, list]]:
        """
        Run `queries` in parallel (≤ MAX_WORKERS).
        Each element of `queries` is (query_string, extra_params_dict | None).
        Returns [(original_index, result_list), ...] in completion order.
        """
        results = []
        with concurrent.futures.ThreadPoolExecutor(
                max_workers=_MAX_WORKERS) as pool:
            future_to_idx = {
                pool.submit(self.search, q, ep, num): i
                for i, (q, ep) in enumerate(queries)
            }
            for fut in concurrent.futures.as_completed(future_to_idx):
                idx  = future_to_idx[fut]
                data = fut.result()
                results.append((idx, data.get(field) or []))
        results.sort(key=lambda x: x[0])
        return results
