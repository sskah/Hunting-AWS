"""
Module 6 - Phishing Discovery
------------------------------
Two-pronged approach:

  A) Typosquatting — domain permutation using **dnstwist**
     (github.com/elceef/dnstwist), the community-standard engine.
     Variants are validated passively via DNS A/AAAA lookup only.
     Zero HTTP probing: no target contact, no server-log footprint.

  B) Sponsored ads — SerpAPI 'ads' field on brand-name searches.

dnstwist algorithms used:
  addition, bitsquatting, homoglyph (Unicode confusables),
  hyphenation, insertion, omission, plural, repetition,
  replacement (QWERTY/AZERTY/QWERTZ), subdomain, transposition,
  vowel-swap, TLD permutations, dictionary keyword injection.

DNS cache: resolved results are cached for 24 h in memory to avoid
redundant lookups across multiple terms in the same process run.
"""
import concurrent.futures
import socket
import time

import config as cfg_mod
from utils.serpapi_client import SerpApiClient

try:
    import dnstwist
    _HAS_DNSTWIST = True
except ImportError:
    _HAS_DNSTWIST = False

SOURCE_LABEL     = "SerpAPI"
SOURCE_LABEL_DNS = "DNS-Probe"

# 24-hour in-memory DNS cache: variant -> (alive, timestamp)
_DNS_CACHE: dict[str, tuple[bool, float]] = {}
_DNS_TTL = 86_400  # seconds

# Keyword list fed to dnstwist's dictionary/word-insert fuzzer.
# These are terms commonly appended to brand names in phishing domains.
BRAND_KEYWORDS = [
    "login", "secure", "account", "support", "verify", "auth",
    "portal", "client", "service", "official", "online", "app",
    "billing", "pay", "update", "mail", "webmail", "access",
    "help", "reset", "bank", "web", "my", "home",
]

# TLD set passed to dnstwist for TLD-swap permutations.
_TLD_DICTIONARY = [
    "com", "net", "org", "io", "co", "info", "biz",
    "online", "site", "shop", "store", "live", "app",
    "xyz", "br", "com.br", "com.ar", "com.mx", "com.co",
]


# ---------------------------------------------------------------
#  VARIANT GENERATION — dnstwist
# ---------------------------------------------------------------
def _generate_variants(domain: str, max_variants: int,
                       logger=None) -> list[tuple[str, str]]:
    """
    Returns a list of (variant_domain, fuzzer_algorithm) tuples.

    Uses dnstwist's DomainFuzz engine, which applies 14+ independent
    permutation algorithms. Much more comprehensive and reliable than
    any hand-rolled solution.
    """
    if not _HAS_DNSTWIST:
        if logger:
            logger.warn(
                "phishing",
                "dnstwist not installed — typosquatting skipped. "
                "Fix: pip install dnstwist",
            )
        return []

    try:
        fuzz = dnstwist.Fuzzer(
            domain,
            dictionary=BRAND_KEYWORDS,
            tld_dictionary=_TLD_DICTIONARY,
        )
        fuzz.generate()

        results: list[tuple[str, str]] = [
            (p["domain"], p.get("fuzzer", "unknown"))
            for p in fuzz.permutations()
            # skip the *original entry and exact match
            if p.get("domain")
            and not p.get("fuzzer", "").startswith("*")
            and p["domain"] != domain.lower()
        ]

        if logger:
            logger.debug(
                "phishing",
                f"[{domain}] dnstwist: {len(results)} permutations generated",
            )

        return results[:max_variants]

    except Exception as exc:
        if logger:
            logger.err("phishing", f"dnstwist error for '{domain}': {exc}")
        return []


# ---------------------------------------------------------------
#  DNS PROBE — passive, no HTTP contact
# ---------------------------------------------------------------
def _dns_resolve(variant: str) -> bool:
    """
    Checks whether a domain has a DNS A or AAAA record.
    Uses the OS resolver via socket — no external DNS library needed.
    UnicodeError handles IDN (internationalized) domains on systems
    that do not support IDNA encoding natively.
    """
    now = time.time()
    if variant in _DNS_CACHE:
        alive, ts = _DNS_CACHE[variant]
        if now - ts < _DNS_TTL:
            return alive

    try:
        socket.getaddrinfo(variant, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        alive = True
    except (socket.gaierror, UnicodeError):
        alive = False

    _DNS_CACHE[variant] = (alive, now)
    return alive


def _dns_batch(
    variants: list[tuple[str, str]],
    workers: int = 30,
    logger=None,
) -> list[tuple[str, str]]:
    """
    Concurrent DNS resolution for all (domain, fuzzer) pairs.
    Returns only those that resolve (i.e., are registered and live).
    """
    alive: list[tuple[str, str]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_dns_resolve, domain): (domain, fuzzer)
                   for domain, fuzzer in variants}
        done = 0
        for fut in concurrent.futures.as_completed(futures):
            done += 1
            if done % 50 == 0 and logger:
                logger.debug("phishing", f"DNS probe: {done}/{len(variants)}")
            try:
                if fut.result():
                    alive.append(futures[fut])
            except Exception:
                pass
    return alive


# ---------------------------------------------------------------
#  ORCHESTRATOR
# ---------------------------------------------------------------
def collect(terms: list, sources: list = None, logger=None) -> list:
    cfg = cfg_mod.load()
    if logger is None:
        from run_logger import RunLogger
        logger = RunLogger()

    sources = sources or cfg["MODULE_SOURCES"]["phishing"]
    logger.info("phishing", f"sources enabled: {sources}")

    findings: list[dict] = []
    seen: set[str] = set()
    max_v   = cfg.get("TYPO_MAX_VARIANTS", 600)
    workers = cfg.get("TYPO_PROBE_WORKERS", 30)

    for term in terms:
        domain = (
            term.replace("https://", "").replace("http://", "")
                .split("/")[0]
                .lower()
                .strip()
        )

        # ---- A) Typosquatting — dnstwist + passive DNS probe ----
        if SOURCE_LABEL_DNS in sources:
            variants = _generate_variants(domain, max_v, logger)

            if variants:
                logger.info(
                    "phishing",
                    f"[{domain}] resolving {len(variants)} permutations "
                    f"({workers} threads)...",
                )
                live = _dns_batch(variants, workers=workers, logger=logger)
                logger.ok(
                    "phishing",
                    f"[{domain}] {len(live)} live domain(s) "
                    f"out of {len(variants)} checked",
                )

                for v_domain, v_fuzzer in live:
                    if v_domain in seen:
                        continue
                    seen.add(v_domain)
                    findings.append({
                        "term":            term,
                        "detection_type":  "typosquatting",
                        "typo_variant":    v_domain,
                        "title":           "",
                        "link":            f"https://{v_domain}",
                        "snippet":         f"DNS registered [{v_fuzzer}]",
                        "source":          SOURCE_LABEL_DNS,
                    })
        else:
            logger.info("phishing", "DNS-Probe not selected; skipping typosquatting")

        # ---- B) Sponsored ads — SerpAPI ----
        if SOURCE_LABEL in sources:
            if not cfg.get("SERPAPI_KEY"):
                logger.err("phishing", "SERPAPI_KEY not configured")
            else:
                client = SerpApiClient(cfg["SERPAPI_KEY"], "phishing", logger)
                data   = client.search(term, num=20)
                ads    = data.get("ads", []) or []
                logger.info("phishing", f"[{term}] {len(ads)} sponsored ad(s)")

                for ad in ads:
                    link = ad.get("link", "")
                    if not link or link in seen:
                        continue
                    seen.add(link)
                    findings.append({
                        "term":           term,
                        "detection_type": "sponsored_ad",
                        "typo_variant":   "",
                        "title":          ad.get("title", ""),
                        "link":           link,
                        "snippet":        ad.get("description", "") or ad.get("snippet", ""),
                        "source":         SOURCE_LABEL,
                    })
        else:
            logger.info("phishing", "SerpAPI not selected; skipping ads")

    logger.info("phishing", f"completed: {len(findings)} suspicious domain(s)")
    return findings
