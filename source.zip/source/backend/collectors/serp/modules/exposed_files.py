"""
Module 2 - Exposed Files via SerpAPI dorking (refactored)
---------------------------------------------------------
New dork shape per spec:
  ( site:scribd.com OR site:docdroid.net OR ... ) "{term}" "{search_term}"

We report `term_searched` (the suspicious keyword, e.g. "confidential")
instead of the full dork string.
"""
import config as cfg_mod
from utils.serpapi_client import SerpApiClient

SOURCE_LABEL = "SerpAPI"


def collect(terms: list, sources: list = None, logger=None) -> list:
    cfg = cfg_mod.load()
    if logger is None:
        from run_logger import RunLogger
        logger = RunLogger()

    sources = sources or [SOURCE_LABEL]
    if SOURCE_LABEL not in sources:
        logger.info("exposed_files", f"{SOURCE_LABEL} not selected; skipping")
        return []

    if not cfg.get("SERPAPI_KEY"):
        logger.err("exposed_files", "SERPAPI_KEY not configured")
        return []

    sites_block  = cfg["EXPOSED_FILES_SITES"]
    search_terms = cfg["EXPOSED_FILES_TERMS"]
    extra        = {"hl": "pt-br", "gl": "br"}
    client       = SerpApiClient(cfg["SERPAPI_KEY"], "exposed_files", logger)

    # Build query list with metadata for reconstruction
    queries_meta = []
    for term in terms:
        for keyword in search_terms:
            query = f'({sites_block}) "{term}" "{keyword}"'
            queries_meta.append((query, extra, term, keyword))

    total = len(queries_meta)
    logger.info("exposed_files",
                f"dispatching {total} queries "
                f"({len(terms)} terms x {len(search_terms)} keywords)")

    batch = [(q, ep) for q, ep, _, _ in queries_meta]
    batched = client.search_many(batch, num=20, field="organic_results")

    findings   = []
    seen_links = set()
    for idx, results in batched:
        _, _, term, keyword = queries_meta[idx]
        new_in_q = 0
        for res in results:
            link = res.get("link", "")
            if not link or link in seen_links:
                continue
            seen_links.add(link)
            new_in_q += 1
            findings.append({
                "term": term,
                "term_searched": keyword,
                "title": res.get("title", ""),
                "link": link,
                "snippet": res.get("snippet", ""),
                "source": SOURCE_LABEL,
            })
        logger.debug("exposed_files",
                     f"[{idx+1}/{total}] term='{term}' "
                     f"keyword='{keyword}' → {len(results)} results, "
                     f"{new_in_q} new")

    logger.info("exposed_files", f"completed: {len(findings)} unique finding(s)")
    return findings
