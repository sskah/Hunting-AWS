"""
Module 5 - APK Discovery via SerpAPI
------------------------------------
Uses filetype:apk (not ext:apk).
"""
import config as cfg_mod
from utils.serpapi_client import SerpApiClient

SOURCE_LABEL = "SerpAPI"


def _detect_source(link: str) -> str:
    s = {"apkpure.com": "APKPure", "apkmirror.com": "APKMirror",
         "apkmonk.com": "APKMonk", "play.google.com": "Play Store"}
    for d, n in s.items():
        if d in link:
            return n
    return "Other"


def collect(terms: list, sources: list = None, logger=None) -> list:
    cfg = cfg_mod.load()
    if logger is None:
        from run_logger import RunLogger
        logger = RunLogger()

    sources = sources or [SOURCE_LABEL]
    if SOURCE_LABEL not in sources:
        logger.info("apks", f"{SOURCE_LABEL} not selected; skipping")
        return []

    if not cfg.get("SERPAPI_KEY"):
        logger.err("apks", "SERPAPI_KEY not configured")
        return []

    dorks  = cfg["APK_DORKS"]
    client = SerpApiClient(cfg["SERPAPI_KEY"], "apks", logger)

    queries_meta = [
        (dt.replace("{term}", term), None, term, dt)
        for term in terms for dt in dorks
    ]
    total = len(queries_meta)
    logger.info("apks", f"dispatching {total} queries")

    batch   = [(q, ep) for q, ep, _, _ in queries_meta]
    batched = client.search_many(batch, num=20, field="organic_results")

    findings   = []
    seen_links = set()
    for idx, results in batched:
        _, _, term, dork = queries_meta[idx]
        query    = dork.replace("{term}", term)
        new_in_q = 0
        for res in results:
            link = res.get("link", "")
            if not link or link in seen_links:
                continue
            seen_links.add(link)
            new_in_q += 1
            findings.append({
                "term": term,
                "store": _detect_source(link),
                "title": res.get("title", ""),
                "link": link,
                "snippet": res.get("snippet", ""),
                "source": SOURCE_LABEL,
            })
        logger.debug("apks",
                     f"[{idx+1}/{total}] '{query[:60]}…' "
                     f"→ {len(results)} results, {new_in_q} new")

    logger.info("apks", f"completed: {len(findings)} unique APK link(s)")
    return findings
