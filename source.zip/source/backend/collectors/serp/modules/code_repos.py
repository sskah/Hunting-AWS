"""
Module 3 - Exposed Code Repositories via SerpAPI
------------------------------------------------
"""
import re
from urllib.parse import urlparse
import config as cfg_mod
from utils.serpapi_client import SerpApiClient

SOURCE_LABEL = "SerpAPI"


def _is_official(link: str, term: str, official_patterns: list) -> bool:
    link_lower = link.lower()
    term_clean = re.sub(r"\.\w+$", "", term.lower())
    parts = [p for p in urlparse(link).path.split("/") if p]
    if parts and term_clean in parts[0].lower():
        return True
    return any(p in link_lower for p in official_patterns)


def _detect_platform(link: str) -> str:
    mapping = {
        "github.com": "GitHub", "gitlab.com": "GitLab",
        "bitbucket.org": "Bitbucket", "postman.com": "Postman",
        "swaggerhub.com": "SwaggerHub", "pastebin.com": "Pastebin",
        "trello.com": "Trello",
    }
    for d, n in mapping.items():
        if d in link:
            return n
    return "Other"


def collect(terms: list, sources: list = None, logger=None) -> list:
    cfg = cfg_mod.load()
    if logger is None:
        from run_logger import RunLogger
        logger = RunLogger()

    sources = sources or [SOURCE_LABEL]
    if SOURCE_LABEL not in sources:
        logger.info("code_repos", f"{SOURCE_LABEL} not selected; skipping")
        return []

    if not cfg.get("SERPAPI_KEY"):
        logger.err("code_repos", "SERPAPI_KEY not configured")
        return []

    dorks    = cfg["CODE_REPO_DORKS"]
    official = cfg["OFFICIAL_REPO_PATTERNS"]
    client   = SerpApiClient(cfg["SERPAPI_KEY"], "code_repos", logger)

    queries_meta = [
        (dt.replace("{term}", term), None, term, dt)
        for term in terms for dt in dorks
    ]
    total = len(queries_meta)
    logger.info("code_repos",
                f"dispatching {total} queries "
                f"({len(terms)} terms x {len(dorks)} dorks)")

    batch   = [(q, ep) for q, ep, _, _ in queries_meta]
    batched = client.search_many(batch, num=20, field="organic_results")

    findings       = []
    seen_links     = set()
    filtered_count = 0
    for idx, results in batched:
        _, _, term, dork = queries_meta[idx]
        query    = dork.replace("{term}", term)
        new_in_q = 0
        for res in results:
            link = res.get("link", "")
            if not link or link in seen_links:
                continue
            if _is_official(link, term, official):
                filtered_count += 1
                continue
            seen_links.add(link)
            new_in_q += 1
            findings.append({
                "term": term,
                "platform": _detect_platform(link),
                "title": res.get("title", ""),
                "link": link,
                "snippet": res.get("snippet", ""),
                "source": SOURCE_LABEL,
            })
        logger.debug("code_repos",
                     f"[{idx+1}/{total}] '{query[:60]}…' "
                     f"→ {len(results)} results, {new_in_q} new")

    logger.info("code_repos",
                f"completed: {len(findings)} finding(s), "
                f"{filtered_count} official result(s) filtered out")
    return findings
