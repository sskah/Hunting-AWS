from __future__ import annotations
import base64
import concurrent.futures
import json
import os
import socket
import sys
import time
import traceback
import types
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

import boto3

DDB = boto3.resource("dynamodb")
LAMBDA = boto3.client("lambda")
SECRETS = boto3.client("secretsmanager")
SECRETS_NAME = os.getenv("CTI_HUNTING_SECRETS_NAME", "cti_hunting_secrets")
ORCHESTRATOR = os.getenv("CTI_HUNTING_ORCHESTRATOR_LAMBDA", "cti_hunting_osint_orchestrator")
TTL_DAYS = int(os.getenv("CTI_HUNTING_COLLECTOR_TTL_DAYS", "90"))
_SECRET_CACHE: tuple[float, dict] | None = None
_CURRENT_SCAN_ID = ""
_LOG_COUNTER = 0

DEFAULT_CONFIG = {
    "INTELX_BASE": "https://2.intelx.io", "INTELX_BUCKET": "leaks.logs", "INTELX_DAYS_BACK": 4,
    "INTELX_MAX_RESULTS": 1000, "INTELX_RECORTE_WINDOW": 500,
    "APURA_BASE": "https://bttng.apura.com.br", "APURA_SOURCES_DARKWEB": ["Ransomware", "Forums"], "APURA_SOURCES_CERTSTREAM": ["CertStream"],
    "DOMAINTOOLS_BASE": "https://api.domaintools.com", "DOMAINTOOLS_MONITOR_ID": os.getenv("DOMAINTOOLS_MONITOR_ID", ""), "DOMAIN_PROBE_WORKERS": 20,
    "TYPO_MAX_VARIANTS": 500, "TYPO_PROBE_WORKERS": 20,
    "EXPOSED_FILES_SITES": "site:scribd.com OR site:docdroid.net OR site:slideshare.net OR site:issuu.com OR site:yumpu.com OR site:vdocuments.com OR site:atlassian.net OR site:s3.amazonaws.com OR inurl:docs.google.com OR site:pastebin.com OR site:repl.it",
    "EXPOSED_FILES_TERMS": ["confidential", "confidencial", "internal use only", "uso interno", "interno", "restricted", "password", "senha", "api_key", "apikey", "token", "secret", "BEGIN RSA PRIVATE KEY", "AKIA", "boleto", "comprovante", "CPF", "nota fiscal", "fatura", "contrato"],
    "CODE_REPO_DORKS": ['site:github.com "{term}" "password"', 'site:github.com "{term}" "api_key"', 'site:github.com "{term}" "secret"', 'site:github.com "{term}" "token"', 'site:github.com "{term}" ".env"', 'site:gitlab.com "{term}" "password"', 'site:gitlab.com "{term}" "secret"', 'site:bitbucket.org "{term}" "credentials"', 'site:gist.github.com "{term}"', 'site:postman.com "{term}"', 'site:documenter.getpostman.com "{term}"', 'site:swaggerhub.com "{term}"', 'site:pastebin.com "{term}"', 'site:trello.com "{term}" "password"'],
    "OFFICIAL_REPO_PATTERNS": ["/docs/", "/documentation/", "official"],
    "APK_DORKS": ['"{term}" filetype:apk', 'site:apkpure.com "{term}"', 'site:apkmirror.com "{term}"', 'site:apkmonk.com "{term}"'],
}
_RUNTIME_CONFIG: dict[str, Any] = {}

try:
    import requests
    requests.packages.urllib3.disable_warnings()  # type: ignore
except Exception:
    requests = None

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def ttl_epoch() -> int:
    return int(time.time()) + TTL_DAYS * 86400

def to_dynamo(value: Any) -> Any:
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {k: to_dynamo(v) for k, v in value.items()}
    if isinstance(value, list):
        return [to_dynamo(v) for v in value]
    return value

def table():
    return DDB.Table(COLLECTOR_TABLE)

def put_item(item: dict):
    table().put_item(Item=to_dynamo(item))

def update_status(scan_id: str, provider: str, status: str, **extra):
    names = {"#s": "status"}
    values = {":s": status, ":u": now_iso()}
    sets = ["#s=:s", "updated_at=:u"]
    for i, (k, v) in enumerate(extra.items()):
        names[f"#k{i}"] = k; values[f":v{i}"] = to_dynamo(v); sets.append(f"#k{i}=:v{i}")
    table().update_item(Key={"scan_id": scan_id, "item_key": f"COLLECTOR#{provider}"}, UpdateExpression="SET " + ", ".join(sets), ExpressionAttributeNames=names, ExpressionAttributeValues=values)

def log(level: str, module: str, msg: str):
    global _LOG_COUNTER
    _LOG_COUNTER += 1
    entry = {"ts": now_iso(), "elapsed": 0, "level": level, "module": module, "msg": msg}
    print(json.dumps(entry, ensure_ascii=False))
    if _CURRENT_SCAN_ID:
        put_item({"scan_id": _CURRENT_SCAN_ID, "item_key": f"LOG#{entry['ts']}#{_LOG_COUNTER:06d}", "provider": PROVIDER, "level": level, "module": module, "message": msg, "created_at": entry["ts"], "log": entry, "ttl_epoch": ttl_epoch()})

class Logger:
    def info(self, module, msg): log("INFO", module, msg)
    def debug(self, module, msg): log("DEBUG", module, msg)
    def warn(self, module, msg): log("WARN", module, msg)
    def err(self, module, msg): log("ERROR", module, msg)
    def ok(self, module, msg): log("OK", module, msg)
    @property
    def entries(self): return []
    def dump(self): return []

def secret_values(force: bool = False) -> dict:
    global _SECRET_CACHE
    if _SECRET_CACHE and not force and time.time() - _SECRET_CACHE[0] < int(os.getenv("CTI_HUNTING_SECRET_CACHE_TTL", "60")):
        return dict(_SECRET_CACHE[1])
    try:
        raw = SECRETS.get_secret_value(SecretId=SECRETS_NAME).get("SecretString") or "{}"
        values = json.loads(raw) if raw.strip().startswith("{") else {}
        if not isinstance(values, dict): values = {}
    except Exception as exc:
        print(f"secret read failed: {exc}")
        values = {}
    _SECRET_CACHE = (time.time(), values)
    return dict(values)

def set_runtime_config(values: dict | None):
    global _RUNTIME_CONFIG
    _RUNTIME_CONFIG = values or {}

def cfg() -> dict:
    c = dict(DEFAULT_CONFIG)
    c.update(_RUNTIME_CONFIG or {})
    c.update({k: v for k, v in secret_values().items() if v not in (None, "")})
    return c

def configured(keys: list[str]) -> dict[str, bool]:
    c = cfg()
    return {k: bool(c.get(k)) for k in keys}

def put_finding(scan_id: str, module: str, finding: dict):
    fid = finding.get("fingerprint") or finding.get("_fp") or uuid.uuid4().hex
    put_item({"scan_id": scan_id, "item_key": f"FINDING#{module}#{fid}", "provider": PROVIDER, "module": module, "finding": finding, "created_at": now_iso(), "ttl_epoch": ttl_epoch()})

def notify(scan_id: str, job_id: str, status: str):
    payload = {"source": "cti_hunting.collector.completed", "scan_id": scan_id, "job_id": job_id or scan_id, "provider": PROVIDER, "status": status}
    LAMBDA.invoke(FunctionName=ORCHESTRATOR, InvocationType="Event", Payload=json.dumps(payload, ensure_ascii=False).encode("utf-8"))

def init_status(scan_id: str, job_id: str, modules: list[str]):
    put_item({"scan_id": scan_id, "item_key": f"COLLECTOR#{PROVIDER}", "provider": PROVIDER, "job_id": job_id or scan_id, "status": "running", "modules": modules, "started_at": now_iso(), "finished_at": "", "findings_count": 0, "logs_count": 0, "error": "", "ttl_epoch": ttl_epoch()})

def health(required: list[str], modules: dict | None = None, extra: dict | None = None):
    set_runtime_config({})
    secrets = configured(required)
    table_ok = True; table_error = ""
    try:
        DDB.meta.client.describe_table(TableName=COLLECTOR_TABLE)
    except Exception as exc:
        table_ok = False; table_error = str(exc)
    out = {"ok": table_ok and all(secrets.values()), "provider": PROVIDER, "table": COLLECTOR_TABLE, "required_secrets": secrets, "modules": modules or {}, "table_ok": table_ok}
    if table_error: out["table_error"] = table_error
    if extra: out.update(extra)
    return out

import requests
PROVIDER = "apura"
COLLECTOR_TABLE = os.getenv("CTI_HUNTING_COLLECT_APURA_TABLE", "cti_hunting_collect_apura")
REQUIRED_SECRETS = ["APURA_KEY"]

def host(value: str) -> str:
    return (value or "").replace("https://", "").replace("http://", "").split("/")[0].lower().strip()

def http_200(domain: str, timeout: int = 8) -> bool:
    h = host(domain)
    if not h: return False
    for scheme in ("https://", "http://"):
        try:
            r = requests.get(scheme + h, headers={"User-Agent": "Mozilla/5.0 (CTI Hunting OSINT)"}, timeout=timeout, allow_redirects=True, verify=False)
            if r.status_code == 200: return True
        except requests.RequestException: continue
    return False

def filter_live(findings: list[dict], workers: int = 20) -> list[dict]:
    unique = {host(x.get("domain", "")) for x in findings if host(x.get("domain", ""))}
    if not unique: return findings
    alive = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(http_200, h): h for h in unique}
        for fut in concurrent.futures.as_completed(futures):
            h = futures[fut]
            try: alive[h] = fut.result()
            except Exception: alive[h] = False
    kept = []
    for item in findings:
        if alive.get(host(item.get("domain", ""))): item["http_status"] = 200; kept.append(item)
    log("OK", "domains", f"HTTP 200 check: {len(kept)}/{len(findings)} kept")
    return kept

def apura_post(query: str, c: dict, timeout: int = 60) -> list[dict]:
    r = requests.post(f"{c['APURA_BASE']}/v2/events/search", json={"query": query}, headers={"Authorization": f"Bearer {c['APURA_KEY']}"}, timeout=timeout)
    r.raise_for_status(); data = r.json()
    return data.get("results") or data.get("cards") or data.get("events") or data.get("data") or []

def collect_domains(terms: list[str]) -> list[dict]:
    c = cfg()
    if not c.get("APURA_KEY"):
        log("ERROR", "domains", "APURA_KEY not configured"); return []
    sources = " OR ".join(c.get("APURA_SOURCES_CERTSTREAM", ["CertStream"]))
    findings, seen = [], set()
    for term in terms:
        domain = host(term); query = f"source.name: ({sources}) AND ({domain})"
        try:
            events = apura_post(query, c, timeout=30); log("DEBUG", "domains", f"Apura/CertStream {domain}: {len(events)} event(s)")
            for ev in events:
                d = ev.get("domain") or ev.get("hostname") or ev.get("subject_common_name") or ev.get("title") or ev.get("forums", {}).get("topic", {}).get("title", "") or str(ev.get("content", ""))
                if not d or d.lower() in seen: continue
                seen.add(d.lower())
                findings.append({"term": domain, "domain": d, "type": "cert-stream", "last_analysis": ev.get("event_date", ev.get("timestamp", "")), "reputation": 0, "cert_issuer": ev.get("issuer", "") or (ev.get("ssl", {}) or {}).get("issuer", ""), "cert_subject": ev.get("subject", "") or d, "cert_san": ", ".join(ev.get("san", []) or [])[:300], "source": "Apura/CertStream"})
        except requests.RequestException as exc:
            log("ERROR", "domains", f"Apura/CertStream {domain} error: {exc}")
    return filter_live(findings, workers=int(c.get("DOMAIN_PROBE_WORKERS", 20)))

def collect_darkweb(terms: list[str]) -> list[dict]:
    c = cfg()
    if not c.get("APURA_KEY"):
        log("ERROR", "darkweb", "APURA_KEY not configured"); return []
    sources = " OR ".join(c.get("APURA_SOURCES_DARKWEB", ["Ransomware", "Forums"]))
    terms_block = " OR ".join(f'"{t}"' for t in terms)
    query = f"source.name: ({sources}) AND ({terms_block})"
    log("INFO", "darkweb", f"Apura query: {query}")
    try: events = apura_post(query, c, timeout=60)
    except requests.RequestException as exc:
        log("ERROR", "darkweb", f"Apura request failed: {exc}"); return []
    findings = []
    for ev in events:
        blob = f"{ev.get('content','')} {ev.get('title','')} {ev.get('snippet','')}".lower()
        matched = next((t for t in terms if t.lower() in blob), terms[0] if terms else "")
        findings.append({"term": matched, "source_name": ev.get("source", {}).get("name", "") if isinstance(ev.get("source"), dict) else ev.get("source_name", ""), "title": ev.get("title", ""), "snippet": (ev.get("content") or ev.get("snippet") or "")[:500], "url": ev.get("url", ""), "timestamp": ev.get("timestamp", ev.get("date", "")), "event_id": ev.get("id", ""), "source": "Apura"})
    log("INFO", "darkweb", f"received {len(findings)} event(s) from Apura")
    return findings

def handler(event, context):
    global _CURRENT_SCAN_ID
    event = event or {}
    if event.get("source") == "cti_hunting.health": return health(REQUIRED_SECRETS, {"domains": {"ok": True}, "darkweb": {"ok": True}})
    scan_id = event.get("scan_id") or event.get("job_id"); job_id = event.get("job_id") or scan_id
    if not scan_id: return {"ok": False, "error": "scan_id is required"}
    _CURRENT_SCAN_ID = scan_id; set_runtime_config(event.get("config") or {})
    modules = event.get("modules") or []; init_status(scan_id, job_id, modules)
    status = "completed"; error = ""; count = 0
    try:
        if "domains" in modules:
            items = collect_domains(event.get("terms") or []); count += len(items)
            for item in items: put_finding(scan_id, "domains", item)
        if "darkweb" in modules:
            items = collect_darkweb(event.get("terms") or []); count += len(items)
            for item in items: put_finding(scan_id, "darkweb", item)
        log("OK", PROVIDER, f"completed: {count} finding(s)")
    except Exception as exc:
        traceback.print_exc(); status = "failed"; error = str(exc); log("ERROR", PROVIDER, f"failed: {exc}")
    update_status(scan_id, PROVIDER, status, finished_at=now_iso(), findings_count=count, error=error)
    notify(scan_id, job_id, status)
    return {"ok": status == "completed", "provider": PROVIDER, "scan_id": scan_id, "status": status, "findings_count": count, "error": error}
