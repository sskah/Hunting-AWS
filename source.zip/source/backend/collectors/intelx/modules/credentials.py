"""
Module 1 - Exposed Credentials via IntelX (refactored)
------------------------------------------------------

Strategy (based on the production Lambda from the reference image):
  1. For each host in `terms`, search IntelX in the `leaks.logs` bucket,
     limited to the last N days (default 4).
  2. Iterate result records, keep only those whose `name` contains 'pass'.
  3. Download each file via /file/view?f=0&storageid=...&bucket=...&k=KEY
  4. Locate every occurrence of the search term inside the file content.
  5. Extract a "recorte" of +/- 500 chars around each occurrence.
  6. Split the recorte into blocks separated by blank lines and parse
     each block as `key: value` lines into a "card" dict.
  7. Detect the user field (key contains 'user' or 'login') and validate
     that the searched host appears in card[user_field].
  8. Mask values whose key contains 'pass'.
  9. Return the unique list of cards (deduped per storageid).

Adapted for local testing: returns list, no DynamoDB write.
"""
import re
import time
import requests
from datetime import datetime, timedelta, timezone
import config as cfg_mod

SOURCE_LABEL = "IntelX"

# Free/personal e-mail providers → credential belongs to a client/customer
_FREE_DOMAINS = frozenset({
    "gmail.com", "googlemail.com", "hotmail.com", "hotmail.com.br",
    "outlook.com", "outlook.com.br", "live.com", "live.com.br",
    "yahoo.com", "yahoo.com.br", "icloud.com", "me.com",
    "protonmail.com", "proton.me", "mail.com",
    "bol.com.br", "uol.com.br", "terra.com.br", "globo.com",
    "ig.com.br", "r7.com",
})

# CPF: 11 digits optionally formatted as ###.###.###-##
_CPF_RE = re.compile(r'\b\d{3}[.\-]?\d{3}[.\-]?\d{3}[.\-]?\d{2}\b')

_CURRENT_YEAR = str(datetime.now(timezone.utc).year)


def _classify(user_value: str, term: str) -> str:
    """Return 'corporate', 'client', or 'unknown'."""
    u = user_value.lower().strip()
    # Corporate: user field contains the searched domain/term
    term_base = term.lower().split(".")[0]
    if term.lower() in u or (len(term_base) > 2 and term_base in u):
        return "corporate"
    # Free e-mail provider
    if "@" in u:
        provider = u.split("@", 1)[-1]
        if provider in _FREE_DOMAINS:
            return "client"
    # CPF pattern
    if _CPF_RE.search(user_value):
        return "client"
    return "unknown"


def _is_recent(source_rec: dict) -> bool:
    """True if the IntelX record's date falls in the current calendar year."""
    for field in ("date", "added", "modified", "systemdate"):
        val = str(source_rec.get(field, ""))
        if _CURRENT_YEAR in val:
            return True
    return False


def _mask(value: str) -> str:
    if not value or len(value) <= 4:
        return "***"
    return value[:2] + "*" * (len(value) - 4) + value[-2:]


def _intelx_search(cfg, host: str, logger) -> list:
    days_back = cfg["INTELX_DAYS_BACK"]
    now = datetime.now(timezone.utc)
    datefrom = (now - timedelta(days=days_back)).strftime("%Y-%m-%d %H:%M:%S")
    dateto = now.strftime("%Y-%m-%d %H:%M:%S")

    headers = {"x-key": cfg["INTELX_KEY"], "Content-Type": "application/json"}
    payload = {
        "term": host,
        "buckets": [cfg["INTELX_BUCKET"]],
        "lookuplevel": 0,
        "maxresults": cfg["INTELX_MAX_RESULTS"],
        "timeout": 20,
        "datefrom": datefrom,
        "dateto": dateto,
        "sort": 4,
        "media": 0,
        "terminate": [],
    }
    logger.debug("credentials",
                 f"search host={host} bucket={cfg['INTELX_BUCKET']} "
                 f"window={datefrom}->{dateto}")

    try:
        r = requests.post(f"{cfg['INTELX_BASE']}/intelligent/search",
                          json=payload, headers=headers, timeout=30)
        r.raise_for_status()
        sid = r.json().get("id")
    except requests.RequestException as e:
        logger.err("credentials", f"search request failed: {e}")
        return []

    if not sid:
        logger.warn("credentials", f"no search id returned for host={host}")
        return []

    records = []
    for poll in range(12):
        time.sleep(2)
        try:
            r = requests.get(
                f"{cfg['INTELX_BASE']}/intelligent/search/result",
                params={"id": sid,
                        "limit": cfg["INTELX_MAX_RESULTS"],
                        "statistics": 0},
                headers=headers, timeout=30)
            data = r.json()
            batch = data.get("records", [])
            records.extend(batch)
            logger.debug("credentials",
                         f"poll {poll+1}: +{len(batch)} records "
                         f"(total={len(records)}) status={data.get('status')}")
            if data.get("status") in (0, 1):
                break
        except requests.RequestException as e:
            logger.err("credentials", f"poll error: {e}")
            break

    return records


def _intelx_read_file(cfg, storage_id: str, bucket: str, logger) -> str:
    url = (f"{cfg['INTELX_BASE']}/file/view"
           f"?f=0&storageid={storage_id}&bucket={bucket}"
           f"&k={cfg['INTELX_KEY']}")
    try:
        r = requests.get(url, timeout=60)
        r.raise_for_status()
        return r.text
    except requests.RequestException as e:
        logger.err("credentials",
                   f"file/view error storageid={storage_id[:12]}...: {e}")
        return ""


def _extract_recortes(response: str, term: str, window: int) -> list:
    out = []
    for m in re.finditer(re.escape(term), response, re.IGNORECASE):
        start = max(0, m.start() - window)
        end = min(len(response), m.end() + window)
        lf_before = response.rfind("\r\n", 0, start)
        inicio = lf_before + 2 if lf_before != -1 else 0
        lf_after = response.find("\r\n", end)
        fim = lf_after if lf_after != -1 else len(response)
        out.append(response[inicio:fim].strip())
    return out


def _parse_card_block(block: str, host: str, source_rec: dict) -> dict | None:
    card = {}
    for line in block.split("\r\n"):
        line = line.strip()
        if not line or ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip().lower()
        val = val.strip()
        if key:
            card[key] = val

    if not card:
        return None

    user_field = None
    for k in card.keys():
        if "user" in k or "login" in k or k == "email":
            user_field = k
            break
    if not user_field:
        return None

    if host.lower() not in str(card[user_field]).lower():
        return None

    masked = {}
    for k, v in card.items():
        if "pass" in k or "pwd" in k or "senha" in k:
            masked[k] = _mask(v)
        else:
            masked[k] = v

    pwd_value = next((v for k, v in masked.items()
                      if "pass" in k or "pwd" in k or "senha" in k), "")

    user_val  = masked.get(user_field, "")
    category  = _classify(user_val, host)
    recent    = _is_recent(source_rec)
    has_pwd   = bool(pwd_value and pwd_value not in ("***", ""))
    priority  = category == "corporate" and has_pwd and recent

    return {
        "term": host,
        "user": user_val,
        "user_field": user_field,
        "password": pwd_value,
        "url": masked.get("url", masked.get("host", "")),
        "extra": "; ".join(f"{k}={v}" for k, v in masked.items()
                           if k != user_field
                           and "pass" not in k and "pwd" not in k
                           and "senha" not in k
                           and k not in ("url", "host")),
        "source_file": source_rec.get("name", ""),
        "intelx_url": f"https://intelx.io/?did={source_rec.get('systemid','')}",
        "source": SOURCE_LABEL,
        "category": category,   # 'corporate' | 'client' | 'unknown'
        "is_recent": recent,
        "priority": priority,   # corporate + has_password + current year
    }


def collect(terms: list, sources: list = None, logger=None) -> list:
    cfg = cfg_mod.load()
    if logger is None:
        from run_logger import RunLogger
        logger = RunLogger()

    sources = sources or [SOURCE_LABEL]
    if SOURCE_LABEL not in sources:
        logger.info("credentials", f"{SOURCE_LABEL} not selected; skipping")
        return []

    if not cfg.get("INTELX_KEY"):
        logger.err("credentials", "INTELX_KEY not configured")
        return []

    leaks = []
    seen_storageids = set()
    window = cfg["INTELX_RECORTE_WINDOW"]
    block_pattern = re.compile(r"(?:\r?\n){2}(.*?)(?:\r?\n){2}", re.DOTALL)

    for host in terms:
        logger.info("credentials", f"[{host}] starting IntelX search")
        records = _intelx_search(cfg, host, logger)
        logger.info("credentials", f"[{host}] received {len(records)} records")

        candidates = [r for r in records
                      if "pass" in (r.get("name", "") or "").lower()]
        logger.info("credentials",
                    f"[{host}] {len(candidates)} records matched 'pass' in name")

        for rec in candidates:
            storage_id = rec.get("storageid")
            bucket = rec.get("bucket", cfg["INTELX_BUCKET"])
            if not storage_id:
                continue
            logger.debug("credentials",
                         f"[{host}] fetching {rec.get('name','?')} "
                         f"({storage_id[:12]}...)")
            response = _intelx_read_file(cfg, storage_id, bucket, logger)
            if not response:
                continue
            if host.lower() not in response.lower():
                logger.debug("credentials",
                             f"[{host}] file did not mention host; skipping")
                continue

            recortes = _extract_recortes(response, host, window)
            logger.debug("credentials",
                         f"[{host}] {len(recortes)} recortes extracted")

            cards_in_file = 0
            for recorte in recortes:
                padded = "\r\n\r\n" + recorte + "\r\n\r\n"
                for block in block_pattern.findall(padded):
                    if host.lower() not in block.lower():
                        continue
                    card = _parse_card_block(block, host, rec)
                    if card and storage_id not in seen_storageids:
                        leaks.append(card)
                        cards_in_file += 1
            if cards_in_file:
                seen_storageids.add(storage_id)
                logger.ok("credentials",
                          f"[{host}] +{cards_in_file} card(s) from "
                          f"{rec.get('name','?')}")

    logger.info("credentials", f"completed: {len(leaks)} unique leak(s) total")
    return leaks
