from __future__ import annotations
import base64
import concurrent.futures
import json
import os
import socket
import sys
import time
import traceback
import types
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

import boto3

DDB = boto3.resource("dynamodb")
LAMBDA = boto3.client("lambda")
SECRETS = boto3.client("secretsmanager")
SECRETS_NAME = os.getenv("CTI_HUNTING_SECRETS_NAME", "cti_hunting_secrets")
ORCHESTRATOR = os.getenv("CTI_HUNTING_ORCHESTRATOR_LAMBDA", "cti_hunting_osint_orchestrator")
TTL_DAYS = int(os.getenv("CTI_HUNTING_COLLECTOR_TTL_DAYS", "90"))
_SECRET_CACHE: tuple[float, dict] | None = None
_CURRENT_SCAN_ID = ""
_LOG_COUNTER = 0

DEFAULT_CONFIG = {
    "INTELX_BASE": "https://2.intelx.io", "INTELX_BUCKET": "leaks.logs", "INTELX_DAYS_BACK": 4,
    "INTELX_MAX_RESULTS": 1000, "INTELX_RECORTE_WINDOW": 500,
    "APURA_BASE": "https://bttng.apura.com.br", "APURA_SOURCES_DARKWEB": ["Ransomware", "Forums"], "APURA_SOURCES_CERTSTREAM": ["CertStream"],
    "DOMAINTOOLS_BASE": "https://api.domaintools.com", "DOMAINTOOLS_MONITOR_ID": os.getenv("DOMAINTOOLS_MONITOR_ID", ""), "DOMAIN_PROBE_WORKERS": 20,
    "TYPO_MAX_VARIANTS": 500, "TYPO_PROBE_WORKERS": 20,
    "EXPOSED_FILES_SITES": "site:scribd.com OR site:docdroid.net OR site:slideshare.net OR site:issuu.com OR site:yumpu.com OR site:vdocuments.com OR site:atlassian.net OR site:s3.amazonaws.com OR inurl:docs.google.com OR site:pastebin.com OR site:repl.it",
    "EXPOSED_FILES_TERMS": ["confidential", "confidencial", "internal use only", "uso interno", "interno", "restricted", "password", "senha", "api_key", "apikey", "token", "secret", "BEGIN RSA PRIVATE KEY", "AKIA", "boleto", "comprovante", "CPF", "nota fiscal", "fatura", "contrato"],
    "CODE_REPO_DORKS": ['site:github.com "{term}" "password"', 'site:github.com "{term}" "api_key"', 'site:github.com "{term}" "secret"', 'site:github.com "{term}" "token"', 'site:github.com "{term}" ".env"', 'site:gitlab.com "{term}" "password"', 'site:gitlab.com "{term}" "secret"', 'site:bitbucket.org "{term}" "credentials"', 'site:gist.github.com "{term}"', 'site:postman.com "{term}"', 'site:documenter.getpostman.com "{term}"', 'site:swaggerhub.com "{term}"', 'site:pastebin.com "{term}"', 'site:trello.com "{term}" "password"'],
    "OFFICIAL_REPO_PATTERNS": ["/docs/", "/documentation/", "official"],
    "APK_DORKS": ['"{term}" filetype:apk', 'site:apkpure.com "{term}"', 'site:apkmirror.com "{term}"', 'site:apkmonk.com "{term}"'],
}
_RUNTIME_CONFIG: dict[str, Any] = {}

try:
    import requests
    requests.packages.urllib3.disable_warnings()  # type: ignore
except Exception:
    requests = None

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def ttl_epoch() -> int:
    return int(time.time()) + TTL_DAYS * 86400

def to_dynamo(value: Any) -> Any:
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {k: to_dynamo(v) for k, v in value.items()}
    if isinstance(value, list):
        return [to_dynamo(v) for v in value]
    return value

def table():
    return DDB.Table(COLLECTOR_TABLE)

def put_item(item: dict):
    table().put_item(Item=to_dynamo(item))

def update_status(scan_id: str, provider: str, status: str, **extra):
    names = {"#s": "status"}
    values = {":s": status, ":u": now_iso()}
    sets = ["#s=:s", "updated_at=:u"]
    for i, (k, v) in enumerate(extra.items()):
        names[f"#k{i}"] = k; values[f":v{i}"] = to_dynamo(v); sets.append(f"#k{i}=:v{i}")
    table().update_item(Key={"scan_id": scan_id, "item_key": f"COLLECTOR#{provider}"}, UpdateExpression="SET " + ", ".join(sets), ExpressionAttributeNames=names, ExpressionAttributeValues=values)

def log(level: str, module: str, msg: str):
    global _LOG_COUNTER
    _LOG_COUNTER += 1
    entry = {"ts": now_iso(), "elapsed": 0, "level": level, "module": module, "msg": msg}
    print(json.dumps(entry, ensure_ascii=False))
    if _CURRENT_SCAN_ID:
        put_item({"scan_id": _CURRENT_SCAN_ID, "item_key": f"LOG#{entry['ts']}#{_LOG_COUNTER:06d}", "provider": PROVIDER, "level": level, "module": module, "message": msg, "created_at": entry["ts"], "log": entry, "ttl_epoch": ttl_epoch()})

class Logger:
    def info(self, module, msg): log("INFO", module, msg)
    def debug(self, module, msg): log("DEBUG", module, msg)
    def warn(self, module, msg): log("WARN", module, msg)
    def err(self, module, msg): log("ERROR", module, msg)
    def ok(self, module, msg): log("OK", module, msg)
    @property
    def entries(self): return []
    def dump(self): return []

def secret_values(force: bool = False) -> dict:
    global _SECRET_CACHE
    if _SECRET_CACHE and not force and time.time() - _SECRET_CACHE[0] < int(os.getenv("CTI_HUNTING_SECRET_CACHE_TTL", "60")):
        return dict(_SECRET_CACHE[1])
    try:
        raw = SECRETS.get_secret_value(SecretId=SECRETS_NAME).get("SecretString") or "{}"
        values = json.loads(raw) if raw.strip().startswith("{") else {}
        if not isinstance(values, dict): values = {}
    except Exception as exc:
        print(f"secret read failed: {exc}")
        values = {}
    _SECRET_CACHE = (time.time(), values)
    return dict(values)

def set_runtime_config(values: dict | None):
    global _RUNTIME_CONFIG
    _RUNTIME_CONFIG = values or {}

def cfg() -> dict:
    c = dict(DEFAULT_CONFIG)
    c.update(_RUNTIME_CONFIG or {})
    c.update({k: v for k, v in secret_values().items() if v not in (None, "")})
    return c

def configured(keys: list[str]) -> dict[str, bool]:
    c = cfg()
    return {k: bool(c.get(k)) for k in keys}

def put_finding(scan_id: str, module: str, finding: dict):
    fid = finding.get("fingerprint") or finding.get("_fp") or uuid.uuid4().hex
    put_item({"scan_id": scan_id, "item_key": f"FINDING#{module}#{fid}", "provider": PROVIDER, "module": module, "finding": finding, "created_at": now_iso(), "ttl_epoch": ttl_epoch()})

def notify(scan_id: str, job_id: str, status: str):
    payload = {"source": "cti_hunting.collector.completed", "scan_id": scan_id, "job_id": job_id or scan_id, "provider": PROVIDER, "status": status}
    LAMBDA.invoke(FunctionName=ORCHESTRATOR, InvocationType="Event", Payload=json.dumps(payload, ensure_ascii=False).encode("utf-8"))

def init_status(scan_id: str, job_id: str, modules: list[str]):
    put_item({"scan_id": scan_id, "item_key": f"COLLECTOR#{PROVIDER}", "provider": PROVIDER, "job_id": job_id or scan_id, "status": "running", "modules": modules, "started_at": now_iso(), "finished_at": "", "findings_count": 0, "logs_count": 0, "error": "", "ttl_epoch": ttl_epoch()})

def health(required: list[str], modules: dict | None = None, extra: dict | None = None):
    set_runtime_config({})
    secrets = configured(required)
    table_ok = True; table_error = ""
    try:
        DDB.meta.client.describe_table(TableName=COLLECTOR_TABLE)
    except Exception as exc:
        table_ok = False; table_error = str(exc)
    out = {"ok": table_ok and all(secrets.values()), "provider": PROVIDER, "table": COLLECTOR_TABLE, "required_secrets": secrets, "modules": modules or {}, "table_ok": table_ok}
    if table_error: out["table_error"] = table_error
    if extra: out.update(extra)
    return out

PROVIDER = "dnsprobe"
COLLECTOR_TABLE = os.getenv("CTI_HUNTING_COLLECT_DNSPROBE_TABLE", "cti_hunting_collect_dnsprobe")
REQUIRED_SECRETS: list[str] = []
_DNS_CACHE: dict[str, tuple[bool, float]] = {}; _DNS_TTL = 86400
BRAND_KEYWORDS = ["login", "secure", "account", "support", "verify", "auth", "portal", "client", "service", "official", "online", "app", "billing", "pay", "update", "mail", "webmail", "access", "help", "reset", "bank", "web", "my", "home"]
TLD_DICTIONARY = ["com", "net", "org", "io", "co", "info", "biz", "online", "site", "shop", "store", "live", "app", "xyz", "br", "com.br", "com.ar", "com.mx", "com.co"]
try:
    import dnstwist
    HAS_DNSTWIST = True
except ImportError:
    HAS_DNSTWIST = False

def domain(value: str) -> str:
    return (value or "").replace("https://", "").replace("http://", "").split("/")[0].lower().strip()

def generate(d: str, max_variants: int) -> list[tuple[str, str]]:
    if not HAS_DNSTWIST:
        log("WARN", "phishing", "dnstwist not installed; DNS-Probe skipped"); return []
    try:
        fuzz = dnstwist.Fuzzer(d, dictionary=BRAND_KEYWORDS, tld_dictionary=TLD_DICTIONARY)
        fuzz.generate()
        out = [(p["domain"], p.get("fuzzer", "unknown")) for p in fuzz.permutations() if p.get("domain") and not p.get("fuzzer", "").startswith("*") and p["domain"] != d]
        log("DEBUG", "phishing", f"{d}: {len(out)} permutations generated")
        return out[:max_variants]
    except Exception as exc:
        log("ERROR", "phishing", f"dnstwist error for {d}: {exc}"); return []

def resolve(variant: str) -> bool:
    now = time.time()
    if variant in _DNS_CACHE:
        alive, ts = _DNS_CACHE[variant]
        if now - ts < _DNS_TTL: return alive
    try:
        socket.getaddrinfo(variant, None, socket.AF_UNSPEC, socket.SOCK_STREAM); alive = True
    except (socket.gaierror, UnicodeError): alive = False
    _DNS_CACHE[variant] = (alive, now); return alive

def dns_batch(variants: list[tuple[str, str]], workers: int) -> list[tuple[str, str]]:
    alive = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(resolve, d): (d, f) for d, f in variants}
        for i, fut in enumerate(concurrent.futures.as_completed(futures), 1):
            if i % 50 == 0: log("DEBUG", "phishing", f"DNS probe: {i}/{len(variants)}")
            try:
                if fut.result(): alive.append(futures[fut])
            except Exception: pass
    return alive

def collect(terms: list[str]) -> list[dict]:
    c = cfg(); findings = []; seen = set()
    max_v = int(c.get("TYPO_MAX_VARIANTS", 500)); workers = int(c.get("TYPO_PROBE_WORKERS", 20))
    for term in terms:
        d = domain(term); variants = generate(d, max_v)
        if not variants: continue
        log("INFO", "phishing", f"{d}: resolving {len(variants)} permutations")
        live = dns_batch(variants, workers); log("OK", "phishing", f"{d}: {len(live)} live domain(s)")
        for v_domain, v_fuzzer in live:
            if v_domain in seen: continue
            seen.add(v_domain)
            findings.append({"term": term, "detection_type": "typosquatting", "typo_variant": v_domain, "title": "", "link": f"https://{v_domain}", "snippet": f"DNS registered [{v_fuzzer}]", "source": "DNS-Probe"})
    return findings

def handler(event, context):
    global _CURRENT_SCAN_ID
    event = event or {}
    if event.get("source") == "cti_hunting.health": return health(REQUIRED_SECRETS, {"phishing": {"ok": HAS_DNSTWIST}}, {"dnstwist_installed": HAS_DNSTWIST})
    scan_id = event.get("scan_id") or event.get("job_id"); job_id = event.get("job_id") or scan_id
    if not scan_id: return {"ok": False, "error": "scan_id is required"}
    _CURRENT_SCAN_ID = scan_id; set_runtime_config(event.get("config") or {})
    modules = event.get("modules") or []; init_status(scan_id, job_id, modules)
    status = "completed"; error = ""; count = 0
    try:
        if "phishing" in modules:
            findings = collect(event.get("terms") or []); count += len(findings)
            for item in findings: put_finding(scan_id, "phishing", item)
    except Exception as exc:
        traceback.print_exc(); status = "failed"; error = str(exc); log("ERROR", PROVIDER, f"failed: {exc}")
    update_status(scan_id, PROVIDER, status, finished_at=now_iso(), findings_count=count, error=error)
    notify(scan_id, job_id, status)
    return {"ok": status == "completed", "provider": PROVIDER, "scan_id": scan_id, "status": status, "findings_count": count, "error": error}
